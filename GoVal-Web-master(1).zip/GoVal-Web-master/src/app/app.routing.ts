import { Routes } from '@angular/router';
import { AdminComponent } from './layout/admin/admin.component';
import { AuthComponent } from './layout/auth/auth.component';
import { AuthGuardService } from './layout/auth/AuthGuardService';
import { MasterDynamicTemplateComponent } from './pages/master-dynamic-template/master-dynamic-template.component';
import { NotificationComponent } from './pages/notification/notification.component';
import { WorkFlowDynamicTemplateComponent } from './pages/work-flow-dynamic-template/work-flow-dynamic-template.component';



export const AppRoutes: Routes = [
  {
    path: '',
    component: AdminComponent,
    children: [
      {
        path: '',
        redirectTo: '/authentication/login/with-social',
        pathMatch: 'full'
      }, {
        path: 'dashboard',
        canActivate: [AuthGuardService],
        loadChildren: './pages/dashboard/dashboard.module#DashboardModule'
      },{
        path: 'login',
        redirectTo: '/authentication/login/with-social',

      },

      {
        path: '404',
        loadChildren: './pages/error-page404/errot-page404.module#ErrorPage404Module'
      },
      {
        path: 'auditTrail',
        canActivate: [AuthGuardService],
        loadChildren: './pages/audit-trail/audit-trail.module#AuditTrailModule'
      }, {
        path: 'organization',
        canActivate: [AuthGuardService],
        loadChildren: './pages/organization/organization.module#OrganizationModule'
    }, {
      path: 'userMapping',
      canActivate: [AuthGuardService],
      loadChildren: './pages/user-mapping/user-mapping.module#UserEquipmentModule'
  },{
    path: 'workflowConfiguration',
    canActivate: [AuthGuardService],
    loadChildren: './pages/workflow-configuration/workflow-configuration.module#WorkflowConfigurationModule'
}
,{
  path: 'commonconfiguration',
  canActivate: [AuthGuardService],
  loadChildren: './pages/commonworkflowconfiguration/commonworkflowconfiguration.module#CommonWorkflowConfigurationModule'
},
    {
      path: 'Project-setup',
      canActivate: [AuthGuardService],
      loadChildren: './pages/projectsetup/projectsetup.module#ProjectSetupModule'
    },
    {
      path: 'equipmentDetailDashboard',
      canActivate: [AuthGuardService],
      loadChildren: './pages/equipment-wise-dashboard/equipment-wise-dashboard.module#EquipmentWiseDashboardModule'
    },{
      path: 'URS',
      canActivate: [AuthGuardService],
      loadChildren: './pages/urs/urs.module#URSModule'
    },{
      path: 'iqtc',
      canActivate: [AuthGuardService],
      loadChildren: './pages/iqtc/iqtc.module#IqtcModule'
    },
	{
      path: 'Summary-Report',
      canActivate: [AuthGuardService],
      loadChildren: './pages/validation-summary-report/validation-summary.module#VSRModule'
    },
    {
      path: 'createForms',
      canActivate: [AuthGuardService],
      loadChildren: './pages/master-dynamic-forms/master-dynamic-forms.module#MasterDynamicFormsModule'
    },
    {
      path: 'deviceMaster',
      canActivate: [AuthGuardService],
      loadChildren: './pages/device-master/device-master.module#DeviceMasterModule'
    },
    {
      path: 'test',
      canActivate: [AuthGuardService],
      loadChildren: './pages/iqtc/iqtc.module#IqtcModule'
    },{
      path: 'test',
      canActivate: [AuthGuardService],
      loadChildren: './pages/oqtc/OQTestCase.module#OQTCModule'
    },
    {
      path: 'test',
      canActivate: [AuthGuardService],
      loadChildren: './pages/pqtc/pqtc.module#PQTCModule'
    },
    {
      path: 'department',
      canActivate: [AuthGuardService],
      loadChildren: './pages/department/department.module#DepartmentModule'
    },
    {
      path: 'traceability',
      canActivate: [AuthGuardService],
      loadChildren: './pages/traceabilitymatrix/traceabilitymatrix.module#TraceModule'
    },
    {
      path: 'testCaseCreation',
      canActivate: [AuthGuardService],
      loadChildren: './pages/test-case-creation/test-case-creation.module#TestCreationModule'
    },
    {
      path: 'riskAssessment',
      canActivate: [AuthGuardService],
      loadChildren: './pages/risk-assessment/risk-assessment.module#RiskAssessmentModule'
    },
    {
      path: 'rolesManagement',
      canActivate: [AuthGuardService],
      loadChildren: './pages/role-management/role-mangement.module#RoleManagementModule'
    },
    {
      path: 'df',
      canActivate: [AuthGuardService],
      loadChildren: './pages/discrepancy-form/discrepancy-status.module#DiscrepancyFormModule'
    },
    {
      path: 'roles',
      canActivate: [AuthGuardService],
      loadChildren: './pages/roles/roles.module#RolesModule'
    },
    {
      path: 'add-riskAssessment',
      canActivate: [AuthGuardService],
      loadChildren: './pages/risk-assessment/add-risk-assessment/add-risk-assessment.module#AddRiskAssessmentModule'
    },
    {
        path: 'add-riskAssessment/:id',
        canActivate: [AuthGuardService],
        loadChildren: './pages/risk-assessment/add-risk-assessment/add-risk-assessment.module#AddRiskAssessmentModule'
      },
      {
        path: 'add-riskAssessmenttemplate',
        canActivate: [AuthGuardService],
        loadChildren: './pages/riskassesstemplate/add-riskassesstemplate/add-riskassesstemplate.module#AddRiskassesstemplateModule'
      },
      {
        path: 'riskAssessmentTemplate',
        canActivate: [AuthGuardService],
        loadChildren: './pages/riskassesstemplate/riskassesstemplate.module#RiskassesstemplateModule'
      },
      {
        path: 'add-riskAssessmenttemplate/:id',
        canActivate: [AuthGuardService],
        loadChildren: './pages/riskassesstemplate/add-riskassesstemplate/add-riskassesstemplate.module#AddRiskassesstemplateModule'
      },
      {
        path: 'add-department',
        canActivate: [AuthGuardService],
        loadChildren: './pages/department/add-department/add-department.module#AddDepartmentModule'
      },
      {
        path: 'add-department/:id',
        canActivate: [AuthGuardService],
        loadChildren: './pages/department/add-department/add-department.module#AddDepartmentModule'
      },
      {
        path: 'Priority',
        canActivate: [AuthGuardService],
        loadChildren: './pages/priority/priority.module#PriorityModule'
      },
      {
        path: 'category',
        canActivate: [AuthGuardService],
        loadChildren: './pages/category/category.module#CategoryModule'
      },
      {
        path: 'oqtc',
        canActivate: [AuthGuardService],
        loadChildren: './pages/oqtc/OQTestCase.module#OQTCModule'
      },
      {
        path: 'pqtc',
        canActivate: [AuthGuardService],
        loadChildren: './pages/pqtc/pqtc.module#PQTCModule'
      },
      {
        path: 'knowledgeBase',
        canActivate: [AuthGuardService],
        loadChildren: './pages/knowledge-base/knowledge-base.module#KnowledgeBaseModule'
      },
      {
        path: 'ldap',
        canActivate: [AuthGuardService],
        loadChildren: './pages/LDAP/ldap.module#LDAPModule'
      },
      {
        path: 'look-up',
        canActivate: [AuthGuardService],
        loadChildren: './pages/LookUpCategory/lookup.module#LookUpModule'
      },
      {
        path: 'editor',
        canActivate: [AuthGuardService],
        loadChildren: './pages/ui-elements/editor/editor.module#EditorModule'
      },
      {
        path: 'userManagement',
        canActivate: [AuthGuardService],
        loadChildren: './pages/userManagement/user.module#UserModule'
      },
      {
        path: 'DocStatus',
        canActivate: [AuthGuardService],
        loadChildren: './pages/document-status/document-status.module#DocumentStatusModule'
      },
      {
          path: 'masterControl',
          canActivate: [AuthGuardService],
          loadChildren: './pages/master-control/master-control.module#MasterControlModule'
        },
        {
            path: 'pdfPreference',
            canActivate: [AuthGuardService],
            loadChildren: './pages/pdf-preferences/pdf-preferences.module#pdfPreferenceModule'
          },
          {
            path: 'vendor',
            canActivate: [AuthGuardService],
            loadChildren: './pages/vendor/vendor.module#VendorModule'
          },

          {
            path: 'user',
            canActivate: [AuthGuardService],
            loadChildren: './pages/user/user.module#UserModule'
          },

          {
              path: 'dynamicTemplate',
              canActivate: [AuthGuardService],
              loadChildren: './pages/dynamic-templates/dynamic-templates.module#DynamicTemplatesModule'
            },

            {
              path: 'MainMenu',
              canActivate: [AuthGuardService],
              loadChildren: './pages/mainmenu/mainmenu.module#MainMenuModule'
          },
          {
            path: 'home',
            canActivate: [AuthGuardService],
            loadChildren: './pages/home/home.module#HomeModule'
        },
          {
            path: 'Masterdatasetup',
            canActivate: [AuthGuardService],
            loadChildren: './pages/masterdatasetup/masterdatasetup.module#MasterDataSetupmodule'
          },
          {
            path: 'projectplan',
            canActivate: [AuthGuardService],
            loadChildren: './pages/projectplan/projectplan.module#ProjectPlanModule'
          },
          {
            path: 'forgetPassword',
            redirectTo: '/authentication/forgot',
          },
          {
            path: 'changePassword',
            canActivate: [AuthGuardService],
            loadChildren: './pages/authentication/changepassword/changePassword.module#ChangePasswordModule'
        },{
          path: 'dynamicForm/:id',
          canActivate: [AuthGuardService],
          loadChildren:'./pages/dynamic-form/dynamic-form.module#DynamicFormModule'
        },
        {
          path: 'dynamicFormView/:id',
          canActivate: [AuthGuardService],
          loadChildren:'./pages/dynamic-form-view/dynamic-form-view.module#DynamicFormViewModule'
        }
        ,{
          path: 'notification',
          canActivate: [AuthGuardService],
          component:NotificationComponent,
        },
       {
          path: 'search',
          canActivate: [AuthGuardService],
          loadChildren: './pages/advanced-search/advenced-search.module#AdvencedSearchModule'
      },
        {
          path: 'dms',
          canActivate: [AuthGuardService],
          loadChildren: './pages/dms/dms.module#DmsModule'
      },
      {
        path: 'formEquipment',
        canActivate: [AuthGuardService],
        loadChildren: './pages/form-equipment/form-equipment.module#FormEquipmentModule'
    },
{
          path: 'newDocumentStatus',
          canActivate: [AuthGuardService],
          loadChildren: './pages/doc-status/doc-status.module#DocStatusModule'
        },
    {
      path: 'bulkUpload',
      canActivate: [AuthGuardService],
      loadChildren: './pages/bulk-upload/bulk-upload.module#BulkUploadModule'
  },{
    path: 'masterDynamicForm',
    canActivate: [AuthGuardService],
   loadChildren: './pages/master-dynamic-forms/master-dynamic-forms.module#MasterDynamicFormsModule'
  },
    {
        path: 'workFlowMasterDynamicForm',
        canActivate: [AuthGuardService],
       loadChildren: './pages/work-flow-dynamic-form/work-flow-dynamic-form.module#DynamicFormModule'
      }, {
        path: 'newDynamicTemplate',
        canActivate: [AuthGuardService],
        loadChildren: './pages/dynamic-template/dynamic-template.module#DynamicTemplateModule'
      },{
        path: 'workFlowMasterDynamicTemplate',
        canActivate: [AuthGuardService],
        component:WorkFlowDynamicTemplateComponent
      },{
        path: 'masterDynamicTemplate',
        canActivate: [AuthGuardService],
        component:MasterDynamicTemplateComponent
      },
      {
        path: 'templates',
        canActivate: [AuthGuardService],
        loadChildren: './pages/templates/templates.module#TemplatesModule'
      },
      {
        path: 'equipment',
        canActivate: [AuthGuardService],
        loadChildren: './pages/equipment/equipment.module#EquipmentModule'
      },
      {
        path: 'facility',
        canActivate: [AuthGuardService],
        loadChildren: './pages/facility/facility.module#FacilityModule'
      },{
        path: 'batch',
        canActivate: [AuthGuardService],
        loadChildren: './pages/batch-creation/batch-creation.module#BatchCreationModule'
      },
      {
        path: 'location',
        canActivate: [AuthGuardService],
        loadChildren: './pages/location/location.module#LocationModule'
      },
      {
        path: 'shift',
        canActivate: [AuthGuardService],
        loadChildren: './pages/shift/shift.module#ShiftModule'
      },
      {
        path: 'formReports',
        canActivate: [AuthGuardService],
        loadChildren: './pages/form-reports/form-reports.module#FormReportsModule'
      },
      {
        path: 'equipmentDashboard',
        canActivate: [AuthGuardService],
        loadChildren: './pages/equipment-dashboard/equipment-dashboard.module#EquipmentDashboardModule'
      },
      {
        path: 'freeze',
        canActivate: [AuthGuardService],
        loadChildren: './pages/freezemodule/freezemodule.module#FreezeModule'
      },
      {
        path: 'templatebuilder',
        canActivate: [AuthGuardService],
        loadChildren: './pages/templatebuilder/templatebuilder.module#templateBuilderModule'
      },
      {
        path: 'equipmentStatus',
        canActivate: [AuthGuardService],
        loadChildren: './pages/equipment-status/equipment-status.module#EquipmentStatusModule'
      },
      {
        path: 'smtpMasterSetup',
        canActivate: [AuthGuardService],
        loadChildren: './pages/smtp-setup-master/smtp-setup-master.module#SmtpSetupMasterModule'
      },
      {
        path: 'emaillogs',
        canActivate: [AuthGuardService],
        loadChildren: './pages/emaillogs/emaillogs.module#EmailLogsModule'
      },
      {
        path: 'emailTemplateConfig',
        canActivate: [AuthGuardService],
        loadChildren: './pages/email-template-config/email-template-config.module#EmailTemplateConfigModule'
      },
      {
        path: 'equipmentStatusUpdate',
        canActivate: [AuthGuardService],
        loadChildren: './pages/equipment-status-update/equipment-status-update.module#EquipmentStatusUpdateModule'
      },
      {
        path: 'projectSummary',
        canActivate: [AuthGuardService],
        loadChildren: './pages/project-summary/project-summary.module#ProjectSummaryModule'
      },
      {
        path: 'calendarView',
        canActivate: [AuthGuardService],
        loadChildren: './pages/calender-view/calender-view.module#CalenderViewModule'
      },
       {
        path: 'emailRule',
        canActivate: [AuthGuardService],
        loadChildren: './pages/email-rule/email-rule.module#EmailRuleModule'

      } ,
      {
        path: 'documentsummary',
        canActivate: [AuthGuardService],
        loadChildren: './pages/documentsummary/documentsummary.module#DocumentsummaryModule'

      } ,
      {
        path: 'documentapprovalstatus',
        canActivate: [AuthGuardService],
        loadChildren: './pages/document-approval-status/document-approval-status.module#DocumentApprovalStatusModule'

      } ,
       {
        path: 'newEquipmentDashboard/:id',
        canActivate: [AuthGuardService],
        loadChildren: './pages/new-equipmemt-dashboard/new-equipmemt-dashboard.module#NewEquipmemtDashboardModule'

      } ,
      {
       path: 'equipmentCalendarView',
       canActivate: [AuthGuardService],
       loadChildren: './pages/equipment-calendar-view/equipment-calendar-view.module#EquipmentCalenderViewModule'
     },{
      path: 'emaillogs',
      canActivate: [AuthGuardService],
      loadChildren: './pages/emaillogs/emaillogs.module#EmailLogsModule'
    },{
      path: 'dateFormatSettings',
      canActivate: [AuthGuardService],
      loadChildren: './pages/date-format-settings/date-format-settings.module#DateFormatSettingsModule'
    },{
      path: 'taskCreation',
      canActivate: [AuthGuardService],
      loadChildren: './pages/task-creation/task-creation.module#TaskCreationModule'
    },
    {
      path: 'ccf',
      canActivate: [AuthGuardService],
      loadChildren: './pages/change-control-form/change-control-form.module#CCFModule'
    },{
      path: 'matrix',
      canActivate: [AuthGuardService],
      loadChildren: './pages/gobal-traceability-matrix/gobal-traceability-matrix.module#GobalTraceModule'
    },{
      path: 'periodic-review',
      canActivate: [AuthGuardService],
      loadChildren: './pages/periodic-review/periodic-review.module#PeriodicReviewModule'
    },{
      path: 'documentsReport',
      canActivate: [AuthGuardService],
      loadChildren: './pages/documents-report/documents-report.module#ReportsModule'
    },{
      path: 'taskReport',
      canActivate: [AuthGuardService],
      loadChildren: './pages/task-report/task-report.module#TaskReportsModule'
    },
    {
      path: 'myTask',
      canActivate: [AuthGuardService],
      loadChildren: './pages/my-task/my-task.module#MyTaskModule'
    },
    {
      path: 'timeline-graph',
      canActivate: [AuthGuardService],
      loadChildren: './pages/timeline-graph/timeline-graph.module#TimelineGraphModule'
    },
    {
      path: 'vendor-master',
      canActivate: [AuthGuardService],
      loadChildren: './pages/vendor-master/vendor-master.module#vendorMasterModule'
    },
    {
      path: 'apiConfiguration',
      canActivate: [AuthGuardService],
      loadChildren: './pages/api-configuration/api-configuration.module#ApiConfigurationModule'
    },
    {
      path: '**',
      redirectTo: "/404"
    }
    ]
  }, {
    path: '',
    component: AuthComponent,
    children: [
      {
        path: 'authentication',
        loadChildren: './pages/authentication/authentication.module#AuthenticationModule'
      }
    ]
  }
];
