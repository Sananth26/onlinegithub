
import { AfterViewInit, ChangeDetectorRef, Component, ElementRef, Inject, OnDestroy, OnInit, Renderer2, ViewChild } from '@angular/core';
import { Http } from '@angular/http';
import { DOCUMENT } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { BehaviorSubject, Observable } from '../../../../node_modules/rxjs';
import { CommonModel, dropDownDto, NavMasterDto, User, UserPrincipalDTO } from '../../models/model';
import { AuthenticationService } from '../../pages/authentication/authentication.service';
import { DateFormatSettingsService } from '../../pages/date-format-settings/date-format-settings.service';
import { FileUploadForDocService } from '../../pages/file-upload-for-doc/file-upload-for-doc.service';
import { FileViewComponent } from '../../pages/file-view/file-view.component';
import { IQTCService } from '../../pages/iqtc/iqtc.service';
import { KnowledgeBaseService } from '../../pages/knowledge-base/knowledge-base.service';
import { projectsetupService } from '../../pages/projectsetup/projectsetup.service';
import { UrsService } from '../../pages/urs/urs.service';
import { ConfigService } from '../../shared/config.service';
import { ModalBasicComponent } from '../../shared/modal-basic/modal-basic.component';
import { LocationService } from '../../pages/location/location.service';

@Component({
    selector: 'app-admin',
    templateUrl: './admin.component.html',
    styleUrls: [
        './admin.component.css', './notification.scss',
    ],
    providers: [projectsetupService, UrsService, ConfigService, FileUploadForDocService],
})


export class AdminComponent implements OnInit, AfterViewInit, OnDestroy {
    @ViewChild('modalSmallProjectGlobal') modalSmallProjectGlobal;
    @ViewChild('modalSmallTaskGlobal') modalTaskGlobal;
    @ViewChild('TaskCreation') modalTaskCreation;
    @ViewChild('fileuploadAdmin') private fileupload: any;
    @ViewChild('viewFileGlobal') private viewFile: FileViewComponent;
    @ViewChild('searchFriends') search_friends: ElementRef;
    @ViewChild('headernotification') el: ElementRef;
    @ViewChild('iframeKnowId') iframe: ElementRef;
    @ViewChild('iframeImageId') iframeImage: ElementRef;
    @ViewChild('modalLarge') modalLarge: any;
    @ViewChild('videoModalSmall') modalSmall: ModalBasicComponent;
    @ViewChild('videoViewTag') videoViewTag: any;
    @ViewChild("video_iframe") _videoPlayer: ElementRef;
    isloading = false;
    currentUser: UserPrincipalDTO = new UserPrincipalDTO();
    navMasterDataSetup: any[] = new Array();
    navDocuments: any[] = new Array();
    navForms: any[] = new Array();
    navTemplates: any[] = new Array();
    navEquipments: any[] = new Array();
    navSettings: any[] = new Array();
    navAuditTrail: any[] = new Array();
    navDocumentStatus: any[] = new Array();
    isHeaderChecked: boolean;
    public static Title: number = 0;
    public titleList: any = [];
    selectedProject: any;

    filterQuery: string = "";
    public newNotification: boolean = false;
    public notificationList: any;
    selectedModule: string = "";
    // This is use for creating the task form their component;
    public taskDocType: string;
    public taskDocTypeUniqueId: string = "";
    public taskEquipmentId: number = 0;
    public taskEnbleFlag: boolean = false;
    // This is use for creating the task form their component;
    knowledgeBaseContent: any;
    content: string = "";
    public navMasterDto: NavMasterDto = new NavMasterDto();
    showModal: boolean = false;
    videoURL: any;
    isVideo: boolean = false;
    isPdf: boolean = false;
    isImage: boolean = false;
    spinnerFlag: boolean = false;
    videoSpinnerFlag: boolean = false;
    timeZone: string = "";
    FTPFileSize: string = "";

    // for screen recording
    rowData: any;
    dfId: any;
    iqId: any;
    url: any;
    documentType: any;
    queryParams: any;
    videoFile: any;
    documentName: any;

    mainElementDisplay: boolean = false;
    showSuccessMsg: boolean = false;
    isUpdate: boolean = false;
    receivedId: any;
    location: any;
    locationsList: any;
    constructor(private renderer2: Renderer2, @Inject(DOCUMENT) private _document,
        public service: IQTCService,
        public authenticationService: AuthenticationService, private cdr: ChangeDetectorRef,
        private http: Http, public config: ConfigService,
        private router: Router, public projectsetupService: projectsetupService,
        public configService: ConfigService, public knowledgeBaseService: KnowledgeBaseService,
        private servie: DateFormatSettingsService,public locationService:LocationService) {

        /* Please  this if you like it! */


        (function ($) {
            "use strict";

            let data: boolean = true;
            //Open dropdown when clicking on element
            $(document).on('click', "a[data-dropdown='notificationMenu']", function (e) {

            });

            //Close dropdowns on document click

            $(".dropdown-container").click(function (e) {
                e.stopPropagation();
            });

            $(document).on('click', '#dropdownOverlay', function (e) {

                var el = (<any>$(e.currentTarget)[0]).activeElement;
                if (typeof $(el).attr('data-dropdown') === 'undefined') {
                    $('#dropdownOverlay').remove();
                    $('.dropdown-container.expanded').removeClass('expanded');
                }


            })






            $(document).click(function (e) {
                var el = (<any>$(e.currentTarget)[0]).activeElement;
                if (typeof $(el).attr('data-dropdown') === 'undefined') {
                    $('#dropdownOverlay').remove();
                    $('.dropdown-container.expanded').removeClass('expanded');
                }
            });



            $(document).on('click', '.notification-list-item', function (e) {
                e.stopPropagation();
            });





            $(function () {
                var header = $(".start-style");
                $(window).scroll(function () {
                    var scroll = $(window).scrollTop();

                    if (scroll >= 10) {
                        header.removeClass('start-style').addClass("scroll-on");
                    } else {
                        header.removeClass("scroll-on").addClass('start-style');
                    }
                });

            });

            //Animation

            $(document).ready(function () {
                $('body.hero-anime').removeClass('hero-anime');
            });

            //Menu On Hover

            $('body').on('mouseenter mouseleave', '.nav-item', function (e) {
                if ($(window).width() > 750) {
                    var _d = $(e.target).closest('.nav-item'); _d.addClass('show');
                    setTimeout(function () {
                        _d[_d.is(':hover') ? 'addClass' : 'removeClass']('show');
                    }, 1);
                }
            });

            //Switch light/dark

            $("#switch").on('click', function () {
                if ($("body").hasClass("dark")) {
                    $("body").removeClass("dark");
                    $("#switch").removeClass("switched");
                }
                else {
                    $("body").addClass("dark");
                    $("#switch").addClass("switched");
                }
            });






        })(jQuery);

        this.taskEnbleFlag = false;
    }

    opennotificationdropdown(e) {
        e.preventDefault();
        //data = false;

        var container = $(e.currentTarget).parent();
        var dropdown = container.find('.dropdown');
        var containerWidth = container.width();

        dropdown.css({
            'right': containerWidth / 2 + 'px'
        })

        container.toggleClass('expanded " "')

    }
    ovenenvelope(e) {
        e.stopPropagation();
        if ($(e.currentTarget).parent().hasClass('expanded')) {
            $('.notification-group').removeClass('expanded');
        }
        else {
            $('.notification-group').removeClass('expanded');
            $(e.currentTarget).parent().toggleClass('expanded');
        }
    }

    public source = new BehaviorSubject<dropDownDto>(new dropDownDto());
    //key: projectId , value: projectName
    globalProjectObservable = this.source.asObservable();

    model: User;
    modal: CommonModel = new CommonModel();
    isApplicationAdmin: boolean = false;
    isSuperAdmin: boolean = false;
    userName: string;
    roleName: string;
    sub: any

    loadnavBar() {

        this.configService.HTTPPostAPI("", "modules/loadNavBarPermission").subscribe(response => {
            this.navMasterDto = response;
            // Loading Respective module if the user has access
            if (this.navMasterDto.formsPermission)
                this.loadNavBarForms();

            if (this.navMasterDto.templatesPermission)
                this.loadNavBarTemplates();

            if (this.navMasterDto.documentStatusPermission)
                this.loadNavBarForDocumentStatus();

            if (this.navMasterDto.auditTrailPermission)
                this.loadNavBarForAuditTrail();

            if (this.navMasterDto.equipmentPermission)
                this.loadNavBarForEquipments();
            //Setting only for Super Admin 
            this.loadNavBarForSettings();

            if (!this.isApplicationAdmin) {
                this.loadNavBarForMasterDataSetUp();
                this.loadNavBarForDocuments();
            }
            this.isloading = true;
        });
    }

    public loadNavBarForms() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForms").subscribe(response => {
            this.navForms = response;
        });
    }
    public loadNavBarTemplates() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarTemplates").subscribe(response => {
            this.navTemplates = response;
        });
    }

    public loadNavBarForMasterDataSetUp() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForMasterDataSetUp").subscribe(response => {
            this.navMasterDataSetup = response;
        });

    }

    public loadNavBarForDocuments() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForDocuments").subscribe(response => {
            this.navDocuments = response;
        });
    }

    public loadNavBarForEquipments() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForEquipments").subscribe(response => {
            this.navEquipments = response;
        });
    }

    public loadNavBarForSettings() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForSettings").subscribe(response => {
            this.navSettings = response;
        });
    }

    public loadNavBarForAuditTrail() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForAuditTrail").subscribe(response => {
            this.navAuditTrail = response;
        });
    }

    public loadNavBarForDocumentStatus() {
        this.configService.HTTPPostAPI("", "modules/loadNavBarForDocumentStatus").subscribe(response => {
            this.navDocumentStatus = response;
        });
    }
    ngOnDestroy(): void {
        // this.sub.unsubscribe();
    }
    ngOnInit() {
        if (localStorage.length > 0 && localStorage.getItem('token')) {
            // this.loadProjects();
            this.loadCurrentUserDetails();
            if (document.location.pathname !== "/home") {
                this.loadnavBar();
            }

            this.loadOrgDateFormat();
            this.sub = Observable.interval(30000).subscribe((val) => {
                if (null != localStorage.getItem("token"))
                    this.loadNotification()
            });

            this.router.events.subscribe((ev) => {
                if (ev instanceof NavigationEnd) {
                    if (null != localStorage.getItem("token"))
                        this.loadNotification()
                    this.removeDraftOfProjectSetUp()
                }
            });
        } else {
            this.router.navigate(["/login"]);
        }
    }


    loadCurrentUserDetails(): Promise<any> {
        return new Promise<any>(resolve => {
            this.configService.loadCurrentUserDetails().subscribe(jsonResp => {
                this.currentUser = jsonResp;
                resolve(jsonResp);
                if (this.config.helper.APPLICATION_ADMIN == this.currentUser.adminFlag)
                    this.isApplicationAdmin = true;
                if (this.config.helper.SUPER_ADMIN == this.currentUser.adminFlag)
                    this.isSuperAdmin = true;
                this.userName = this.currentUser.username;
                this.roleName = this.currentUser.roleName;
                this.model = new User();
                this.modal = new CommonModel();
                this.model.userName = this.currentUser.username.toLocaleUpperCase();
                this.modal.globalProjectName = this.currentUser.projectName;
                this.modal.globalProjectId = this.currentUser.projectId;
                this.modal.projectVersionName = this.currentUser.versionName;
            });
        });
    }

    loadOrgDateFormat() {
        this.spinnerFlag = true;
        this.servie.getOrgDateFormat().subscribe(result => {
            if (!this.config.helper.isEmpty(result)) {
                this.timeZone = result.timeZoneId;
                this.FTPFileSize = result.ftpFileSize;
            }
            this.spinnerFlag = false;
        });
    }
    ngAfterViewInit() {

    }


    logOut() {
        this.authenticationService.logOut(this.model).subscribe(jsonResp => {
        });
        this.config.helper.clearLocalStorage();
        this.router.navigate(["/login"]);
    }
    showProjectModal() {
        this.loadLocation();
        if (this.modalSmallProjectGlobal) {
            this.modalSmallProjectGlobal.show();
        }
    }
    onChange(id: any, dontreDirect?): Promise<void> {
        this.spinnerFlag = true;
        return new Promise<void>(resolve => {
            this.configService.saveCurrentProject(id).subscribe(response => {
                this.spinnerFlag = false;
                let list = this.titleList.filter(p => p.id == id);
                if (list.length != 0) {
                    this.modal.globalProjectName = list[0].projectName;
                    this.modal.globalProjectId = list[0].id;

                } else {
                    this.modal.globalProjectName = 'No Active Project Available';
                    this.modal.globalProjectId = 0
                }
                this.loadCurrentUserDetails();
                let dropDown: dropDownDto = new dropDownDto()
                dropDown.key = "" + this.modal.globalProjectId;
                dropDown.value = this.modal.globalProjectName;
                this.source.next(dropDown);
                if (!dontreDirect)
                    this.router.navigate(['/home'])
                resolve();
            }, err => resolve());
        })
    }


    loadNotification() {
        if (localStorage.length > 0 && localStorage.getItem('token')) {
            this.newNotification = false
            this.loadnotification("", "usernotification/loadnotification")
                .catch((e: any) => Observable.throw(this.handleError(e))).subscribe(response => {
                    this.notificationList = response;
                    this.cdr.markForCheck();
                })
        }else{
            this.router.navigate(["/login"]);
        }
    }
    handleError(error): string {
        if (error.status == 401 && error.error == "Unauthorized")
            localStorage.clear()
        this.router.navigate(['/login']);
        return "Unauthorized";
    }

    viewedFlagForsinglenotification(item) {
        const data: any[] = new Array<any>();
        data.push(item);
        this.loadnotification(data, 'usernotification/checkedNotification').subscribe(response => {
            this.loadNotification()
            this.cdr.markForCheck();
        });
    }




    loadnotification(data?, url?) {
        return this.http.post(this.config.helper.common_URL + url, data, this.config.getRequestOptionArgs())
            .map((resp) => resp.json())
            .catch(res => {
                return Observable.throw(res.json());
            });
    }
    notification(url?) {
        return this.http.post(this.config.helper.common_URL + url, this.config.getRequestOptionArgs())
            .map((resp) => resp.json())
            .catch(res => {
                return Observable.throw(res.json());
            });
    }


    loadProjects(): Promise<any> {
        return new Promise<any>(resolve => {
            this.configService.loadprojectOfUserAndCreatorForLocation(this.location).subscribe(response => {
                this.titleList = response.projectList;
                resolve();
            },
            );
        })

    }
    loadLocation(){
    this.locationService.loadAllActiveLocations().subscribe(response =>{
        this.locationsList=response.result
      });
    }
   

    update(values: dropDownDto) {
        //key:projectid ,value projectname
        this.source.next(values);
    }
    redirectEBMR(url) {
        this.router.navigate([url]);
    }
    redirect(url, status?) {
        var queryParams = {};
        if (status) {
            queryParams["status"] = status;
        }
        if (url.includes("dynamicForm")) {
            let finalURLList = url.split("?");
            queryParams["exists"] = finalURLList[1];
            queryParams["id"] = finalURLList[0].split("/")[1];
            queryParams["isMapping"] = finalURLList[2];
            if (finalURLList[3]) {
                queryParams["documentCode"] = finalURLList[3];
            }

            this.router.navigate([finalURLList[0]], { queryParams: queryParams, skipLocationChange: true });
        } else if (url.includes("newDynamicTemplate")) {
            let finalURLList = url.split("?");
            let valueList = finalURLList[1].split("&");
            queryParams["exists"] = valueList[1];
            queryParams["id"] = valueList[0];
            this.router.navigateByUrl(this.router.createUrlTree(
                [finalURLList[0]], { queryParams: queryParams, skipLocationChange: true }));
        } else {
            this.router.navigateByUrl(url);
        }
    }
    updateSideMenu(url?: string) {
        this.loadNavBarForms();
        if (url == undefined) {
            this.router.navigate(['/home']);
        } else {
            this.router.navigate([url]);
        }
    }
    onClickHelp() {
        if (!this.config.helper.isEmpty(this.selectedModule)) {
            this.knowledgeBaseService.callAPI("knowledgebase/loadModuleContent", this.selectedModule).subscribe((resp) => {
                if (!this.config.helper.isEmpty(resp.data)) {
                    this.showModal = true;
                    this.knowledgeBaseContent = resp.data;
                    this.content = this.knowledgeBaseContent.content;
                    this.receivedId = this.knowledgeBaseContent.id;
                    this.fileupload.loadFileListForEdit(this.receivedId, this.config.helper.KNOWLEDGEBASE).then((result) => {
                        this.spinnerFlag = false;
                    }).catch((err) => {
                        this.spinnerFlag = false;
                    })
                    // this.loadKBFile();
                } else {
                    this.modalLarge.hide();
                    this.showModal = false;
                    this.router.navigate(['/knowledgeBase/view-knowledgeBase']);
                }
            });
        } else {
            this.modalLarge.hide();
            this.showModal = false;
            this.router.navigate(['/knowledgeBase/view-knowledgeBase']);
        }
    }
    setUpModuleForHelpContent(moduleId: any) {
        this.selectedModule = moduleId;
    }
    onClickCLose() {
        if (this.isVideo)
            this.iframe.nativeElement.src = "";
        this.showModal = false;
    }

    onClickExportKB() {
        this.knowledgeBaseService.downloadKBPdf(this.knowledgeBaseContent.subCategoryId).subscribe(res => {
            var blob: Blob = this.b64toBlob(res._body, 'application/pdf');
            let name = this.knowledgeBaseContent.subCategoryName + ".pdf";
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, name);
            } else {
                var a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = name;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            }
        });
    }
    b64toBlob(b64Data, contentType) {
        contentType = contentType || '';
        var sliceSize = sliceSize || 512;
        var byteCharacters = atob(b64Data);
        var byteArrays = [];
        for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
            var slice = byteCharacters.slice(offset, offset + sliceSize);
            var byteNumbers = new Array(slice.length);
            for (var i = 0; i < slice.length; i++) {
                byteNumbers[i] = slice.charCodeAt(i);
            }
            var byteArray = new Uint8Array(byteNumbers);
            byteArrays.push(byteArray);
        }
        var blob = new Blob(byteArrays, { type: contentType });
        return blob;
    }

    routeToUrl(row) {
        if (row.projectId != null) {
            this.onChange(row.projectId).then(() => {
                this.notificationrouteToUrl(row)
            })
        } else {
            this.notificationrouteToUrl(row)
        }
    }

    notificationrouteToUrl(row) {
        if (row.category == this.config.helper.PERMISSION_CATEGORY_FORM || row.category == 'Form_Group' || row.category == this.config.helper.PERMISSION_CATEGORY_TEMPLATE) {
            if (row.url) {
                this.redirect(row.url, location.pathname);
            }
            this.viewedFlagForsinglenotification(row);
        }
        else {
            this.router.navigate([row.url], { queryParams: { id: row.documentId, status: '/documentapprovalstatus', exists: true, list: row.selectedDocuments } });
        }
    }
    getMapSize(data) {
        var len = 0;
        for (var count in data) {
            len++;
        }
        return len;
    }

    removeDraftOfProjectSetUp() {
        localStorage.removeItem(this.config.helper.PERMISSION_CATEGORY_DOCUMENT);
        localStorage.removeItem(this.config.helper.PERMISSION_CATEGORY_FORM);
        localStorage.removeItem(this.config.helper.PERMISSION_CATEGORY_TEMPLATE);
        localStorage.removeItem(this.config.helper.PERMISSION_CATEGORY_FORM_GROUP);
    }

    openModalForScreenrecording(modelData, dfId, url, queryParams) {
        this.mainElementDisplay = false;
        this.showSuccessMsg = false;
        this.openVideoRecording(modelData, dfId, url, queryParams);
    }

    openVideoRecording(row, dfId, url, queryParams) {
        this.rowData = row;
        this.dfId = dfId;
        if (dfId === null) {
            this.iqId = this.rowData.id;
            this.documentName = this.rowData.testCaseCode;
        } else {
            this.iqId = null;
            if (this.dfId == 0)
                this.dfId = null;
            this.documentName = "discrepancy_form";
        }
        this.url = url
        if (queryParams != undefined)
            this.queryParams = queryParams;
        else
            this.queryParams = null;

        const s = this.renderer2.createElement('script');
        s.type = 'text/javascript';
        s.src=  '../../../assets/js/recorder.js';
        s.text = ``;
        this.renderer2.appendChild(this._document.body, s);
        var modalTag = document.getElementById('videoBody');
        modalTag.style.height = window.innerHeight - 110 + "px";
        this.modalSmall.show();
    }

    scrollToViewVideo() {
        this.modalSmall.show();
        this.mainElementDisplay = true;
        this.showSuccessMsg = false;

        var iframeTag = document.getElementById("video_iframe");
        iframeTag.setAttribute('src', window.URL.createObjectURL(fileTOTypeScript));
        iframeTag.setAttribute("style", "display:inline-block");
    }

    uploadFile() {
        if (this.iqId === null && this.dfId === null) {
            this.documentType = this.config.helper.DISCREPANCY_VALUE;
        }
        this.videoSpinnerFlag = true;
        this.modalSmall.spinnerShow();
        this.videoFile = fileTOTypeScript;
        if (localStorage.getItem('rowData'))
            localStorage.removeItem('rowData');
        this.service.saveRecordedVideo(this.videoFile, this.documentName, this.iqId, this.dfId, this.documentType).subscribe(jsonResp => {
            if (jsonResp.result === "success") {
                localStorage.setItem('rowData', this.config.helper.encode(this.rowData));
                // localStorage.setItem('fileId',this.config.helper.encode(jsonResp.fileDto.id));
                this.showSuccessMsg = true;
                this.videoSpinnerFlag = false;
                this.modalSmall.spinnerHide()
                this.closeView();
                setTimeout(() => {
                    if (this.queryParams != null) {
                        if (this.iqId != null)
                            this.router.navigate([this.url + "/" + this.queryParams]);
                        else
                            this.router.navigate([this.url], { queryParams: { id: this.queryParams, rowData: JSON.stringify(this.rowData), fileId: jsonResp.fileDto.id, skipLocationChange: true } });
                    } else {
                        if (this.iqId != null)
                            this.router.navigate([this.url]);
                        else
                            this.router.navigate([this.url], { queryParams: { rowData: JSON.stringify(this.rowData), fileId: jsonResp.fileDto.id, skipLocationChange: true } });
                    }
                }, 1500)
            }
        });
    }

    closeView() {
        this.videoFile = null;
        this.mainElementDisplay = false;
        this.showSuccessMsg = false;
        this.modalSmall.hide();
        var iframe = document.getElementById('video_iframe');
        iframe.setAttribute('src', '');
        iframe.setAttribute("style", "display:none");
        // this._videoPlayer.nativeElement.destroy();
    }

    /*Start Global File View From Any Module Methods*/
    /**
     * @param fileName => file name of the file
     * @param sFTPFilePath => file path of the SFTP
     * @param viewOrDownloadFlag => only viewing =true || download the file = false
     * @param headerName => in preview of modal ,the header name 
     */
    downloadOrViewFile(fileName: string, sFTPFilePath: string, viewOrDownloadFlag: boolean, headerName?: string) {
        if (this.viewFile)
            this.viewFile.downloadFileOrView(fileName, sFTPFilePath, viewOrDownloadFlag, headerName);
    }

    /**
     * @param fileName => file name of the file
     * @param blobResponse => blob response
     * @param viewOrDownloadFlag => only viewing =true || download the file = false
     * @param headerName => in preview of modal ,the header name 
     */
    previewByBlob(fileName: string, blobResponse: any, viewOrDownloadFlag: boolean, headerName?: string) {
        if (this.viewFile)
            this.viewFile.previewByBlob(fileName, blobResponse, viewOrDownloadFlag, headerName);
    }

    /**
     * @param fileName => file name of the file
     * @param base64 => base64 response
     * @param viewOrDownloadFlag => only viewing =true || download the file = false
     * @param headerName => in preview of modal ,the header name 
     */
    previewOrDownloadByBase64(fileName: string, base64: any, viewOrDownloadFlag: boolean, headerName?: string) {
        if (this.viewFile)
            this.viewFile.previewOrDownloadByBase64(fileName, base64, viewOrDownloadFlag, headerName);
    }

    loadTaskDetails() {

        this.modalTaskGlobal.show();
        this.modalTaskCreation.onClickCreate();
        this.modalTaskCreation.setTaskGobalValues(this.taskDocType, this.taskDocTypeUniqueId, this.taskEquipmentId);
    }
    checkTheTaskData() {
        if (this.taskDocType != undefined && this.taskDocType != '') {
            this.taskEnbleFlag = true;
        } else {
            this.taskEnbleFlag = false;
        }
    }
    onClickSave() {
        this.modalTaskCreation.onClickSave();
    }


}
