import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic-invoice',
  templateUrl: './basic-invoice.component.html',
  styleUrls: ['./basic-invoice.component.css']
})
export class BasicInvoiceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
