import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormPreviewComponent } from './form-preview.component';
import { SharedModule } from '../../shared/shared.module';
import { FormsModule } from '../ui-elements/forms/forms.module';
import { QuillEditorModule } from 'ngx-quill-editor';
import { SqueezeBoxModule } from 'squeezebox';
import { UiSwitchModule } from 'ng2-ui-switch';
import { SelectModule } from 'ng-select';
import { CKEditorModule } from 'ng2-ckeditor';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    QuillEditorModule,
    SqueezeBoxModule,
    UiSwitchModule,
    SelectModule,
    CKEditorModule
  ],
  declarations: []
})
export class FormPreviewModule { }
