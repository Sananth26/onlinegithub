import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dynamic-templates',
  templateUrl: './dynamic-templates.component.html',
  styleUrls: ['./dynamic-templates.component.css']
})
export class DynamicTemplatesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
