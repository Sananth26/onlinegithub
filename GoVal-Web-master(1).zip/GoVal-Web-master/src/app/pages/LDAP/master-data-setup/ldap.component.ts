import { OnInit, Component, ViewEncapsulation } from "../../../../../node_modules/@angular/core";
import { FormGroup, Validators, FormBuilder } from "../../../../../node_modules/@angular/forms";
import { LDAPService } from "../ldap.service";
import { Helper } from "../../../shared/helper";
import { LDAPMasterData, OrganizationDetails } from "../../../models/model";
import swal from "sweetalert2";
import { AdminComponent } from "../../../layout/admin/admin.component";

@Component({
    selector: 'ldap-selector',
    templateUrl: './ldap.component.html',
    styleUrls: ['./ldap.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
    encapsulation: ViewEncapsulation.None
})
export class LDAPComponent implements OnInit {
    formdata: FormGroup;
    orgs: Object[] = new Array();
    isLoading: boolean = false;
    dropDownLoad: boolean = false;
    ldapMasterData: LDAPMasterData = new LDAPMasterData();
    validation_messages = {
        'org': [
            { type: 'required', message: 'Organization is required.' },
        ],
        'mangerdn': [
            { type: 'required', message: 'Manager DN is required.' },
        ],
        'serverURL': [
            { type: 'required', message: 'LDAP Server URL is required.' },
        ],
        'serverPort': [
            { type: 'required', message: 'LDAP Server port is required.' },
            { type: 'pattern', message: 'Invalid port number' },
            { type: 'minlength', message: 'Server port should contain minium 3 numbers' },
        ],
    }

    constructor( private adminComponent: AdminComponent,public fb: FormBuilder, public ldapService: LDAPService, public helper: Helper) {
        this.formdata = fb.group({
            "org": ["", Validators.compose([
                Validators.required])],
            "mangerdn": ["", Validators.compose([
                Validators.required])],
            "serverURL": ["", Validators.compose([
                Validators.required])],
            "serverPort": ["", Validators.compose([
                Validators.required])],

        });
    }
    ngOnInit() {
        this.adminComponent.setUpModuleForHelpContent("");
        this.ldapService.loadAllOrgs().subscribe(jsonResp => {
            this.helper.logMessage("All Orgs", jsonResp);
            this.orgs = jsonResp;
        },
            err => {
            }
        );
    }
    submitForm() {
        this.isLoading = true;
        let org : OrganizationDetails = new OrganizationDetails();
        org.id = this.formdata.get("org").value;
        this.ldapMasterData.organizationDTO = org;
        this.ldapMasterData.managerDN = this.formdata.get("mangerdn").value;
        this.ldapMasterData.ldapURL = this.formdata.get("serverURL").value;
        this.ldapMasterData.ldapPort = this.formdata.get("serverPort").value;
        this.helper.logMessage("Form data ==>", this.ldapMasterData);
        this.ldapService.saveOrUpdate(this.ldapMasterData).subscribe(jsonResp => {
            this.helper.logMessage("After Save", jsonResp);
            if(jsonResp["type"] == "Updated"){
            swal(
                'Success',
                'Details are updated',
                'success'
            )
        }else{
            swal(
                'Success',
                'Details are saved',
                'success'
            ) 
        }
            this.isLoading = false;
        },
        err => {
            this.isLoading = false;
        }
        );
    }
    loadByOrgId(){
        this.dropDownLoad = true;
        let org : OrganizationDetails = new OrganizationDetails();
        org.id = this.formdata.get("org").value;
        this.ldapMasterData.organizationDTO = org;
        this.ldapService.loadByOrgId(this.ldapMasterData).subscribe(jsonResp => {
            this.helper.logMessage("After load", jsonResp);
            this.ldapMasterData.id = jsonResp["data"]["id"];
           
            this.formdata.controls["mangerdn"].setValue(jsonResp["data"]["managerDN"]);
            this.formdata.controls["serverURL"].setValue(jsonResp["data"]["ldapURL"]);
            this.formdata.controls["serverPort"].setValue(jsonResp["data"]["ldapPort"]);
            this.dropDownLoad = false;
        },
        err => {
            this.dropDownLoad = false;
        }
        );
    }
    clearForm() {
        this.formdata.controls["org"].setValue("");
        this.formdata.controls["mangerdn"].setValue("");
        this.formdata.controls["serverURL"].setValue("");
        this.formdata.controls["serverPort"].setValue("");
    }
}