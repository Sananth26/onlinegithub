import { Injectable } from "../../../../node_modules/@angular/core";
import { Http } from "../../../../node_modules/@angular/http";
import { Helper } from "../../shared/helper";
import { ConfigService } from "../../shared/config.service";
import { Observable } from "../../../../node_modules/rxjs";

@Injectable()
export class LDAPService {

  url_get_all_orgs: string = this.helper.common_URL + "organization/loadAllOrgs";
  url_save_or_update_ldap : string = this.helper.common_URL + "ldap/saveOrUpdate";
  url_load_by_org_id : string = this.helper.common_URL + "ldap/loadByOrgId";

  constructor(private http: Http, public helper: Helper, public config: ConfigService) { }

  loadAllOrgs() {
    return this.http.post(this.url_get_all_orgs, "N", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  saveOrUpdate(data : any) {
    return this.http.post(this.url_save_or_update_ldap, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  loadByOrgId(data : any) {
    return this.http.post(this.url_load_by_org_id, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
}