import { Component, OnInit, Input, ViewChild, Output,EventEmitter } from '@angular/core';
import { projectsetupService } from '../projectsetup/projectsetup.service';
import { StepperClass, UserPrincipalDTO, DocumentSummaryDTO, TestCaseSummaryDTO, TaskTimerTrackingDTO, ProjectTaskDTO } from '../../models/model';
import { DashBoardService } from '../dashboard/dashboard.service';
import { TaskCreationService } from '../task-creation/task-creation.service';
import { Router } from '@angular/router';
import { WorkflowConfigurationService } from '../workflow-configuration/workflow-configuration.service';
import { ConfigService } from '../../shared/config.service';
import { ProjectSummaryService } from '../project-summary/project-summary.service';
import swal from 'sweetalert2';
import { ChartOptions } from 'chart.js';
import { Helper } from '../../shared/helper';
import { DateFormatSettingsService } from '../date-format-settings/date-format-settings.service';
import { IQTCService } from '../iqtc/iqtc.service';
import { Permissions } from '../../shared/config';
@Component({
  selector: 'app-individual-document-summary',
  templateUrl: './individual-document-summary.component.html',
  styleUrls: ['./individual-document-summary.component.css']
})
export class IndividualDocumentSummaryComponent implements OnInit {
  docName='';
  @Input() permissionConstant: string = "";
  @ViewChild('freezemodal') freezeModalData: any;
  documentDetails: DocumentSummaryDTO;
  percentage: number = 0;
  progressBarColour: string;
  spinnerFlag: boolean = false;
  public loadStepperList: any[] = new Array();
  pendingTaskList: any[] = new Array();
  currentUser: UserPrincipalDTO = new UserPrincipalDTO();
  freezeData: any;
  documentlockDataLogs: any[] = new Array();
  @Output() onCloseSummary = new EventEmitter();
  viewFlag:boolean=false;
  projectPlanviewFlag:boolean=false;
  projectTaskviewFlag:boolean=false;
  testApproachviewFlag:boolean=false;
  TableViewFlag:boolean=false;
  pieChartLabels: string[] = ['No Run', 'In-Progress', 'Pass', 'Fail', 'N/A', 'DF'];
  pieChartType: string = 'pie';
  pieChartColors: Array<any> = [{
    backgroundColor: ['#f54296', '#ebe834', '#3D8B37', '#eb5334', '#87CEFA', '#dd42f5']
  }];
  chartData: number[] = new Array();
  pieChartOptions: ChartOptions = {
    responsive: false,
    legend: {
      position: 'left',
    },
  };
  datePipeFormat='yyyy-MM-dd';
  toggleTestApproach = false;
  toggleConclusion = false;
  conclusion:string="";
  testApproach:string=""
  isTestApproach:boolean=false;
  isTestApproachEdit:boolean=false;
  isUserInWorkFlow:boolean=false;
  timerTrackingDTO:TaskTimerTrackingDTO = new TaskTimerTrackingDTO();
  modal: ProjectTaskDTO = new ProjectTaskDTO();
  permissionModal: Permissions=new Permissions(this.permissionConstant,false)
  docLevelUserList: any=[];
  assignedUsers:any[] = new Array();
  currentTaskID: any;
  constructor(public config: ConfigService, private projectsetupService: projectsetupService,public helper:Helper, public taskCretionervice: TaskCreationService,
    public dashboardService: DashBoardService, private taskCreationService: TaskCreationService,private servie: DateFormatSettingsService,
     public router: Router, public projectSummaryService: ProjectSummaryService, public workflowService: WorkflowConfigurationService,private iqService:IQTCService) { }

  ngOnInit() {
    this.loadOrgDateFormatAndTime();
    this.config.loadCurrentUserDetails().subscribe(response => {
      this.currentUser = response;
      this.loaddata();
    });
    let docList = [this.permissionConstant];
    this.config.isUserInWorkFlow(docList).subscribe( resp =>{
      this.isUserInWorkFlow = resp;
    });
  }
  loaddata() {
    this.spinnerFlag = true;
    this.chartData = new Array();
    this.projectsetupService.loadDocumentSummary(this.permissionConstant).subscribe(jsonResp => {
      this.spinnerFlag = false;
      if (jsonResp.result != null) {
        this.documentDetails = jsonResp.result;
        this.calculatePercentage(this.documentDetails.published, this.documentDetails.completed);
        this.checkdocumentIslockOrNotForIcon();
        if(this.documentDetails.documentType == '108' || this.documentDetails.documentType == '109' || this.documentDetails.documentType == '110'){
          this.config.loadPermissionsBasedOnModule(this.documentDetails.documentType).subscribe(resp=>{
            this.permissionModal=resp;
          })
          if(this.getcountExists(this.documentDetails.runCount) || this.getcountExists(this.documentDetails.testCaseInProgressCount)
          || this.getcountExists(this.documentDetails.passCount) || this.getcountExists(this.documentDetails.failCount)
          || this.getcountExists(this.documentDetails.nacount)  || this.getcountExists(this.documentDetails.discrepancyCount)){
            this.chartData.push(this.documentDetails.runCount);
            this.chartData.push(this.documentDetails.testCaseInProgressCount);
            this.chartData.push(this.documentDetails.passCount);
            this.chartData.push(this.documentDetails.failCount);
            this.chartData.push(this.documentDetails.nacount);
            this.chartData.push(this.documentDetails.discrepancyCount);
          }
        }
      }
    },
      err => {
        this.spinnerFlag = false;
      }
    );
  }
getcountExists(value:number):boolean{
  return value > 0;
}
  loadStepperData(doc:DocumentSummaryDTO) {
    this.docName=doc.documentName;
    let list = new Array();
    if (doc.formGroupConstants.length != 0) {
      list = doc.formGroupConstants;
    } else {
      list[0] = { key: doc.documentType, value: "", displayOrder: 0 }
    }
    this.loadStepperList = new Array();
    list.forEach(element => {
      let stepperModule = new StepperClass();
      stepperModule.constantName = element.key;
      this.dashboardService.loaddocumentStepper(stepperModule).subscribe(response => {
        this.loadStepperList.push({ docName: element.value, stepperList: response, displayOrder: element.displayOrder })
        if (this.loadStepperList.length == list.length) {
          this.loadStepperList.sort((a, b) => a.displayOrder - b.displayOrder);
        }
      },
        err => {
          this.spinnerFlag = false;
        }
      );
    });
  }
  loadTaskData() {
    this.taskCreationService.loadTasksForDocument(this.permissionConstant).subscribe(res => {
      if (res.pendingList) {
        this.pendingTaskList = res.pendingList;
      }
    },
      err => {
        this.spinnerFlag = false;
      }
    );
  }

  startTime(row:any){
    this.spinnerFlag = true;
    var today = new Date();
     var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
     var month = today.getMonth() + 1;
     var date = today.getFullYear() + "-" +month + "-" +today.getDate() + " " + time;
     this.timerTrackingDTO.projectTaskId = row.id;
     this.timerTrackingDTO.startTimer = time;
     this.timerTrackingDTO.endTimer = "";
     this.timerTrackingDTO.activeFlag = "Y";
     this.timerTrackingDTO.startDate = date;
     this.timerTrackingDTO.endDate = "";
     this.taskCretionervice.saveTimer(this.timerTrackingDTO).subscribe(result =>{
       if(result.result == "success"){
         this.loadTaskData();
         this.spinnerFlag = false;
      swal({
        title: row.taskCode + " Start at " + time,
        text: 'Task started.',
        type: 'success',
        timer: this.helper.swalTimer,
        showConfirmButton: true,
      });
    }else{
      this.spinnerFlag = false;
      swal({
        title: 'error',
        text: 'Oops, something went wrong',
        type: 'error',
        timer: this.helper.swalTimer,
        showConfirmButton: true,
      });
    }
     });
  }

  endTime(row:any){
    this.spinnerFlag = true;
    var today = new Date();
    var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
    var month = today.getMonth() + 1;
    var date = today.getFullYear() + "-" +month + "-" +today.getDate()+ " " +time;
    this.timerTrackingDTO.projectTaskId = row.id;
     this.timerTrackingDTO.endTimer = time;
     this.timerTrackingDTO.startTimer = "";
     this.timerTrackingDTO.startDate = "";
     this.timerTrackingDTO.activeFlag = "N";
     this.timerTrackingDTO.endDate = date;
     this.taskCretionervice.saveTimer(this.timerTrackingDTO).subscribe(result =>{
      if(result.result == "success"){
        this.spinnerFlag = false;
        this.loadTaskData();
      swal({
        title: row.taskCode + " End at " + time,
        text: 'Task Ended.',
        type: 'success',
        timer: this.helper.swalTimer,
        showConfirmButton: true,
      });
    }else{
      this.spinnerFlag = false;
      swal({
        title: 'error',
        text: 'Oops, something went wrong',
        type: 'error',
        timer: this.helper.swalTimer,
        showConfirmButton: true,
      });
    }
     });
  }
  
  calculatePercentage(totalSum, value) {
    if (totalSum == 0 && value == 0)
      this.percentage = 0;
    else
      this.percentage = Math.floor(value / totalSum * 100);
    this.progressBarColour = this.percentage == 100 ? "progress-bar bg-success" : "progress-bar";
  }
  redirect(row) {
    this.router.navigate(["taskCreation"], { queryParams: { id: row.id, url: '/'+row.url } })
  }

  editTask(row){
    this.router.navigate(["taskCreation"], { queryParams: { id: row.id, url: '/'+'editTask' } })
  }

  freezeOrUnFreeze() {
    this.spinnerFlag = true;
    this.projectSummaryService.docLockPermissions(this.permissionConstant, this.currentUser.versionId).subscribe(rsp => {
      if (rsp) {
        this.spinnerFlag = false;
        swal({ title: 'Sorry!', text: 'This Document is freezed for next version; cannot be unlocked', timer: 4000, showConfirmButton: false });
      } else {
        this.documentlockDataLogs = [];
        this.checkifdocumentIsLockedService().then((result) => {
          this.freezeData.documentConstantName = this.permissionConstant;
          if (this.freezeData.lockLogs.length > 0)
            this.documentlockDataLogs.push(...this.freezeData.lockLogs);
          this.freezeModalData.show();
          this.spinnerFlag = false;
        }).catch((err) => {
        });
      }
    });
  }
  checkifdocumentIsLockedService(): Promise<void> {
    return new Promise<void>(resolve => {
      this.projectSummaryService.docLockStatus(this.permissionConstant, this.currentUser.versionId).subscribe(jsonResp => {
        this.freezeData = jsonResp;
        resolve()
      }, err => {
        this.spinnerFlag = false;
      }
      );
    });
  }
  saveDocumentLockAndUnlock() {
    this.freezeData.documentLock = !this.freezeData.documentLock;
    this.workflowService.documentLockUnlock(this.freezeData).subscribe(resp => {
      swal({ title: 'Success', text: this.freezeData.documentName + ' has been' + ((this.freezeData.documentLock) ? ' locked' : ' Unlocked'), type: 'success', timer: 2000, showConfirmButton: false })
      this.freezeOrUnFreeze();
    });
  }
  checkdocumentIslockOrNotForIcon() {
    if (!this.documentDetails.freezeFlag) {
      this.spinnerFlag=true;
      this.projectSummaryService.docLockPermissions(this.documentDetails.documentType, this.currentUser.versionId).subscribe(rsp => {
        if (rsp) {
          this.spinnerFlag = false;
          this.documentDetails.freezeFlagIcon = true;
        } else {
          this.documentlockDataLogs = [];
          this.checkifdocumentIsLockedService().then((result) => {
            if (this.freezeData.lockLogs.length > 0)
              this.documentDetails.freezeFlagIcon = this.freezeData.lockLogs[0].status;
            else
              this.documentDetails.freezeFlagIcon = false;
            this.spinnerFlag = false;
          }).catch((err) => {
          });
        }
      });
    }
  }
  loadOrgDateFormatAndTime() {
    this.servie.getOrgDateFormat().subscribe(result => {
        if (!this.helper.isEmpty(result)) {
          this.datePipeFormat=result.datePattern.replace("mm", "MM")
          this.datePipeFormat=this.datePipeFormat.replace("YYYY", "yyyy");
        }
    });
}

  close(){
    this.onCloseSummary.emit();
  }
 
  saveTestCaseSummary(){
    let dto=new TestCaseSummaryDTO();
    dto.docType=this.documentDetails.documentType;
    dto.testApproach=this.testApproach;
    dto.conclusion=this.conclusion;
    this.spinnerFlag=true;
    this.iqService.saveTestCaseSummary(dto).subscribe(resp =>{
      this.spinnerFlag=false;
      this.loadTestCaseSummary();
      swal({
        title:'Success',
        text:'TestCase Summary Saved successfully',
        type:'success',
        timer:2000,
        showConfirmButton:false
      });
    }, err => {
      this.spinnerFlag=false;
      swal({
        title: 'Error', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false,
        text: type+' has not  been saved.',
      }
      );
    });
  }
  loadTestCaseSummary(){
    this.isTestApproachEdit=false;
    this.isTestApproach=false;
    this.spinnerFlag=true;
    this.iqService.loadTestCaseSummary(this.documentDetails.documentType).subscribe(resp =>{
      this.spinnerFlag=false;
      if(!this.helper.isEmpty(resp.result)){
        if(!this.helper.isEmpty(resp.result.testApproach) || !this.helper.isEmpty(resp.result.conclusion)){
          this.testApproach=resp.result.testApproach;
          this.conclusion=resp.result.conclusion;
          this.isTestApproach=true;
        }else{
          if(this.permissionModal.createButtonFlag && this.permissionModal.userInWorkFlow)
            this.isTestApproachEdit=true;
        }
      }else{
        if(this.permissionModal.createButtonFlag && this.permissionModal.userInWorkFlow){
          this.isTestApproachEdit=true;
        }
      }
    });
  }
  editTestApproach(){
    this.isTestApproachEdit=true;
    this.isTestApproach=false;
  }

  getLevelUsers(row: any) {
    if (!this.helper.isEmpty(row)) {
      this.currentTaskID = row.id;
      this.docLevelUserList = row.userDTO.map(m => ({ value: m.organizationId, label: m.firstName }));
      let usernameList = row.selectedUserNames.split(',');
      this.assignedUsers=new Array();
      usernameList.forEach(item => {
        this.docLevelUserList.forEach(data => {
          if(item === data.label)
          this.assignedUsers.push(data.value);
        });
      });
    }
  }

  reAssignUsers(){
    this.taskCretionervice.loadTasksBasedOnId(this.currentTaskID).subscribe(resp=>{
      let taskData = resp.dto;
      taskData.selectedUsers = this.assignedUsers;
      taskData.userDTO = [];
      this.modal = taskData;
      this.taskCreationService.reAssignTaskUsers(this.modal).subscribe(jsonRep =>{
        if (jsonRep.result === "success") {
          swal({
            title: '',
            text: 'Users Added Successfully',
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton: false,
          });
        this.loadTaskData();
        }
      })
    });
  }
}
