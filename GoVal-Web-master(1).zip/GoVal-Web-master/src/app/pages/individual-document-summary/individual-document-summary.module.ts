import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../shared/shared.module';
import { Helper } from '../../shared/helper';
import { ConfigService } from '../../shared/config.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { projectsetupService } from '../projectsetup/projectsetup.service';
import { IndividualDocumentSummaryComponent } from './individual-document-summary.component';
import { DashBoardService } from '../dashboard/dashboard.service';
import { TaskCreationService } from '../task-creation/task-creation.service';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DocumentForumModule } from '../document-forum/document-forum.module';
import { WorkflowConfigurationService } from '../workflow-configuration/workflow-configuration.service';
import { ProjectSummaryService } from '../project-summary/project-summary.service';
import { ChartsModule } from 'ng2-charts';
import { tableReportModule } from '../table-report/table-report.module';
import { QuillEditorModule } from 'ngx-quill-editor';
import { UiSwitchModule } from 'ng2-ui-switch';
import { IQTCService } from '../iqtc/iqtc.service';
import { SelectModule } from 'ng-select';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    UiSwitchModule,
    QuillEditorModule,
    SelectModule,
    NgxDatatableModule,DocumentForumModule,ChartsModule,tableReportModule
  ],
  exports:[IndividualDocumentSummaryComponent],
  declarations: [IndividualDocumentSummaryComponent],
  providers : [Helper,ConfigService,projectsetupService,DashBoardService,TaskCreationService,ProjectSummaryService,WorkflowConfigurationService,IQTCService,TaskCreationService],
})
export class IndividualDocumentSummaryModule { }
