import { SharedModule } from '../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { FormsModule } from '@angular/forms';
import { Helper } from '../../shared/helper';
import { HttpModule } from '@angular/http';
import {AuthGuardService} from '../../layout/auth/AuthGuardService';
import { SharedCommonModule } from '../../shared/SharedCommonModule';
import { MainmenuComponent } from './mainmenu.component';


export const MainMenuRoutes: Routes = [
    {
        path: '',
        component: MainmenuComponent,
        canActivate: [ AuthGuardService ],
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( MainMenuRoutes ),
        SharedModule,
        NgxDatatableModule,
        FormsModule,
        HttpModule,
        SharedCommonModule
    ],
    declarations: [],
    providers: [Helper]
} )
export class MainMenuModule { }
