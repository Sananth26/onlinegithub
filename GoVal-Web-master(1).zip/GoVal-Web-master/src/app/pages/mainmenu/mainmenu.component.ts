import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ISubscription } from '../../../../node_modules/rxjs/Subscription';
import { AdminComponent } from '../../layout/admin/admin.component';
import { ConfigService } from '../../shared/config.service';
import { Permissions } from '../../shared/config';
import { Helper } from '../../shared/helper';
import { UserPrincipalDTO } from '../../models/model';

@Component({
  selector: 'app-mainmenu',
  templateUrl: './mainmenu.component.html',
  styleUrls: ['./mainmenu.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MainmenuComponent implements OnInit {
  subscription: ISubscription
  permissionData: any
  public modalpermission = new Permissions(this.helper.DocumentStatus,false);
  menuData:  any[];
  documentList: any[];
  projectName:any;
  isFlag:boolean=true;
  isAdmin:boolean=false;
  currentUser:UserPrincipalDTO=new UserPrincipalDTO();
  isPeriodicReviewModuleExists:boolean=false;
  orgModulePermissions = new Array();
  dashboardLink:string  = "/dashboard"
  iconsarray: any = {
    "100": "icofont-gears",
    "107": "icofont-share",
    "108": "icofont-test-tube",
    "109": "icofont-test-bulb",
    "110": "icofont-test-tube-alt",
    "113": "icofont-chart-radar-graph",
    "114": "icofont-chart-flow-2",
    "128": "icofont-document-folder",
    "129": "icofont-table",
    "102":"icofont-chart-radar-graph"

  };
    // order: any = {
    //   "100": 1,
    //   "107": 2,
    //   "108": 3,
    //   "109": 5,
    //   "110": 4,
    //   "113": 6,
    //   "114": 9,
    //   "128": 8,
    //   "129": 7,
    //   "102":10

    // };
  colorarray: any = {
    "100": "btn-outline-primary  bg-white ",
    "107": "btn-outline-danger   bg-white ",
    "108": "btn-outline-warning  bg-white ",
    "109": "btn-outline-inverse  bg-white ",
    "110": "btn-outline-disabled bg-white ",
    "113": "btn-outline-success  bg-white ",
    "114": "btn-outline-warning  bg-white ",
    "128": "btn-outline-primary  bg-white ",
    "129": "btn-outline-inverse  bg-white ",
    "102":"btn-outline-inverse  bg-white "
  };


  constructor(private adminComponent: AdminComponent, private permissionService: ConfigService,public helper:Helper  ) {
    this.loadpermission();
    this.adminComponent.setUpModuleForHelpContent("");
    this.adminComponent.taskEnbleFlag = true;
    this.subscription = this.adminComponent.globalProjectObservable.subscribe(
      data => {
        this.isFlag=true;
        this.loaddata()

  })

}

  ngOnInit() {
    this.loadOrgPermission(); 
    this.permissionService.loadCurrentUserDetails().subscribe(resp => {
      this.currentUser=resp;
      this.isAdmin = this.currentUser.adminFlag=='A';
  });
  this.checkPeriodicReviewModulePermissions();
}
  loaddata() {
    this.projectName=this.currentUser.projectName;
    this.menuData = new Array<any>();
    this.documentList = new Array<any>();
    this.permissionService.loadPermissionForLoggedInUser().subscribe(resp => {
      let name = null;
      let color = null;
      let icon = null;

      resp.list.filter(  doc => doc.categoryName == this.helper.categoryDocumentList && doc.displayOrder )
      {}


      resp.list.filter(doc => doc.permissionValue == this.helper.Dashboard).forEach(data => {
        if(this.individualPermissions(data))
        {
          let projectNamedatas:any;
          projectNamedatas={
            projectName:data.permissionTitle,
            projectLink:this.helper.routelinks[data.permissionValue]
          }

          this.menuData.push(projectNamedatas)
        }

      });
      resp.list.filter(doc => doc.permissionValue == this.helper.DocumentStatus).forEach(data => {
        if(this.individualPermissions(data))
        {
          let  documentStatusdatas:any;
          documentStatusdatas={
            documentStatusName:data.permissionTitle,
            documentStatusLink:this.helper.routelinks[data.permissionValue]
          }

          this.menuData.push( documentStatusdatas)
        }

      });
      let datasForMasterDataSetup:any;

      resp.list.filter(  doc => doc.categoryName == this.helper.categoryDocumentList && doc.displayOrder ).forEach(element => {

         if(this.individualPermissions(element))
        {

          if(this.iconsarray[element.permissionValue])
          {

            datasForMasterDataSetup={

              name:element.permissionTitle,
              order:Number(element.displayOrder),
              title:element.permissionValue,
              color:this.colorarray[element.permissionValue],
              icon:this.iconsarray[element.permissionValue],
              link:this.helper.routelinks[element.permissionValue]

            }
            this.documentList.push(datasForMasterDataSetup)
          }



        }
      });
      datasForMasterDataSetup=null;
      resp.list.filter(doc => doc.categoryName == this.helper.categoryLink).forEach(element => {
        if(this.individualPermissions(element))
       {
        if(element.permissionValue!=this.helper.Dashboard && element.permissionValue!=this.helper.DocumentStatus)
        {
         if(this.helper.routelinks[element.permissionValue])
         {

          datasForMasterDataSetup={

             name:element.permissionTitle,
             order:Number(element.displayOrder),
             title:element.permissionValue,
             color:this.colorarray[element.permissionValue],
             icon:this.iconsarray[element.permissionValue],
             link:this.helper.routelinks[element.permissionValue]

           }

           this.documentList.push(datasForMasterDataSetup)
         }


       }
      }
     });
    // this.menuData.push(this.documentList)


     this.menuData.push(this.documentList.sort((obj1, obj2) => {
      if (obj1.order > obj2.order) {
          return 1;
      }

      if (obj1.order < obj2.order) {
          return -1;
      }

      return 0;
  }))

      this.isFlag=false;
    });
  
  }


  individualPermissions(element:Permissions) {
    if (element.workFlowButtonFlag ||
      element.viewButtonFlag ||
      element.deleteButtonFlag ||
      element.updateButtonFlag ||
      element.importButtonFlag ||
      element.createButtonFlag ||
      element.exportButtonFlag) {
      return true;
    }
    else {
      return false;
    }
  }
  loadOrgPermission(){
    this.permissionService.loadOrgModules().subscribe(resp =>{
       this.orgModulePermissions = resp;
    });
  }
  loadpermission() {
    this.permissionService.loadPermissionForLoggedInUser().subscribe(resp => {
      this.permissionData = resp.list;
      this.individualPermissionsresult(this.helper.DocumentStatus);
    });
  }
  individualPermissionsresult(typeId: any) {
    if (this.permissionData == null || this.permissionData == undefined) {
      return false;
    } else {
      this.permissionData = this.permissionData.filter(p => p.permissionValue == typeId);
      if (this.permissionData.length != 0) {
        this.modalpermission = this.permissionData[0];
      } else {
        this.modalpermission = new Permissions(typeId, false);
      }
      return this.modalpermission.viewButtonFlag;
    }
    
  }
  checkPeriodicReviewModulePermissions() {
    this.permissionService.checkIndividualModulePermission(this.helper.PERIODIC_REVIEW).subscribe(resp => {
      this.isPeriodicReviewModuleExists = resp;
    });
  }
}
