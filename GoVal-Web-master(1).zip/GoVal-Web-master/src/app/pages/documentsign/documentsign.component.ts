import { animate, style, transition, trigger } from '@angular/animations';
import { Component, Input, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { Router } from '@angular/router';

import { IOption } from 'ng-select';
// tslint:disable-next-line: import-blacklist
import { Observable } from 'rxjs';
import swal from 'sweetalert2';
import { User, UserPrincipalDTO } from '../../models/model';
import { ConfigService } from '../../shared/config.service';
import { eSignErrorTypes } from '../../shared/constants';
import { Helper } from '../../shared/helper';
import { ModalAnimationComponent } from '../../shared/modal-animation/modal-animation.component';
import { DashBoardService } from '../dashboard/dashboard.service';

@Component({
  selector: 'app-documentsign',
  templateUrl: './documentsign.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./documentsign.component.css', '../../../../node_modules/sweetalert2/dist/sweetalert2.min.css']
  ,

  animations: [
    trigger('fadeInOutTranslate', [
      transition(':enter', [
        style({opacity: 0}),
        animate('400ms ease-in-out', style({opacity: 1}))
      ]),
      transition(':leave', [
        style({transform: 'translate(0)'}),
        animate('400ms ease-in-out', style({opacity: 0}))
      ])
    ])
  ]
})
export class DocumentsignComponent implements OnInit, OnDestroy {

  public subscription;
  @Input() data: any=null;
  @Input() stepperData: any;
  @ViewChild('documentEsign') documentEsign:ModalAnimationComponent;

  // tslint:disable-next-line: max-line-length
  constructor(public config: ConfigService, private http: Http, private configService: ConfigService,
     public router: Router, public esignErrors: eSignErrorTypes, public helper: Helper, public dashboardService: DashBoardService,public fb: FormBuilder) { }
  public documentlist:any[]= new Array<any>();
  public modal: User = new User();
  public summaryorindividual:Boolean=false;
  public docSignselectList: Array<IOption> = new Array<IOption>();
  public esignForm = null;
  public finalstatus: boolean=true;
  public comments:any="";
  public esignSpinnerFlag=false;
  public esignButtonEnabled: Boolean = false;
  public errorList: any[]= new Array<any>();
  submitted: boolean = false;
  @Input() closeFlag = true;
  currentUser: UserPrincipalDTO= new UserPrincipalDTO();

  ngOnInit() {
    if  ( null === this.data) {
      this.summaryorindividual = true;
    }

    if (null != this.stepperData) {
      const result = this.stepperData.filter(t => t.lastEntry);
      if (null != result) {
        this.data =  result[0].workflowDto;
        this.data.actionTypeName = "Esign"
      }
     }
    this.esignForm = this.fb.group({
      userName: [this.modal.email, [Validators.required]],
      password: [this.modal.password, [Validators.required]],
      comments: [this.modal.dob, [Validators.required]],
    });
  }
  changestatus(status){
    this.documentlist.forEach(element => {
      element.comments = this.esignForm.get('comments').value;
    });
  }
  ngOnDestroy() {
  }

  clickFilter(event): void {
    this.helper.filter(event);
  }

  Api(data, url) {
    return this.http.post(this.helper.common_URL + url, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  esign() {
    this.esignSpinnerFlag=true;
    this.documentEsign.spinnerShow();
    this.loadDocumentList(this.data);
    this.Api(this.modal, 'workFlow/validEsignUser').subscribe(response => {
    if (response.flag) {
      this.esignSpinnerFlag=true;
      
      if(null!=this.documentlist)
      {
        this.documentlist.forEach(element => {
          element.comments = this.comments;
          element.approvedFlag = this.finalstatus
        });
        this.Api(this.documentlist, 'workFlow/approveOrReject').subscribe(res => {
          this.comments = "";
          this.finalstatus = false;
          this.helper.changeMessageforId('data');
          
          if (res.dataType === 'Multiple access for same Data') {
            swal({
              title: '',
              text: 'Multiple access for same Data reload the page',
              type: 'warning',
              timer: this.helper.swalTimer,
              showConfirmButton: false
            });
          } else {
            swal({
              title: '',
              text: 'Esign validated',
              type: 'success',
              timer: this.helper.swalTimer,
              showConfirmButton: false
            });

      }
          setTimeout(() => {
            if (null != this.data && this.data.length === undefined) {
              this.helper.filter(this.data.documentId);
            }
            this.esignSpinnerFlag = false;
            this.documentEsign.spinnerHide();
            document.querySelector('#' + 'effect-1').classList.remove('md-show');
          }, 1000);
        });
    }
    } else {
      this.esignSpinnerFlag = false;
      this.errorList = response.errorList;
      this.documentEsign.spinnerHide();
    }
    });
  
  }

  onSubmit(esignForm) {
    if (esignForm.valid) {
      this.esignSpinnerFlag=true;
      this.submitted=false;
      this.modal.userName = this.esignForm.get('userName').value;
      this.modal.password = this.esignForm.get('password').value;
      this.comments=this.esignForm.get('comments').value;
      this.esign();
    }else
    this.submitted=true;
  }

  openMyModal(event) {
    if(this.closeFlag){
      this.finalstatus=true;
      this.submitted=false;
      document.querySelector('#' + event).classList.add('md-show');
      setTimeout(() => {
        $('#workFlowCommentsId').focus();
      }, 1000);
    }
  }

  closeMyModal(event) {
    this.errorList = new Array();
    this.esignForm.reset();
    if(document.querySelector('#' + event))
      document.querySelector('#' + event).classList.remove('md-show');
  }

  loadDocumentList(data: any) {
    if ( null != data && data.length === undefined) {
      const dd: any[] = new Array<any>();
      data.approveFlag = true;
      dd.push(data);
      this.documentlist  = dd;
    } else {
      this.documentlist = data ;
    }

  }
  // checkComment(comment:any){
  //  if(!this.helper.isEmpty(comment)&&comment.length>=500)
  //   this.commentLengthValMsg = 'max length '+comment.length+', characters only!';
  //   else
  //   this.commentLengthValMsg = '';
  // }

}
