import { NgModule } from '@angular/core';
import { SelectModule } from 'ng-select';
import { DocumentsignComponent } from './documentsign.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { QuillEditorModule } from 'ngx-quill-editor';
import { FormWizardModule } from 'angular2-wizard';
import { DashBoardService } from '../dashboard/dashboard.service';
import { eSignErrorTypes } from '../../shared/constants';




@NgModule( {
    imports: [
        FormsModule,
        SelectModule,
        CommonModule,
        SharedModule,
        QuillEditorModule,
        FormWizardModule,
        ReactiveFormsModule,
    ],
    exports:[DocumentsignComponent],
    declarations: [DocumentsignComponent],
    providers:[DashBoardService,eSignErrorTypes]


} )
export class DocumentsignComponentModule { }
