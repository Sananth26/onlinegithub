import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import swal from 'sweetalert2';
import { CommonFileFTPService } from '../common-file-ftp.service';
import { PDFViewerModule } from '../pdf-viewer/pdf-viewer.module';


@Component({
  selector: 'file-view',
  encapsulation:ViewEncapsulation.None,
  templateUrl: './file-view.component.html',
  styleUrls: ['./file-view.component.css','./../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],

})
export class FileViewComponent implements OnInit {
  fileName;
  pdfSrc;
  showModal: boolean=false;
  height:any="600px";
 
  constructor(private commonService: CommonFileFTPService) { }

  ngOnInit() {
  }

  downloadFileOrView(fileName: string, filePath: string, viewFlag: boolean, fileViewTitle?) {
    if (viewFlag)//show modal ob view
      this.showModal=true;
   // this.fileViewerModal.spinnerShow();
    this.commonService.loadFile(filePath).subscribe(resp => {
      const contentType = this.commonService.getContentType(fileName.split(".")[fileName.split(".").length - 1]);
      const blob: Blob = new Blob([resp], { type: contentType });
      this.createIframeBlob(viewFlag, fileName, blob, contentType,filePath);
    }, err => {
        swal({
          title: 'Error', type: 'info', timer: 2000, showConfirmButton: false,
          text: 'No such file found'
        });
     // this.fileViewerModal.spinnerHide();
      this.showModal=false;
    });
  }

  previewByBlob(fileNameWithExtention: string, blobResponse: any, viewFlag: boolean, fileViewTitle?) {
    if (viewFlag)//show modal ob view
      this.showModal=true;
      //this.fileViewerModal.show(); 
   // this.fileViewerModal.spinnerShow();
    const contentType = this.commonService.getContentType(fileNameWithExtention.split(".")[fileNameWithExtention.split(".").length - 1]);
    const blob: Blob = new Blob([blobResponse], { type: contentType });
    this.createIframeBlob(viewFlag, fileNameWithExtention, blob, contentType);
  }
  public previewOrDownloadByBase64(fileName: string, base64String: string, viewFlag: boolean, fileViewTitle?: string) {
    if (viewFlag)//show modal ob view
      this.showModal=true;
      //this.fileViewerModal.show();
    //this.fileViewerModal.spinnerShow();
    const contentType = this.commonService.getContentType(fileName.split(".")[fileName.split(".").length - 1]);
    var response: any[] = this.b64toBlob(base64String)
    const blob: Blob = new Blob(response, { type: contentType });
    this.createIframeBlob(viewFlag, fileName, blob, contentType);
  }

  private createIframeBlob(viewFlag, fileName:string, blob, contentType,filePath?:string) {
    if (viewFlag) {
      if (contentType.toLowerCase().match("video/mp4") || contentType.toLowerCase().match("video/webm")) {
        //veiwing video without scolling
        this.createIFrame(URL.createObjectURL(blob),fileName,'450px');
      } else if (fileName.toLowerCase().includes(".xls")) {
        this.commonService.convertExcelToPDF(filePath).subscribe(resp => {
          const contentType = this.commonService.getContentType("pdf");
          const blob: Blob = new Blob([resp], { type: contentType });
          this.createIFrame(URL.createObjectURL(blob),
          fileName.replace(fileName.split(".")[fileName.split(".").length - 1],"pdf"));
        }, err => {
            swal({
              title: 'Unable To View', type: 'info', timer: 2000, showConfirmButton: false,
              text: 'Please download'
            });
            // this.fileViewerModal.spinnerHide();
            // this.fileViewerModal.hide();
            this.showModal=false;
        });
        // this.download(blob,fileName).then(()=>{
        //   this.fileViewerModal.spinnerHide();
        //   this.fileViewerModal.hide();
        //   swal({
        //     title: 'Please find the Downloaded File', type: 'info', timer: 3000, showConfirmButton: false,
        //     html: `<label style="color:red">View Not Supported for this file type</label>`
        //   });
        // }).catch(()=> { this.fileViewerModal.spinnerHide();
        // this.fileViewerModal.hide();});
      } else if (!contentType.toLowerCase().match(".pdf")) {
        this.commonService.convertFileToPDF(blob, fileName).then((respBlob) => {
          this.createIFrame(URL.createObjectURL(respBlob),
          fileName.replace(fileName.split(".")[fileName.split(".").length - 1],"pdf"));
        }).catch(()=>{
          swal({
            title: 'Unable To View', type: 'info', timer: 2000, showConfirmButton: false,
            text: 'Please download'
          });
          // this.fileViewerModal.spinnerHide();
          // this.fileViewerModal.hide();
          this.showModal=false;
        });
      } else {
        this.createIFrame(URL.createObjectURL(blob),fileName);
        
      }
    } else {
      this.download(blob,fileName).then(()=>{
        // this.fileViewerModal.spinnerHide();
      });
    }
  }

  private download(blob, fileName):Promise<void> {
    return new Promise<void>(resolve=>{
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, fileName);
      } else {
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = fileName;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      }
      resolve();
    })
   
    
  }

  private createIFrame(blob_url: string,fileName:string ,height?: string) {
    this.height=height ? height : (window.innerHeight - 100)+"px"
     debugger
    this.fileName=fileName;
    if(fileName.includes(".pdf")){
      this.pdfSrc=blob_url;
    }else{
      var iframe;
      var elementExists = document.getElementById('iframeView');
      if (!elementExists)
        iframe = document.createElement('embed');
      else
        iframe = elementExists;
      iframe.setAttribute('id', 'iframeView')
      iframe.setAttribute("height",this.height);
      iframe.setAttribute("width", "100%");
      iframe.src = blob_url + '#zoom=113&pagemode=thumbs';
      const find = document.querySelector('#fileUploadId');
      find.setAttribute('class', 'well well-lg row');
      find.appendChild(iframe);
    }
   

   
    // this.fileViewerModal.spinnerHide();

  }

  private closeFileView() {
    var elementExists = document.getElementById('iframeView');
    if (elementExists) {
      elementExists.remove();
      const find = document.querySelector('#fileUploadId');
      find.removeAttribute('class')
    }
 //   this.fileViewerModal.hide();
    this.showModal=false;
  }

  private b64toBlob(b64Data) {
    var sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    return byteArrays;
  }
  close(){
    this.showModal=false;
    this.closeFileView();
  }

  
}
