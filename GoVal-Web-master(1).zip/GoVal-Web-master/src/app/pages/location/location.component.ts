import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { LocationService } from './location.service';
import { Location } from './../../models/model';
import swal from 'sweetalert2';
import { Helper } from './../../shared/helper';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Permissions } from './../../shared/config';
import { AdminComponent } from '../../layout/admin/admin.component';
import { IOption } from 'ng-select';
import { ConfigService } from '../../shared/config.service';
import { locationValidationMsg } from '../../shared/constants';
@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.css', './../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class LocationComponent implements OnInit {
  @ViewChild('myTable') table: any;
  public onLocationForm: FormGroup;
  public simpleOptionStep: Array<IOption> = new Array<IOption>();
  data: any;
  modal: Location = new Location();
  public rowsOnPage = 10;
  public filterQuery = '';
  spinnerFlag = false;
  iscreate: boolean = false;
  isUpdate: boolean = false;
  isSave: boolean = false;
  permissionsfromlocalstorage: any;
  permissionModal: Permissions = new Permissions("140",false);
  isValidName:boolean=false;
  submitted: boolean = false;
  constructor(public permissionService:ConfigService,private comp: AdminComponent,public fb: FormBuilder, public service: LocationService, public helper: Helper, private locationValMsg: locationValidationMsg) { }

  ngOnInit() {
    this.comp.setUpModuleForHelpContent("140");
    this.comp.taskDocType = "140";
    this.comp.taskDocTypeUniqueId = "";
    this.comp.taskEquipmentId = 0;
    this.loadAll();
    this.onLocationForm = this.fb.group({
      code: ['', Validators.compose([
        Validators.required
      ])],
      name: ['', Validators.compose([
        Validators.required
      ])],
      active: ['', Validators.compose([
      ])],
      steps : ['',],
    });
    this.permissionService.loadPermissionsBasedOnModule("140").subscribe(resp=>{
      this.permissionModal=resp
    }); 
  }
  onClickCreate() {
    this.isSave = true;
    this.iscreate = true;
    this.isUpdate= false;
    this.onLocationForm.reset();
    this.modal.id = 0;
    this.onLocationForm.get("active").setValue(true);
  }
  onChangeName(){
    this.isValidName=false;
    this.data.forEach(element => {
      if(element.name === this.onLocationForm.get("name").value && this.modal.id !=element.id)
        this.isValidName=true;
    });
  }
  onClickCancel() {
    this.iscreate = false;
    this.submitted = false;
  }

  loadAll() {
    this.spinnerFlag = true;
    this.service.loadStepList("LocationStep").subscribe(jsonResp => {
      this.simpleOptionStep = this.helper.cloneOptions(jsonResp.result);
    });
    this.service.loadLocation().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.data = response.result
      }
    }, error => { this.spinnerFlag = false });
  }

  editLocation(data:Location) {
    this.iscreate=true;
    this.isSave= false;
    this.isUpdate = true;
    this.modal=data;
    this.onLocationForm.get("active").setValue(data.active==='Y'?true:false);
    this.onLocationForm.get("code").setValue(data.code);
    this.onLocationForm.get("name").setValue(data.name);
    this.onLocationForm.get("steps").setValue(data.stepList);
  }

  openSuccessCancelSwal(dataObj, id) {
    var classObject = this;
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      classObject.deleteLocation(dataObj);
    });
  }

  deleteLocation(dataObj): string {
    let timerInterval;
    let status = '';
    let location = new Location();
    location.id = dataObj.id;
    this.service.deleteLocation(location)
      .subscribe((response) => {
        let responseMsg: string = response.result;
        if (responseMsg === "success") {
          swal({
            title:'Deleted!',
            text:'Location ' + dataObj.code + '  has been deleted.',
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              this.loadAll();
              clearInterval(timerInterval)
            }
          });
        } else {
          status = "failure";
          swal({
            title:'Not Deleted!',
            text:'Location ' + dataObj.code + '  has not been deleted.',
            type:'error',
            timer:this.helper.swalTimer,
            showConfirmButton:false
          }
          );
        }
      }, (err) => {
        status = "failure";
        swal({
          title:'Not Deleted!',
          text:dataObj.code + 'is not deleted...Something went wrong',
          type:'error',
          timer:this.helper.swalTimer,
            showConfirmButton:false
        });
      });
    return status;
  }
  onClickSave() {
    let timerInterval;
    if(!this.isValidName && this.onLocationForm.valid){
    this.spinnerFlag = true;
    this.submitted = false;
    this.modal.code=this.onLocationForm.get("code").value;
    this.modal.name=this.onLocationForm.get("name").value;
    this.modal.stepList = this.onLocationForm.get("steps").value;
    if(this.onLocationForm.get("active").value)
      this.modal.active="Y";
    else
      this.modal.active="N";

    this.service.createLocation(this.modal).subscribe(jsonResp => {
      this.spinnerFlag = false;
      let responseMsg: string = jsonResp.result;
      if (responseMsg === "success") {
        this.loadAll();
        let mes = 'New Location is created';
        if (this.isUpdate) {
          mes = "Location is updated"
        }
        swal({
          title:'',
          text:mes,
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false,
          onClose: () => {
            this.iscreate = false;
            clearInterval(timerInterval)
          }
        });
      } else {
        swal({
          title:'',
          text:'Something went Wrong ...Try Again',
          type:'error',
          timer:this.helper.swalTimer,
            showConfirmButton:false
        })
      }
    },
      err => {
        this.spinnerFlag = false
      }
    );
    }else{
      this.submitted = true;
      Object.keys(this.onLocationForm.controls).forEach(field => {
        const control = this.onLocationForm.get(field);            
        control.markAsTouched({ onlySelf: true });      
      });
    }
  }
  checkOnly(event)
{   
   var k;  
   k = event.charCode; 
   return((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57)); 
}
}
