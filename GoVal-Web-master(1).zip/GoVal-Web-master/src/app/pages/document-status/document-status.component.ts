import { Component } from '@angular/core';

@Component({
  selector: 'app-document-status',
  templateUrl: './document-status.component.html',
  styleUrls: ['./document-status.component.css'],
  // animations: [
  //   trigger('fadeInOutTranslate', [
  //     transition(':enter', [
  //       style({opacity: 0}),
  //       animate('400ms ease-in-out', style({opacity: 1}))
  //     ]),
  //     transition(':leave', [
  //       style({transform: 'translate(0)'}),
  //       animate('400ms ease-in-out', style({opacity: 0}))
  //     ])
  //   ])
  // ]
})

export class DocumentStatusComponent {
//   modalSpinner:boolean=false;implements OnInit 
//   @ViewChild('myTable') table: any;
//   public docItemList: any;
//   public Title: number = 0;
//   public notApprovedDocuments: any;
//   public documentList: Array<DocStatusList> = [];
//   public tempData: any;
//   public testCaseTypes: TestCaseType = new TestCaseType();
//   public rowsOnPage = 10;
//   public viewIndividualData: boolean = false;
//   public popupdata: any
//   public tempRowId: number;
//   public model: Permissions = new Permissions('',false);
//   public docNamePermissionId: string;
//   public approvedDocList: any;
//   public declinedDoclist: any;
//   public pendingDocList: any;
//   public docType: string;
//   public status: string;
//   public isFlag: boolean = true;
//   public type: string = '';
//   public permissionsfromlocalstorage: any;
//   public assessmentTemplateModal: any;
//   public riskAssesmentData: any;
//   public hideButtonFlag: boolean = false;
//   public StatusValue: string;
//   public slideIndex = 0;
//   selected = [];
//   saveAll: boolean = false;
//   subscription: any;
//   docStatus: any;
//   pdfSrc: Uint8Array;
//   totalNumberOfPdfPages: any;
//   pdfPage: any;
//   zoom: any = 1;
//   originalSize: boolean = true;
//   showAll: boolean = true;
//   dynamicTemplateModel: DynamicTemplateDto = new DynamicTemplateDto();
//   public documentStausChangeComments="";
// public currentDocType:any;
// public currentDocStatus:any;
// public currentCreatedBy:any;
// public currentModifiedDate:any;
// currentUser:UserPrincipalDTO=new UserPrincipalDTO();
// statusLog:any;
  constructor() {
    // private comp: AdminComponent,public projectService: projectsetupService,public helper: Helper,
    //  public lookUpService: LookUpService, public ursService: UrsService, public docStatusService: DocStatusService, 
    //  public iqtcService: IQTCService, public routers: Router, public riskAssessmentService: RiskAssessmentService, 
    //  public riskAssesstemplateService: RiskassesstemplateService, public dashboardService: DashBoardService,
    //   public adminComponent: AdminComponent, public configService: ConfigService,
    // public vendorService: VendorService, public dynamicTemplateService: DynamicTemplateService
    // this.subscription = this.adminComponent.globalProjectObservable.subscribe(
    //   data => {
    //     this.loaddata();
    //   },
    //   err => console.log(err),
    //   () => console.log('complete'),
    // );
    
  }

//   loaddata() {
//     this.individualPermissions("126");
//     this.docItemList = new Array<any>();
//     this.configService.loadPermissionsBasedOnModule("126").subscribe(resp=>{
//       this.model=resp
//     }); 
//     this.projectService.loadDocumentOrderList().subscribe(resp => {
//       resp.result.forEach(element => {
//         let tempDocItemList = { 'id': element.documentListId, 'name': element.documentListName }
//         this.docItemList.push(tempDocItemList);
//       });
//       });
//     this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType('').subscribe(jsonresp => {
//       this.loadDocStatusData(jsonresp);
//     });
//   }

//   ngOnInit() {
//     this.configService.loadCurrentUserDetails().subscribe(jsonresp => {
//       this.currentUser=jsonresp;
//     });
//     this.comp.setUpModuleForHelpContent("126");
//    }

//   toggleExpandRow(row) {
//     this.table.rowDetail.toggleExpandRow(row);
//   }

//   onChange(data: any) {
//     this.approvedDocList = [];
//     this.declinedDoclist = [];
//     this.pendingDocList = [];
//     this.documentList = [];
//     var docName = data.name;
//     this.docNamePermissionId = data.id;
//     this.isFlag = true;

//     this.configService.loadPermissionForLoggedInUser().subscribe(resp => {

//       let permission = resp.list
//       switch (docName) {
//         case "URS":

//           var ursPermisssion = permission.filter(dto => dto.permissionValue == 107);
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {
//             if (ursPermisssion[0].approvedButtonFlag) {
//               this.loadUrsData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadUrsData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//             }
//             if (ursPermisssion[0].esignButtonFlag) {
//               this.loadUrsData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadUrsData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (ursPermisssion[0].esignButtonFlag && ursPermisssion[0].approvedButtonFlag) {
//               this.loadUrsData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadUrsData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadUrsData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadUrsData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         case "IQTC":
//           var iqtcPermisssion = permission.filter(dto => dto.permissionValue == 108);
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {
//             if (iqtcPermisssion[0].approvedButtonFlag) {
//               this.loadIqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadIqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//             }
//             if (iqtcPermisssion[0].esignButtonFlag) {
//               this.loadIqtcData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadIqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (iqtcPermisssion[0].esignButtonFlag && iqtcPermisssion[0].approvedButtonFlag) {
//               this.loadIqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadIqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadIqtcData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadIqtcData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         case "PQTC":
//           var pqtcPermisssion = permission.filter(dto => dto.permissionValue == 109);
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {
//             if (pqtcPermisssion[0].approvedButtonFlag) {
//               this.loadPqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadPqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;

//             }
//              if (pqtcPermisssion[0].esignButtonFlag) {
//               this.loadPqtcData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadPqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (pqtcPermisssion[0].esignButtonFlag && pqtcPermisssion[0].approvedButtonFlag) {
//               this.loadPqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadPqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadPqtcData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadPqtcData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         case "OQTC":
//           var oqtcPermisssion = permission.filter(dto => dto.permissionValue == 110);

//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {

//             if (oqtcPermisssion[0].approvedButtonFlag) {
//               this.loadOqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadOqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//             } if (oqtcPermisssion[0].esignButtonFlag) {
//               this.loadOqtcData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadOqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (oqtcPermisssion[0].esignButtonFlag && oqtcPermisssion[0].approvedButtonFlag) {
//               this.loadOqtcData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadOqtcData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadOqtcData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadOqtcData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         case "Risk Assessment":
//           var riskAssessmentPermisssion = permission.filter(dto => dto.permissionValue == 113);
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {

//             if (riskAssessmentPermisssion[0].approvedButtonFlag) {
//               this.loadriskAssessmentData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadriskAssessmentData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//             } if (riskAssessmentPermisssion[0].esignButtonFlag) {
//               this.loadriskAssessmentData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadriskAssessmentData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (riskAssessmentPermisssion[0].esignButtonFlag && riskAssessmentPermisssion[0].approvedButtonFlag) {
//               this.loadriskAssessmentData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadriskAssessmentData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadriskAssessmentData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadriskAssessmentData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         case "Vendor Validation":
//           var vendorValidationPermisssion = permission.filter(dto => dto.permissionValue == 128);
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType(this.docNamePermissionId).subscribe(jsonresp => {
//             if (vendorValidationPermisssion[0].approvedButtonFlag) {
//               this.loadVendorValidationData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadVendorValidationData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//             } if (vendorValidationPermisssion[0].esignButtonFlag) {
//               this.loadVendorValidationData(jsonresp.ReviewPending);
//               this.pendingDocList = this.documentList;
//               this.loadVendorValidationData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.approvedDocList = this.documentList;
//             }
//             if (vendorValidationPermisssion[0].esignButtonFlag && vendorValidationPermisssion[0].approvedButtonFlag) {
//               this.loadVendorValidationData(jsonresp.ReviewCompeletedOrApprovePending);
//               this.pendingDocList = this.documentList;
//               this.loadVendorValidationData(jsonresp.Approve);
//               this.approvedDocList = this.documentList;
//               this.loadVendorValidationData(jsonresp.ReviewPending);
//               let value = this.pendingDocList.length;
//               for (let index = 0; index < this.documentList.length; index++) {
//                 this.pendingDocList[value + index] = this.documentList[index];
//               }
//             }
//             this.loadVendorValidationData(jsonresp.Rejected);
//             this.declinedDoclist = this.documentList;
//             this.isFlag = false;
//           },
//             err => {
//               this.isFlag = false;
//             }
//           );
//           break;
//         default:
//           var dynamicDocPermisssion = permission.filter(dto => dto.permissionValue == 132);
//           this.dynamicTemplateService.loadIndividualDynamicTempleteDataBasedOnTitleOrganisationAndDocumentStatus(data.name).subscribe(response => {
//             console.log(response.result);
//             if(response.result!=null){
//             let dynamicDocListData = response.result;
//             this.setDynamicTemplateData(dynamicDocListData);
//             if (dynamicDocPermisssion[0].approvedButtonFlag) {
//               if (dynamicDocListData.commonDocumentStatusValue == this.helper.ReviewCompeletedOrApprovePending)
//                 this.pendingDocList = this.documentList;
//               if (dynamicDocListData.commonDocumentStatusValue == this.helper.Approve)
//                 this.approvedDocList = this.documentList;
//             } if (dynamicDocPermisssion[0].esignButtonFlag) {
//               if (dynamicDocListData.commonDocumentStatusValue == this.helper.ReviewPending)
//                 this.pendingDocList = this.documentList;
//               if (dynamicDocListData.commonDocumentStatusValue == this.helper.ReviewCompeletedOrApprovePending)
//                 this.approvedDocList = this.documentList;
//             }
//             if (dynamicDocPermisssion[0].esignButtonFlag && dynamicDocPermisssion[0].approvedButtonFlag) {
//               if (dynamicDocListData.commonDocumentStatusValue == (this.helper.ReviewPending || this.helper.ReviewCompeletedOrApprovePending))
//                 this.pendingDocList = this.documentList;
//               else
//                 this.approvedDocList = this.documentList;
//             }
//           }
//           });
//           this.isFlag = false;

//       }
//     });
//   }

//   viewRowDetails(type: string, rowId: any) {
//     this.tempRowId = rowId;
//     this.docType = type;
//     this.popupdata = [];
//     if (this.currentUser.roleId== this.helper.Reviewer) {
//       this.hideButtonFlag = false;
//     }
//     if (this.currentUser.roleId == this.helper.Approver) {
//       this.hideButtonFlag = true;
//     }
//     switch (type) {
//       case "URS":
//         this.ursService.getDataForEdit(rowId).subscribe(jsonResp => {

//           if (jsonResp.result.approveFlag) {
//             this.hideButtonFlag = true;
//           } else {
//             this.hideButtonFlag = false;
//           }
//           this.popupdata.push(jsonResp.result);
//           this.viewIndividualData = true;
//           this.StatusValue = jsonResp.result.commonDocumentStatusValue;
//         });
//         break;
//       case "IQTC":
//         this.iqtcService.getDataForEdit(rowId).subscribe(jsonResp => {
//           this.setEditedData(jsonResp);
//         });
//         break;
//       case "PQTC":
//         this.iqtcService.getDataForEdit(rowId).subscribe(jsonResp => {
//           this.setEditedData(jsonResp);
//         });
//         break;
//       case "OQTC":
//         this.iqtcService.getDataForEdit(rowId).subscribe(jsonResp => {
//           this.setEditedData(jsonResp);
//         });
//         break;
//       case "riskAssessment":
//         this.riskAssessmentService.edit(rowId).subscribe(jsonResp => {
//           this.riskAssesmentData = [];
//           this.docType = type;
//           this.riskAssesmentData.push(jsonResp.result);
//           this.viewIndividualData = true;
//           this.StatusValue = jsonResp.result.commonDocumentStatusValue;
//           if (jsonResp.result.approveFlag) {
//             this.hideButtonFlag = true;
//           } else {
//             this.hideButtonFlag = false;
//           }
//         },
//           err => {
//           }
//         );
//         break;
//       case "riskAssessmentTemplate":
//         this.riskAssesstemplateService.edit(rowId).subscribe(resp => {
//           if (!this.helper.isEmpty(resp.result)) {
//             this.assessmentTemplateModal = resp.result;
//             this.viewIndividualData = true;
//             this.docType = type;
//             this.StatusValue = resp.result.commonDocumentStatusValue;
//             if (resp.result.approveFlag) {
//               this.hideButtonFlag = true;
//             } else {
//               this.hideButtonFlag = false;
//             }
//           }
//         });
//         break;
//       case "vendorValidation":
//         this.vendorService.loadVendorValidationDetailsBasedOnId(rowId).subscribe(jsonResp => {
//           if (jsonResp.list != null) {
//             this.viewIndividualData = true;
//             this.popupdata.push(jsonResp.list);
//             this.StatusValue = this.popupdata[0].commonDocumentStatusValue;
//             this.individualPermissions(this.helper.VENDOR_VALIDATION_VALUE);
//             this.vendorService.loadVendorValidationFile(this.popupdata[0].fileName).subscribe(resp => {
//               if (resp != null) {
//                 this.pdfSrc = resp;
//               }
//             });
//           }
//         });
//         break;
//       default:
//         this.viewIndividualData = true;
//         this.dynamicTemplateService.loadDynamicTemplateDataBasedOnId(rowId).subscribe(response => {
//           this.StatusValue = response.result.commonDocumentStatusValue;
//           this.individualPermissions(this.helper.DYNAMIC_TEMPLATE_VALUE);
//           if (this.model.workFlowButtonFlag)
//             this.hideButtonFlag = true;
//           else
//             this.hideButtonFlag = false;
//           this.dynamicTemplateModel = response.result;
//         });
//     }
//   }

//   changeStatus(statusFlag: boolean, statusValue: string) {
//     if (statusFlag) {
//       this.status = statusValue;
//     } else {
//       this.status = statusValue;
//     }
//     swal({
//       title: 'Comments',
//       input: 'textarea',
//       confirmButtonText: 'Submit',
//       showCancelButton: true,
//       animation: false,
//       showCloseButton: true,
//       inputPlaceholder: "Please Write Comments" ,

//     }).then((comments)=> {
//       if(comments==""){
//         swal.showLoading();
//         swal.showValidationError('Please Enter the Comments');
//         swal.hideLoading();
//       }else{
//         this.docStatusService.changeStatus(this.status, this.docType, this.tempRowId,comments).subscribe(resp => {
//           let timerInterval;
//           if (resp.result == "success") {
//             switch (resp.status) {
//               case this.helper.Approve:
//                 swal({
//                   title:'Approved Successfully!',
//                   text:' ',
//                   type:'success',
//                   timer:this.helper.swalTimer,
//                   showConfirmButton:false,
//                   onClose: () => {
//                     this.viewIndividualData = false;
//                     this.isFlag = true;
//                     this.loaddata();
//                     clearInterval(timerInterval)
//                   }
//                 });
//                 break;
//               case this.helper.Rejected:
//                 swal({
//                   title:'Declined Successfully!',
//                   text:' ',
//                   type:'success',
//                   timer:this.helper.swalTimer,
//                   showConfirmButton:false,
//                   onClose: () => {
//                     this.viewIndividualData = false;
//                     this.isFlag = true;
//                     this.loaddata();
//                     clearInterval(timerInterval)
//                   }
//                 });
//                 break;
//               case this.helper.RejectedByReviewer:
//                 swal({
//                   title:'Review Declined!',
//                   text:' ',
//                   type:'success',
//                   timer:this.helper.swalTimer,
//                   showConfirmButton:false,
//                   onClose: () => {
//                     this.viewIndividualData = false;
//                   this.isFlag = true;
//                   this.loaddata();
//                     clearInterval(timerInterval)
//                   }
//                 });
//                 break;
//               case this.helper.ReviewCompeletedOrApprovePending:
//                 swal({
//                   title:'Review Successfull!',
//                   text:' ',
//                   type:'success',
//                   timer:this.helper.swalTimer,
//                   showConfirmButton:false,
//                   onClose: () => {
//                     this.viewIndividualData = false;
//                     this.isFlag = true;
//                     this.loaddata();
//                     clearInterval(timerInterval)
//                   }
//                 });
//                 break;
//             }
//           } else {
//             swal({
//               title:'Error',
//               text:'Some Internal Issue has been occured .We will get back to You',
//               type:'error',
//               timer:this.helper.swalTimer,
//               showConfirmButton:false
//             }

//             );
//           }
//         }
//         );
//       }
//     }).catch(swal.noop);

//   }

//   loadAll(jsonresp) {
//     this.documentList = [];
//     let URSListData = jsonresp.ursValue;
//     let IQTCListData = jsonresp.iqtcValue;
//     let PQTCListData = jsonresp.pqtcValue;
//     let OQTCListData = jsonresp.oqtcValue;
//     let riskAssessmentListData = jsonresp.riskAssessmentValue;
//     let riskAssessmentTemplateListData = jsonresp.riskAssessmentTemplateValue;
//     let vendorValidationData = jsonresp.vendorValidationValue;
//     let dynamicDocListData = jsonresp.dynamicDocListValue;

//     if (!this.helper.isEmpty(URSListData)) {
//       for (var i = 0; i < URSListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = URSListData[i].id;
//         tempUsr.code = URSListData[i].ursCode;
//         tempUsr.name = URSListData[i].ursName;
//         tempUsr.createdBy = URSListData[i].createdBy;
//         tempUsr.lastUpdatedTime = URSListData[i].updatedTime;
//         if (URSListData[i].commonDocumentStatus != null) {
//           tempUsr.status = URSListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "URS";
//         this.documentList.push(tempUsr);
//       }
//     }
//     if (!this.helper.isEmpty(IQTCListData)) {
//       for (var i = 0; i < IQTCListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = IQTCListData[i].id;
//         tempUsr.code = IQTCListData[i].testCaseCode;
//         tempUsr.name = IQTCListData[i].description;
//         tempUsr.createdBy = IQTCListData[i].createdBy;
//         tempUsr.lastUpdatedTime = IQTCListData[i].updatedTime;
//         if (IQTCListData[i].commonDocumentStatus != null) {
//           tempUsr.status = IQTCListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "IQTC";
//         this.documentList.push(tempUsr);
//       }
//     }

//     if (!this.helper.isEmpty(OQTCListData)) {
//       for (var i = 0; i < OQTCListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = OQTCListData[i].id;
//         tempUsr.code = OQTCListData[i].testCaseCode;
//         tempUsr.name = OQTCListData[i].description;
//         tempUsr.createdBy = OQTCListData[i].createdBy;
//         tempUsr.lastUpdatedTime = OQTCListData[i].updatedTime;
//         if (OQTCListData[i].commonDocumentStatus != null) {
//           tempUsr.status = OQTCListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "OQTC";
//         this.documentList.push(tempUsr);
//       }
//     }
//     if (!this.helper.isEmpty(PQTCListData)) {
//       for (var i = 0; i < PQTCListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = PQTCListData[i].id;
//         tempUsr.code = PQTCListData[i].testCaseCode;
//         tempUsr.name = PQTCListData[i].description;
//         tempUsr.createdBy = PQTCListData[i].createdBy;
//         tempUsr.lastUpdatedTime = PQTCListData[i].updatedTime;
//         if (PQTCListData[i].commonDocumentStatus != null) {
//           tempUsr.status = PQTCListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "PQTC";
//         this.documentList.push(tempUsr);
//       }
//     }
//     if (!this.helper.isEmpty(riskAssessmentTemplateListData)) {
//       for (var i = 0; i < riskAssessmentTemplateListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = riskAssessmentTemplateListData[i].id;
//         tempUsr.code = riskAssessmentTemplateListData[i].templateCode;
//         tempUsr.name = riskAssessmentTemplateListData[i].titledata;
//         tempUsr.createdBy = riskAssessmentTemplateListData[i].createdBy;
//         tempUsr.lastUpdatedTime = riskAssessmentTemplateListData[i].updatedTime;
//         if (riskAssessmentTemplateListData[i].commonDocumentStatus != null) {
//           tempUsr.status = riskAssessmentTemplateListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "riskAssessmentTemplate";
//         this.documentList.push(tempUsr);
//       }
//     }
//     if (!this.helper.isEmpty(riskAssessmentListData)) {
//       for (var i = 0; i < riskAssessmentListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = riskAssessmentListData[i].id;
//         tempUsr.code = riskAssessmentListData[i].assessmentCode;
//         tempUsr.name = riskAssessmentListData[i].riskFactor;
//         tempUsr.createdBy = riskAssessmentListData[i].createdBy;
//         tempUsr.lastUpdatedTime = riskAssessmentListData[i].updatedTime;
//         if (riskAssessmentListData[i].commonDocumentStatus != null) {
//           tempUsr.status = riskAssessmentListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "riskAssessment";
//         this.documentList.push(tempUsr);
//       }
//     }
//     if (!this.helper.isEmpty(vendorValidationData)) {
//       for (var i = 0; i < vendorValidationData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = vendorValidationData[i].id;
//         tempUsr.code = vendorValidationData[i].vendorCode;
//         tempUsr.name = vendorValidationData[i].documentName;
//         tempUsr.createdBy = vendorValidationData[i].createdBy;
//         tempUsr.lastUpdatedTime = vendorValidationData[i].createdTime;
//         if (vendorValidationData[i].commonDocumentStatus != null) {
//           tempUsr.status = vendorValidationData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "vendorValidation";
//         this.documentList.push(tempUsr);
//       }
//     }

//     if (!this.helper.isEmpty(dynamicDocListData)) {
//       for (var i = 0; i < dynamicDocListData.length; i++) {
//         let tempUsr = new DocStatusList();
//         tempUsr.id = dynamicDocListData[i].id;
//         tempUsr.code = dynamicDocListData[i].templateCode;
//         tempUsr.name = dynamicDocListData[i].tittle;
//         tempUsr.createdBy = dynamicDocListData[i].createdBy;
//         tempUsr.lastUpdatedTime = dynamicDocListData[i].updatedTime;
//         if (dynamicDocListData[i].commonDocumentStatus != null) {
//           tempUsr.status = dynamicDocListData[i].commonDocumentStatus;
//         } else {
//           tempUsr.status = ""
//         }
//         tempUsr.type = "dynamicTemplate";
//         this.documentList.push(tempUsr);
//       }
//     }
//   }

//   loadUrsData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.ursValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].ursCode;
//       tempUsr.name = this.tempData[i].ursName;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.lastUpdatedTime = this.tempData[i].updatedTime;
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       tempUsr.type = "URS";
//       this.documentList.push(tempUsr);
//     }
//   }

//   loadIqtcData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.iqtcValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].testCaseCode;
//       tempUsr.name = this.tempData[i].description;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.lastUpdatedTime = this.tempData[i].updatedTime;
//       tempUsr.type = "IQTC";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }

//   loadOqtcData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.oqtcValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].testCaseCode;
//       tempUsr.name = this.tempData[i].description;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.lastUpdatedTime = this.tempData[i].updatedTime;
//       tempUsr.type = "OQTC";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }

//   loadPqtcData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.pqtcValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].testCaseCode;
//       tempUsr.name = this.tempData[i].description;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.lastUpdatedTime = this.tempData[i].updatedTime;
//       tempUsr.type = "PQTC";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }

//   setEditedData(jsonResp) {
//     if (jsonResp.result.files.length != 0)
//       jsonResp.result.files[0].visible = true;
//     if (jsonResp.result.approveFlag) {
//       this.hideButtonFlag = true;
//     }
//     this.docType = jsonResp.result.testCaseType;
//     this.StatusValue = jsonResp.result.commonDocumentStatusValue;
//     this.popupdata.push(jsonResp.result);
//     this.viewIndividualData = true;
//   }

//   loadDocStatusData(jsonresp) {

//     this.pendingDocList = [];
//     this.approvedDocList = []
//     if (this.model.workFlowButtonFlag) {
//       this.loadAll(jsonresp.ReviewCompeletedOrApprovePending);
//       this.pendingDocList = this.documentList;
//       this.loadAll(jsonresp.Approve);
//       this.approvedDocList = this.documentList;
//     }
//     if (this.model.workFlowButtonFlag) {
//       this.loadAll(jsonresp.ReviewCompeletedOrApprovePending);
//       this.approvedDocList = this.documentList;
//       this.loadAll(jsonresp.ReviewPending);
//       this.pendingDocList = this.documentList;
//     }
//     if (this.model.workFlowButtonFlag && this.model.workFlowButtonFlag) {
//       this.loadAll(jsonresp.ReviewCompeletedOrApprovePending);
//       this.pendingDocList = this.documentList;
//       this.loadAll(jsonresp.Approve);
//       this.approvedDocList = this.documentList;
//       this.loadAll(jsonresp.ReviewPending);
//       let value = this.pendingDocList.length;
//       for (let index = 0; index < this.documentList.length; index++) {
//         this.pendingDocList[value + index] = this.documentList[index];
//       }
//     }
//     this.loadAll(jsonresp.Rejected);
//     this.declinedDoclist = this.documentList;
//     this.isFlag = false;
//   }

//   individualPermissions(typeId: any) {
//     this.configService.loadPermissionsBasedOnModule(typeId).subscribe(resp=>{
//       this.model=resp;
//     }); 
//   }

//   loadriskAssessmentData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.riskAssessmentValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].assessmentCode;
//       tempUsr.name = this.tempData[i].riskFactor;
//       tempUsr.createdBy = this.tempData[i].systemRemarks;
//       tempUsr.type = "riskAssessment";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }
//   loadriskAssessmentTemplateData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.riskAssessmentTemplateValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].templateCode;
//       tempUsr.name = this.tempData[i].titledata;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.type = "riskAssessmentTemplate";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }

//   plusSlides(n) {
//     if (n == 1) {
//       let prev = this.slideIndex;
//       let next = this.slideIndex + 1;
//       if (next < this.popupdata[0].files.length) {
//         this.popupdata[0].files[this.slideIndex].visible = false;
//         this.popupdata[0].files[++this.slideIndex].visible = true;
//       } else {
//         this.popupdata[0].files[this.slideIndex].visible = false;
//         this.popupdata[0].files[0].visible = true;
//         this.slideIndex = 0;
//       }
//     } else {
//       let prev = this.slideIndex - 1;
//       let next = this.slideIndex;
//       if (prev < 0) {
//         this.popupdata[0].files[this.slideIndex].visible = false;
//         this.popupdata[0].files[this.popupdata[0].files.length - 1].visible = true;
//         this.slideIndex = this.popupdata[0].files.length - 1;
//       } else {
//         this.popupdata[0].files[prev].visible = true;
//         this.popupdata[0].files[next].visible = false;
//         this.slideIndex = prev;
//       }
//     }
//   }

//   onSelect({ selected }, statusId) {
//     this.selected = [];
//     if (this.helper.ReviewPending == statusId) {
//       this.docStatus = "review";
//       this.pendingDocList.filter(doc => doc.status == "Review Pending").forEach(element => {
//         this.selected.push(element);
//       });
//     }
//     if (this.helper.ReviewCompeletedOrApprovePending == statusId) {
//       this.docStatus = "approve"
//       this.pendingDocList.filter(doc => doc.status == "Review Compeleted/Approve Pending").forEach(element => {
//         this.selected.push(element);
//       });
//     }
//     if (this.model.workFlowButtonFlag) {
//       this.hideButtonFlag = false;
//     }
//     if (this.model.workFlowButtonFlag) {
//       this.hideButtonFlag = true;
//     }
//     var classObject = this;
//     swal({
//       title: 'Are you sure?',
//       text: 'You wont be able to revert',
//       type: 'warning',
//       showCancelButton: true,
//       confirmButtonColor: '#3085d6',
//       cancelButtonColor: '#d33',
//       confirmButtonText: 'Yes,' + this.docStatus + ' it!',
//       cancelButtonText: 'No, cancel!',
//       confirmButtonClass: 'btn btn-success m-r-10',
//       cancelButtonClass: 'btn btn-danger',
//       allowOutsideClick: false,
//       buttonsStyling: false
//     }).then(resp => {
//       if(resp){
//       swal({
//         title: 'Comments',
//         input: 'textarea',
//         confirmButtonText: 'Submit',
//         showCancelButton: true,
//         animation: false,
//         showCloseButton: true,
//         inputPlaceholder: "Please Write Comments" ,

//       }).then((comments)=> {
//         if(comments==""){
//           swal.showLoading();
//           swal.showValidationError('Please Enter the Comments');
//           swal.hideLoading();
//         }else{
//           this.documentStausChangeComments=comments;
//           classObject.bulkSave(statusId);
//           this.isFlag = true;
//         this.loaddata();
//         }});


//     }
//     }).catch(swal.noop);
//   }

//   bulkSave(statusId: any) {
//     let iqtcId = new Array();
//     let pqtcId = new Array();
//     let oqtcId = new Array();
//     let ursId = new Array();
//     let riskAssessmentId = new Array();
//     let riskAssessmentTemplateId = new Array();
//     let vendorValidationId = new Array();
//     let dynamicDocListId = new Array();

//     this.selected.filter(doc => doc.type == "IQTC").forEach(element => {
//       iqtcId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "PQTC").forEach(element => {
//       pqtcId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "OQTC").forEach(element => {
//       oqtcId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "URS").forEach(element => {
//       ursId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "riskAssessment").forEach(element => {
//       riskAssessmentId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "riskAssessmentTemplate").forEach(element => {
//       riskAssessmentTemplateId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "vendorValidation").forEach(element => {
//       vendorValidationId.push(element.id);
//     });
//     this.selected.filter(doc => doc.type == "dynamicTemplate").forEach(element => {
//       dynamicDocListId.push(element.id);
//     });

//     var data = {
//       "status": statusId,
//       "iqtc": iqtcId,
//       "oqtc": oqtcId,
//       "pqtc": pqtcId,
//       "urs": ursId,
//       "riskAssessment": riskAssessmentId,
//       "riskAssessmentTemplate": riskAssessmentTemplateId,
//       "vendorValidation": vendorValidationId,
//       "dynamicTemplate": dynamicDocListId,
//       "comments":this.documentStausChangeComments
//     };
//     this.docStatusService.bulkSave(data).subscribe(jsonResp => {
//       let responseMsg: boolean = jsonResp;
//       if (responseMsg == true) {
//         swal(
//           'success',
//           this.selected.length + ' record(s) ' + this.docStatus + ' completed',
//           'success'
//         ).then(responseMsg => {
//           this.docStatusService.loadDocStatusListBasedOnRoleIdAndDocType('').subscribe(jsonresp => {
//             this.loadDocStatusData(jsonresp);
//           });

//         });
//       } else {
//         swal(
//           'error',
//           'Oops Somenthing went Worng.',
//           'error'
//         );
//       }
//     });
//   }

//   loadVendorValidationData(jsonresp) {
//     this.documentList = [];
//     this.tempData = jsonresp.vendorValidationValue;
//     for (var i = 0; i < this.tempData.length; i++) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = this.tempData[i].id;
//       tempUsr.code = this.tempData[i].vendorCode;
//       tempUsr.name = this.tempData[i].documentName;
//       tempUsr.createdBy = this.tempData[i].createdBy;
//       tempUsr.lastUpdatedTime = this.tempData[i].updatedTime;
//       tempUsr.type = "vendorValidation";
//       if (this.tempData[i].commonDocumentStatus != null) {
//         tempUsr.status = this.tempData[i].commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       this.documentList.push(tempUsr);
//     }
//   }

//   callBackFn(event) {
//     this.totalNumberOfPdfPages = event.pdfInfo.numPages;
//     this.pdfPage = 1;
//   }

//   zoomInPDF(i) {
//     this.originalSize = true;
//     if (i < 1.30) {
//       this.zoom = i + 0.05;
//     }
//   }
//   zoomOutPDF(i) {
//     this.originalSize = true;
//     if (i != 1) {
//       this.zoom = i - 0.05;
//     }
//   }

//   gotoPage(page) {
//     let presentPage = this.pdfPage;
//     if (page <= this.totalNumberOfPdfPages) {
//       this.showAll = false;
//       this.pdfPage = page;
//     } else {
//       this.pdfPage = presentPage;
//     }
//   }

//   setDynamicTemplateData(dynamicDocListData) {
//     if (!this.helper.isEmpty(dynamicDocListData)) {
//       let tempUsr = new DocStatusList();
//       tempUsr.id = dynamicDocListData.id;
//       tempUsr.code = dynamicDocListData.templateCode;
//       tempUsr.name = dynamicDocListData.tittle;
//       tempUsr.createdBy = dynamicDocListData.createdBy;
//       tempUsr.lastUpdatedTime = dynamicDocListData.updatedTime;
//       if (dynamicDocListData.commonDocumentStatus != null) {
//         tempUsr.status = dynamicDocListData.commonDocumentStatus;
//       } else {
//         tempUsr.status = ""
//       }
//       tempUsr.type = "dynamicTemplate";
//       this.documentList.push(tempUsr);
//     }
//   }
//   loadDocumentCommentLog(row){
//    this.modalSpinner=true;
//     this.docStatusService.loadDocumentCommentLog(row.id,row.type).subscribe(result=>{
//       this.currentDocType=row.type;
//       this.currentDocStatus=row.status;
//       this.currentCreatedBy=row.createdBy;
//       this.currentModifiedDate=row.lastUpdatedTime;
//       if(result.list!=null){
//         this.statusLog=result.list;
//       }
//       this.modalSpinner=false;
//     });
//   }
 }
