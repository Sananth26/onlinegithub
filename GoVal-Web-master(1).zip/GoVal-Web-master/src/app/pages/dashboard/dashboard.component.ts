import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { Helper } from './../../shared/helper';
import { DashBoardService } from './dashboard.service';
import { AdminComponent } from '../../layout/admin/admin.component';
import { DatePipe } from '@angular/common';
import { DocumentSummaryDTO } from '../../models/model';
import { LocationService } from '../location/location.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css', '../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None,
})

export class DashboardComponent implements OnInit {
  spinnerFlag: boolean = false;
  dashboardData:any[];
  @ViewChild( 'myTable' ) table: any;
  public tableView: boolean = true;
  locationsList: any;
  location:any
  constructor(private adminComponent: AdminComponent, public helper: Helper, public service: DashBoardService,public datePipe: DatePipe,public locationService:LocationService) {
  }

  ngOnInit() {
    this.loadLocation();
    this.adminComponent.setUpModuleForHelpContent("101");
    this.adminComponent.taskDocType = "101";
    this.adminComponent.taskDocTypeUniqueId =  "";
    this.adminComponent.taskEquipmentId =0;
    this.adminComponent.taskEnbleFlag = true;
  }
  toggleExpandRowprojectsetup( row ) {
    this.table.rowDetail.toggleExpandRow( row );
}
  onTabChange(tabIndex:any,data:any){
  }

  urlRedirect(url:string,id?){
    this.adminComponent.redirect(url,'/dashboard');
  }
  downloadPdf(documentConstnatName: any, docName: any, version: any) {
    this.spinnerFlag = true;
    this.service.downloadDocumentPdf(documentConstnatName, version.versionId).subscribe(res => {
      var blob: Blob = this.b64toBlob(res._body, 'application/pdf');
      let name:any;
      let date = this.datePipe.transform(new Date(), 'yyyy-MM-dd hh:mm');
      date = date.replace(":", "-");
      this.spinnerFlag = false;
      if (documentConstnatName != '128')
        name = docName + "--" + version.versionName + "--" + date + ".pdf";
      else
        name = docName + "--" + version.versionName + "--" + date + ".zip";
      if (window.navigator && window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(blob, name);
      } else {
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = name;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        this.spinnerFlag = false;
      }
      this.spinnerFlag = false;
    });
  }
  b64toBlob(b64Data, contentType) {
    contentType = contentType || '';
    var sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    var blob = new Blob(byteArrays, { type: contentType });
    return blob;
  }


  changeview(value) {
    //this.helper.setEquipmentStatusGridorTable(value)
    this.tableView = value;
    //this.createChartData();
  }

loadData(id:any){
  this.spinnerFlag = true;
  this.service.loadNewDashboard(id).subscribe(resp =>{
    this.dashboardData =  resp;
    this.spinnerFlag = false;
    this.dashboardData.forEach(data =>{
        data.versionList.forEach((version,index) => {
          let comboChartData =  {
            chartType: 'ComboChart',
            dataTable: [],
            options: {
              height: 300,
              title: data.projectName,
              vAxis: { title: 'No of Documents' },
              hAxis: { title: 'Document' },
              seriesType: 'bars',
              series: { 5: { type: 'line' } },
              colors: ['#919aa3', '#62d1f3', '#FFB64D', '#93BE52',]
            },
          };
         version.nodataInChartFlag=true;
          version.documents.forEach((document:DocumentSummaryDTO) => {
            if(document.draft+document.published==0){
              if(version.nodataInChartFlag)
              version.nodataInChartFlag=true;
            }else{
              version.nodataInChartFlag=false;
            }
            if(comboChartData.dataTable.length<=16){
              let documentData:any[]=new Array();
              documentData.push(document.documentName);
              documentData.push(document.draft);
              documentData.push(document.published);
              documentData.push(document.inProgress);
              documentData.push(document.completed);
              comboChartData.dataTable.push(documentData);
            }
          });
          if(comboChartData.dataTable.length>0){
            comboChartData.dataTable.unshift(['Document', 'Draft', 'Published', 'In Progress', 'Completed']);
          }
          version.comboChartData=comboChartData;
         
        });
    });
  });
}
  loadLocation(){
    this.locationService.loadAllActiveLocations().subscribe(response =>{
        this.locationsList=response.result
      });
    }
   
  
}
