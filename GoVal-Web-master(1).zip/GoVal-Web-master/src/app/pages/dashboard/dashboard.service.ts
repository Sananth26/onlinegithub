import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
@Injectable()
export class DashBoardService {
    constructor(private http: Http, public helper: Helper, public config: ConfigService) { }
    url_docs_project: string = this.helper.common_URL + 'common/loadDocsBasedOnProject';
    url_loadDashboard: string = this.helper.common_URL + 'dashboard/loadDashBoard';
    url_esign: string = this.helper.common_URL + 'workFlow/createEsign';
    url_loadCss: string = this.helper.common_URL + 'common/loadCss';
    url_getdocumentStepper: string = this.helper.common_URL + 'workFlow/getDocumentTimeLine';
    url_setindividualWorkflow: string = this.helper.common_URL + 'workFlow/approveOrReject';
    url_loadAllEsignDoc: string = this.helper.common_URL + "dashboard/downloadpdf";
    url_loadNewDashboard: string = this.helper.common_URL + 'dashboard/loadNewDashBoard';
    //loads the blocks for all the dashboards
    loadProjectDocs() {
        return this.http.post(this.url_docs_project, "", this.config.getRequestOptionArgs())
            .map((resp) => resp.json())
            .catch(res => {
                return Observable.throw(res.json());
            });
    }

    SetIndividualWorkflow(data: any) {
        return this.http.post(this.url_setindividualWorkflow, data, this.config.getRequestOptionArgs())
            .map((resp) => resp.json())
            .catch(res => {
                return Observable.throw(res.json());
            });
    }
    loaddocumentStepper(data) {
        return this.http.post(this.url_getdocumentStepper, data, this.config.getRequestOptionArgs())
            .map((resp) => resp.json())
            .catch(res => {
                return Observable.throw(res.json());
            });
    }
    loadDashboard(){
        return this.http.post(this.url_loadDashboard, "", this.config.getRequestOptionArgs())
        .map((resp) => resp.json())
        .catch(res => {
            return Observable.throw(res.json());
        });
    }
    downloadDocumentPdf(documentConstantName, versionId) {
        return this.http.post(this.url_loadAllEsignDoc, { "documentConstantName": documentConstantName,"versionId":versionId,"From":"dashboard"}, this.config.getRequestOptionArgs())
            .map((resp) => resp)
            .catch(res => {
                return Observable.throw(res);
            });
    }
    loadNewDashboard(locationId:any){
        return this.http.post(this.url_loadNewDashboard, locationId, this.config.getRequestOptionArgs())
        .map((resp) => resp.json())
        .catch(res => {
            return Observable.throw(res.json());
        });
    }
}
