import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../shared/shared.module';
import { Helper } from '../../shared/helper';
import { ConfigService } from '../../shared/config.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { IndividualDocumentWorkflowComponent } from './individual-document-workflow.component';
import { IndividualDocumentWorkflowService } from './individual-document-workflow.service';
import { DocumentsignComponentModule } from '../documentsign/documentsign.module';
import { DocumentStatusCommentLog } from '../document-status-comment-log/document-status-comment-log.module';
import { AuditTrailViewModule } from '../audit-trail-view/audit-trail-view.module';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    DocumentsignComponentModule,
    DocumentStatusCommentLog,AuditTrailViewModule
  ],
  exports:[IndividualDocumentWorkflowComponent],
  declarations: [IndividualDocumentWorkflowComponent],
  providers : [Helper,ConfigService,IndividualDocumentWorkflowService],
})
export class IndividualDocumentWorkflowModule { }
