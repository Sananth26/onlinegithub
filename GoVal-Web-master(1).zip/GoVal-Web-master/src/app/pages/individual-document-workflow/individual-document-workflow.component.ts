import { Component, OnInit, Input, ViewChild, Output,EventEmitter } from '@angular/core';
import { StepperClass, WorkflowDocumentStatusDTO, UserPrincipalDTO, CommonModel } from '../../models/model';
import { IndividualDocumentWorkflowService } from './individual-document-workflow.service';
import swal from 'sweetalert2';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { AdminComponent } from '../../layout/admin/admin.component';

@Component({
  selector: 'app-individual-document-workflow',
  templateUrl: './individual-document-workflow.component.html',
  styleUrls: ['./individual-document-workflow.component.css']
})
export class IndividualDocumentWorkflowComponent implements OnInit {

  @Input() permissionConstant: string="";
  @ViewChild('documentSign') documentChildComponent;
  @ViewChild('esignmodal') closeEsignModal: any;
  @ViewChild('modalLarge') approvalModal: any;
  @ViewChild('levelDescription') levelDescription:any;
  public previewdoc: any = []
  public row: any;
  public viewpdf: boolean = true;
  public getStatus: any = [];
  public filteredPendingDocList: any[] = new Array();
  public spinnerFlag: Boolean = true;
  public comments: any = null;
  public filteredData: any[]=new Array();
  public filteredApprovalData: any[]=new Array();
  public docItemList: any;
  public searchData: any;
  public esignHistoryList: any[] = new Array();
  public filteredCompletedDocList: any[] = new Array();
  public esignActionData: WorkflowDocumentStatusDTO[] = new Array<WorkflowDocumentStatusDTO>();
  currentUser: UserPrincipalDTO = new UserPrincipalDTO();
  public commonModel: CommonModel = new CommonModel();
  @Output() onRejectDocument = new EventEmitter();
  content:any;
  show: boolean;
  constructor(private comp: AdminComponent,private service: IndividualDocumentWorkflowService, public config: ConfigService, public helper: Helper) { }

  ngOnInit() {
    this.comp.setUpModuleForHelpContent(this.permissionConstant);
   this.helper.currentId.subscribe(
      data => {
        if (data !== 'no data') {
          this.closeEsignModal.hide();
          this.loadDocuments();
        }
      })
    this.config.loadCurrentUserDetails().subscribe(response => {
      this.currentUser = response;
      this.loadDocuments();
    });
  }
  loadDocuments() {
    this.viewpdf = false;
    this.commonModel.type = 'workflowapprovalStatus';
    this.commonModel.categoryName = 'pending';
    this.commonModel.dataType = 'opt1';
    this.commonModel.value=this.permissionConstant;
    this.service.Api(this.commonModel, 'workFlow/loadDocumentsForUserAndDocumentType').subscribe(response => {
      this.filteredPendingDocList = response.pendingList;
      this.bulkApprovalTimeLine();
    },
      err => {
        this.spinnerFlag = false
      })
  }
  bulkApprovalTimeLine() {
    this.previewdoc = null;
    const stepperModule: StepperClass = new StepperClass()
    stepperModule.constantName = this.permissionConstant;
    this.service.Api(stepperModule, 'workFlow/bulkDocumentApproveTimeLine').subscribe(response => {
      this.getStatus = response.timeLine;
      this.getStatus.forEach(element => {
        element.errorList = this.filteredPendingDocList.filter(e => e.currentLevel === element.levelId)
        if (this.filteredPendingDocList.length > 0 && null == this.previewdoc && null != element.errorList && element.errorList.length > 0) {
          element.thisIsCurrent = true;
          this.previewdoc = element.errorList;
          this.pdfpreview(this.previewdoc)
        }
      });
      if( this.filteredPendingDocList.length === 0)
        this.spinnerFlag=false;
    });
  }
  pdfpreview(data) {
    const ids: any[] = new Array();
    data.forEach(ee => {
      ids.push(ee.documentId);
    });
    const stepperModule: StepperClass = new StepperClass();
    stepperModule.constantName = this.permissionConstant;
    stepperModule.documentIds = ids;
    this.service.Api(stepperModule, 'workFlow/pdfPreviewfortimeline').subscribe(response => {
      this.viewpdf = true;
      var responseBolb: any[] = this.b64toBlob(response.pdf)
      const blob: Blob = new Blob(responseBolb, { type: "application/pdf" });
      setTimeout(() => {
         this.createIFrame(URL.createObjectURL(blob)); 
        }, 10);
    })

  }
  private createIFrame(blob_url: string) {
    var iframe;
    var elementExists = document.getElementById('iframeView');
    if (!elementExists)
      iframe = document.createElement('iframe');
    else
      iframe = elementExists;
    iframe.setAttribute('id', 'iframeView')
    iframe.setAttribute("height", window.innerHeight);
    iframe.setAttribute("width", "100%");
    iframe.src = blob_url + '#zoom=113';
    const find = document.querySelector('#fileUploadIdBulkApproval');
    find.setAttribute('class', 'well well-lg row');
    find.appendChild(iframe);
    this.spinnerFlag=false;
  }

  private b64toBlob(b64Data) {
    var sliceSize = sliceSize || 512;
    var byteCharacters = atob(b64Data);
    var byteArrays = [];
    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
      var slice = byteCharacters.slice(offset, offset + sliceSize);
      var byteNumbers = new Array(slice.length);
      for (var i = 0; i < slice.length; i++) {
        byteNumbers[i] = slice.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      byteArrays.push(byteArray);
    }
    return byteArrays;
  }
  getdata(data: any,permission:any) {
    this.filteredData=[];
    this.filteredApprovalData=[];
    this.comments = null;
    let currentdata = data[0];
    data.forEach(element => {
      this.filteredPendingDocList.forEach(s => {
        if (s.documentId == element.documentId)
          s.approvedFlag = true
      })
    })
    this.filteredData = this.filteredPendingDocList.filter(
      data => (data.currentLevel === currentdata.currentLevel) && (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Approval" || data.actionType === 1))
    this.filteredApprovalData = this.filteredPendingDocList.filter(
      data => (data.currentLevel === currentdata.currentLevel) && (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Esign" || data.actionType === 2))
    if (undefined != this.documentChildComponent) {
      this.documentChildComponent.loadDocumentList(this.filteredApprovalData)
      this.documentChildComponent.closeMyModal('effect-12')
      this.bulkApprovalTimeLine();
    }
    if (this.filteredApprovalData.length > 0) {
      this.filteredApprovalData.forEach(element => {
        element.approvedFlag = true
        if (element.groupedItems.length > 0) {
          element.groupedItems.push(element.groupedItems)
        }
        this.esignActionData.push(element)
      })
    }
    if(permission){
      if( this.filteredData.length >0)
        this.approvalModal.show();
      if( this.filteredApprovalData.length >0)
        this.closeEsignModal.show();
    }
  }
  approve() {
    this.filteredData.forEach(element => {
      element.approvedFlag = true
      element.rejectedFlag = false
      element.globalProjectId = this.currentUser.projectId
      element.comments = this.comments
      element.currentUser = this.currentUser.id
    })
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Approve All!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then((data) => {
      this.ApproveOrReject()
    })
  }
  reject() {
    this.filteredData.forEach(element => {
      element.approvedFlag = false
      element.rejectedFlag = true
      element.globalProjectId = this.currentUser.projectId
      element.comments = this.comments
      element.currentUser = this.currentUser.id
    })
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, reject All!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then((data) => {
      this.ApproveOrReject();
      this.onRejectDocument.emit();
      
    })
  }
  ApproveOrReject() {
    this.spinnerFlag = true
    this.service.Api(this.filteredData, 'workFlow/approveOrReject').subscribe(response => {
      if (response.dataType === 'Multiple access for same Data') {
        swal({
          title: '',
          text: 'Multiple access for same Data',
          type: 'warning',
          timer: this.helper.swalTimer,
          showConfirmButton: false
        })
      } else {
        swal({
          title: '',
          text: 'Success',
          type: 'success',
          timer: this.helper.swalTimer,
          showConfirmButton: false
        })
      }
      setTimeout(() => { this.loadDocuments(); }, 1000)
    })
  }
  getDescription(data:any){
    this.show= true;
     this.content=data;
  }

  close(data:any){
    this.show= false;
  }
}
