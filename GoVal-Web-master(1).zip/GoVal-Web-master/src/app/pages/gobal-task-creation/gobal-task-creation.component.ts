import { Component, OnInit, ViewChild, ViewEncapsulation, Input,Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateISOParserFormatter } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date-parser-formatter';
import swal from 'sweetalert2';
import { AdminComponent } from '../../layout/admin/admin.component';
import { Permissions } from '../../shared/config';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { FileUploadForDocComponent } from '../file-upload-for-doc/file-upload-for-doc.component';
import { LookUpService } from '../LookUpCategory/lookup.service';
import { projectsetupService } from '../projectsetup/projectsetup.service';
import { FileDTO, ProjectTaskDocuments, ProjectTaskDocumentsIdDTO, ProjectTaskDTO, TaskBoardDTO, UserPrincipalDTO, TaskTimerTrackingDTO } from './../../models/model';
import { IOption } from '../../../../node_modules/ng-select';
import { EquipmentService } from '../equipment/equipment.service';
import { TaskCreationService } from '../task-creation/task-creation.service';
import { DateFormatSettingsService } from '../date-format-settings/date-format-settings.service';
import { DatePipe } from '../../../../node_modules/@angular/common';
@Component({
  selector: 'app-gobal-task-creation',
  templateUrl: './gobal-task-creation.component.html',
  styleUrls: ['./gobal-task-creation.component.css','./../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class GobalTaskCreationComponent implements OnInit {
  @Input() public createFlag:any;
  @Input() public gobalDocType:any;
  @Input() public gobalDocId:any;
  @Input() public gobalEquId:any;
  @ViewChild('myTable') table: any;
  @ViewChild('fileupload') public file: FileUploadForDocComponent;
  public gobalTaskForm: FormGroup;
  data: any;
  filterData: any;
  modal: ProjectTaskDTO = new ProjectTaskDTO();
  timerTrackingDTO:TaskTimerTrackingDTO = new TaskTimerTrackingDTO();
  public rowsOnPage = 10;
  public filterQuery = '';
  spinnerFlag = false;
  disabledocs:boolean=false;
  iscreate: boolean = false;
  isUpdate: boolean = false;
  isSave: boolean = false;
  locationList: any;
  priorityList: any = [];
  taskCategoryList: any = [];
  statusList: any = [];
  usersList: any = [];
  documentTypeList: any = [];
  documentTypeIdList: any = [];
  public today: NgbDateStruct;
  public validDate: NgbDateStruct;
  mainDocumentTypeList: any[];
  projectTaskDocuments: ProjectTaskDocuments[] = new Array<ProjectTaskDocuments>();
  fileList: any = [];
  public tableView: boolean = true;
  selectedPriority: String = "";
  selectedStatus: String = "";
  selectedTaskCategory:String = "";
  taskBoardData: TaskBoardDTO[] = new Array<TaskBoardDTO>();
  viewIndividualTaskData: boolean = false;
  viewData: any;
  viewTimeTrackingData:any
  frequencyList: any[];
  isRemainderFlag: boolean = false;
  currentUser: UserPrincipalDTO = new UserPrincipalDTO();
  permisionModal: Permissions = new Permissions("190",false);
  userItemList = [];
  selectedUserItems = [];
  settings = {};
  submitted:boolean=false;
  users:any[]=new Array<any>();
  public remainingDays:number;
  updateFlag:boolean=false;
  isCancel:boolean = true;
  equipment: Array<IOption> = new Array<IOption>();
  gobalDocumentType:string;
  gobalDocumentId:string;
  @Output() onTaskPopupHide = new EventEmitter();
  roleBackEqupmentId:any=null;
  routeback:any=null;
  disableItems:boolean =false;
  fileUploadDesable:boolean = false;
  redirctUrlFormView:any;
  pattern="d-m-Y";
  datePipeFormat='yyyy-MM-dd';
  validation_messages = {
    'taskTitle': [
        { type: 'required', message: 'Task title is Required' },
      ],
      'priority': [
        { type: 'required', message: 'Priority is Required' },
      ],
      'taskCategory': [
        { type: 'required', message: 'TaskCategory is Required' },
      ],
      'dueDate': [
        { type: 'required', message: 'Due Date is Required' },
      ],
      'assignedTo': [
        { type: 'required', message: 'Assigned to is Required' },
      ],
      'status': [
        { type: 'required', message: 'Status to is Required' },
      ],
      
  }
  constructor(public configService: ConfigService, public router: Router,
    private comp: AdminComponent, public fb: FormBuilder,
    public service: TaskCreationService, public helper: Helper,
    public lookUpService: LookUpService,private datePipe: DatePipe,private servie: DateFormatSettingsService,
    public projectsetupService: projectsetupService,private route: ActivatedRoute,private Eservice:EquipmentService
  ) { }

  ngOnInit() {
    this.loadOrgDateFormatAndTime();
    this.loadOrgDateFormat();
    this.configService.loadCurrentUserDetails().subscribe(res => {
      this.currentUser = res;
      
      this.loadUsers();
      this.loadPriorityList();
      this.loadStatusList();
      this.loadDocumentTypes();
      this.loadTaskCategory();
      this.loadEquipment();
      
    });

    
    this.comp.setUpModuleForHelpContent(this.helper.TASK_CREATION);
    this.comp.taskDocType = this.helper.TASK_CREATION;
    this.configService.loadPermissionsBasedOnModule(this.helper.TASK_CREATION).subscribe(resp=>{
      this.permisionModal=resp
    });
       
    this.gobalTaskForm = this.fb.group({
      taskTitle: ['', Validators.compose([
        Validators.required
      ])],
      priority: ['', Validators.compose([
        Validators.required
      ])],
      dueDate: ['', Validators.compose([
        Validators.required
      ])],
      assignedTo: ['', Validators.compose([
        Validators.required
      ])],
      status: ['', Validators.compose([
        Validators.required
      ])],
      documentType: [],
      documentId: [],
      description: [],
      remainderFlag: [],
      frequency: [],
      taskCategory:[],
      selectedEquipment: [],
    });
    this.lookUpService.getlookUpItemsBasedOnCategory("dueDateFrequency").subscribe(res => {
      this.frequencyList = res.response;
    });
  }

  loadUsers() {
    this.projectsetupService.loadUsersByProject(this.currentUser.projectId).subscribe(resp => {
      if (resp.list != null) {
        this.users= resp.list;
        this.usersList = resp.list.map(option => ({ value: option.id, label: option.userName }));
        this.userItemList = resp.list.map(option => ({ id: option.id, itemName: option.userName }));
      }
    });
  }
  loadEquipment() {
    this.Eservice.loadEquipmentsByuser().subscribe(response => {
      if (response.result != null) {
        this.equipment = response.result.map(option => ({ value: option.id, label: option.name }));
      }
    }, error => { this.spinnerFlag = false });
    this.taskPopupData();
    
  }
  onChangeRemainderFlag(event: any) {
    this.isRemainderFlag = event;
  }
  taskPopupData(){
    if(this.createFlag){
      this.gobalDocumentType = this.gobalDocType;
      this.iscreate=this.createFlag;
      this.isSave = true;
      this.isCancel = false;
      this.setTaskGobalValues(this.gobalDocType,this.gobalDocId,this.gobalEquId);
    }
  }
  setTaskGobalValues(docType:any,docId:any,equipmentId:number){
    this.isSave = true;
    this.iscreate = true;
    this.disableItems = false;
    this.fileUploadDesable = false;
    this.viewIndividualTaskData = false;
    this.gobalTaskForm.reset();
    this.gobalTaskForm.controls['status'].disable();
    this.gobalTaskForm.get("priority").setValue("Medium");
    this.modal.files = [];
    this.loadDocumentTypes();
    if(equipmentId != 0){
      this.gobalTaskForm.get("selectedEquipment").setValue([equipmentId]);
      this.gobalTaskForm.controls['selectedEquipment'].disable();
    }else{
      this.gobalTaskForm.controls['selectedEquipment'].enable();
    }
    this.gobalTaskForm.get("status").setValue("Open");
    if(docType == '108' || docType == '109' || docType == '110'){
    this.gobalTaskForm.get("taskCategory").setValue("Bug");
    }else{
      this.gobalTaskForm.get("taskCategory").setValue("Task");
    }
    if(docType != ''){
      this.loadDocumentTypes();
      this.gobalTaskForm.get("documentType").setValue([docType]);
    }
    if(docId != ""){
      this.onChangeDocumentType([docType]);
      this.gobalTaskForm.get("documentId").setValue(''+docId);
    }
    this.isSave = true;
    this.iscreate = true;
    this.viewIndividualTaskData = false;
    if(this.currentUser.id != undefined && this.currentUser.id != ""){
    this.onChangeUsers([this.currentUser.id]);
    this.onCloseUrsPopup();
    
    }
  }
  onCloseUrsPopup(){
    this.modal.selectedUsers=this.users.filter(data =>data.selected).map(a => a.id);
    this.gobalTaskForm.get("assignedTo").setValue(this.modal.selectedUsers)
  }
  onChangeUsers(event){
    this.modal.selectedUsers = event;
    this.users.forEach(element =>{element.selected=false;});
    if(this.modal.selectedUsers != undefined){
    this.modal.selectedUsers.forEach(data =>{
      this.users.forEach(element =>{
        if(element.id===data)
            element.selected=true;
      });
    });
  }
  }
  onChangeDocumentType(event: any) {
    let data: ProjectTaskDTO = new ProjectTaskDTO();
    data.selectedDocumentTypes = event
    data.projectVersionId = this.currentUser.versionId;
    this.service.loadAllDocumentIds(data).subscribe(resp => {
      if (resp.result != null) {
        this.mainDocumentTypeList = resp.result;
        this.documentTypeIdList = resp.result.map(option => ({ value: option.key, label: option.value }))
      }
    });
  }
  loadDocumentTypes() {
    
   this.lookUpService.loadDocumentForPdfSetting().subscribe(resp =>{
      if (resp != null) {
        this.documentTypeList = resp.map(option => ({ value: option.key, label: option.value }))
      }
    });
    // this.projectsetupService.loadDocumentOrderList().subscribe(resp => {
    //   if (resp.result != null) {
    //     this.documentTypeList = resp.result.map(option => ({ value: option.documentListId, label: option.documentListName }))
    //   }
    // });
  }
  loadPriorityList() {
    this.lookUpService.getlookUpItemsBasedOnCategory("TaskPrioirty").subscribe(result => {
      this.priorityList = result.response;
    });
  }

  loadTaskCategory(){
    this.lookUpService.getlookUpItemsBasedOnCategory("TaskCategory").subscribe(result => {
      this.taskCategoryList = result.response;
    });
  }
  loadStatusList() {
    this.lookUpService.getlookUpItemsBasedOnCategory("TaskStatus").subscribe(result => {
      this.statusList = result.response;
    });
  }
  onClickCreate() {
    this.isSave = true;
    this.iscreate = true;
    this.isUpdate = false;
    this.gobalTaskForm.reset();
    this.modal.id = 0;
    this.gobalTaskForm.get("priority").setValue("Medium");
    this.gobalTaskForm.get("status").setValue("Open");
    this.gobalTaskForm.get("taskCategory").setValue("Task");
    this.gobalTaskForm.controls['status'].disable();
    this.modal.files = [];
  }
  getMonthFromDate(date:any): any{
    let result;
    if (!this.helper.isEmpty(date)) {
      this.validDate = date;
      result = this.validDate.month;
    } else {
      result = "";
    }
    return result;
  }
  onClickSave() {
    this.submitted=true;
    var dateObj = new Date();
    let currentDate:number = dateObj.getMonth() + 1;
    var currentDay = dateObj.getUTCDate();
    this.validDate = this.gobalTaskForm.get("dueDate").value;
    let selectedDay:number = this.validDate.day;
    let selectedDate = this.getMonthFromDate(this.gobalTaskForm.get("dueDate").value);
    if(currentDate == selectedDate && currentDay > selectedDay){
      swal({
        title: 'Warning!',
        text: 'Selected due date is expired, Please change the due date and try again',
        type: 'warning',
        showConfirmButton: true,
      });
      return
    }
    if(this.gobalTaskForm.valid) {
      this.submitted=false;
    this.populateModal();
    this.spinnerFlag = true;
    let files:FileDTO[]=new Array<FileDTO>();
    for (let index = 0; index < this.fileList.length; index++) {
      let file = this.fileList[index];
      let dto:FileDTO=new FileDTO();
      dto.fileName=file.name;
      files.push(dto);
    }
    this.modal.files=files;
    this.fileUploadDesable = true;
    this.service.createTask(this.modal).subscribe(resp => {
      this.file.uploadFileList(resp.data, this.helper.TASK_CREATION).then(re=>{
        this.fileUploadDesable = false;
        this.disableItems = false;
      if (resp.result === "success") {
        this.spinnerFlag = false;
        let timerInterval;
        if (!this.isUpdate)
          swal({
            title: '',
            text: 'Task Saved Successfully',
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton: false,
            onClose: () => {
              if(!this.createFlag){
              this.iscreate = false;
              }else{
                this.onTaskPopupHide.emit();
                this.onClickCreate();
                this.taskPopupData();
              }
              clearInterval(timerInterval)
            }
            
          });
        else
          swal({
            title: '',
            text: 'Task Updated Successfully',
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton: false,
            onClose: () => {
              this.fileUploadDesable = false;
              this.disableItems = false;
              this.iscreate = false;
              clearInterval(timerInterval)
            }
          });
        // this.uploadFileList(resp.data.id);
      } else {
        this.spinnerFlag = false;
        this.disableItems = false;
        this.fileUploadDesable = false;
        swal({
          title: 'Error',
          text: 'Task has not been saved.',
          type: 'error',
          timer: this.helper.swalTimer,
          showConfirmButton: false,
        });
      }
    },
      err => {
        this.spinnerFlag = false;
        this.disableItems = false;
        this.fileUploadDesable = false;
        swal({
          title: 'Error',
          text: 'Task has not been saved.',
          type: 'error',
          timer: this.helper.swalTimer,
          showConfirmButton: false,
        });
      });
    }
    );
    }
  }

  populateModal() {
    this.modal.loginUserId = this.currentUser.id;
    this.modal.globalProjectId = this.currentUser.projectId;
    this.modal.projectVersionId = this.currentUser.versionId
    this.modal.taskTitle = this.gobalTaskForm.get("taskTitle").value;
    this.modal.priority = this.gobalTaskForm.get("priority").value;
    this.modal.taskCategory = this.gobalTaskForm.get("taskCategory").value;
    this.modal.status = "Open";
    this.modal.selectedUsers = this.gobalTaskForm.get("assignedTo").value;
    this.modal.description = this.gobalTaskForm.get("description").value;
    this.modal.remainderFlag = this.gobalTaskForm.get("remainderFlag").value;
    this.modal.frequency = this.gobalTaskForm.get("frequency").value;
    //this.modal.dueDate = this.populateSaveDate(this.gobalTaskForm.get("dueDate").value);
    this.modal.dueDate = this.datePipe.transform(new Date(this.gobalTaskForm.get("dueDate").value), 'yyyy-MM-dd hh:mm:ss');

    this.modal.equipmentId = this.gobalTaskForm.get("selectedEquipment").value;
    this.projectTaskDocuments = new Array<ProjectTaskDocuments>();
    let selectedDocumentTypes = this.gobalTaskForm.get("documentType").value;
    let selectedDocumentIds = this.gobalTaskForm.get("documentId").value;
    if(this.createFlag){
      selectedDocumentIds = [this.gobalTaskForm.get("documentId").value];
    }
    
    if (!this.helper.isEmpty(selectedDocumentTypes)) {
      selectedDocumentTypes.forEach(type => {
        let dto: ProjectTaskDocuments = new ProjectTaskDocuments();
        dto.documentType = type;
        let ids: ProjectTaskDocumentsIdDTO[] = new Array<ProjectTaskDocumentsIdDTO>();
        if (!this.helper.isEmpty(selectedDocumentIds)) {
          selectedDocumentIds.forEach(id => {

            this.mainDocumentTypeList.forEach(element => {
              if (element.key === id && element.documentType === type) {
                let dto: ProjectTaskDocumentsIdDTO = new ProjectTaskDocumentsIdDTO();
                dto.documentId = element.key;
                dto.documentCode = element.value;
                ids.push(dto);
              }
            });
          });
        }
        dto.selectedDocumentIds = ids;
        this.projectTaskDocuments.push(dto);
      });
      this.modal.documents = this.projectTaskDocuments;
    }
  }
  loadOrgDateFormat() {
    this.servie.getOrgDateFormatForDatePicker().subscribe(result => {
        if (!this.helper.isEmpty(result)) {
            this.pattern = result.replace("y","Y");
        }
    });
  }
  loadOrgDateFormatAndTime() {
    this.servie.getOrgDateFormat().subscribe(result => {
        if (!this.helper.isEmpty(result.datePattern)) {
          this.datePipeFormat=result.datePattern.replace("mm", "MM")
          this.datePipeFormat=this.datePipeFormat.replace("YYYY", "yyyy");
        }
    });
}
  populateSaveDate(date: any): any {
    let result;
    if (!this.helper.isEmpty(date)) {
      this.validDate = date;
      result = this.validDate.day + "-" + this.validDate.month + "-" + this.validDate.year;
    } else {
      result = "";
    }
    return result;
  }
  enableItems(){
    if(this.disableItems){
      this.disableItems = false;
      this.fileUploadDesable = false;
    }else{
      this.disableItems = true;
      this.fileUploadDesable = true;
    }
    
  }
}
