import { Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { AdminComponent } from '../../layout/admin/admin.component';
import { CommonModel, ModulePermissionDto, UserPrincipalDTO, UserShortcutsDTO } from '../../models/model';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { DateFormatSettingsService } from '../date-format-settings/date-format-settings.service';
import { projectsetupService } from '../projectsetup/projectsetup.service';
import { HomeService } from './home.service';
import swal from 'sweetalert2';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  spinning=false;
  now:Date=new Date();
  public user: UserPrincipalDTO = new UserPrincipalDTO();
  public enableData:UserShortcutsDTO = new UserShortcutsDTO();
  public spinnerFlag = false;
  currentTime: any;
  message: any;
  modulesList: any[] = new Array();
  taskList:any[] = new Array();
  equipmentList:any[] = new Array();
  recentActivites:any[]=new Array();
  approvalCount:any[]= new Array();
  timeZone: string = "";
  FTPFileSize: string = "";
  modal: CommonModel = new CommonModel();
  public Response: any;
  public userModules:Array<ModulePermissionDto> = [];
  public searchText:any;
  public searchErrorMes:string = '';
  dashboardDropDownmenu: any[] = new Array();
    ebmrList: any[] = new Array();
    dashboardDropDownselectedDropdown: any[] = new Array();
    dashboardDropDownselectedforms: any[] = new Array();
    dashboardDropDownselectedtemplate: any[] = new Array();
    dashboardModulePermission: any[] = new Array();
    auditTrailList: any;
    workflowList: any;
    filteredList: string[] = [];
    list: string[] = [];
    listHidden = true;
  showError = false;
  selectedIndex = -1;
  constructor(public adminComponent: AdminComponent,
    public projectsetupService: projectsetupService,
    public helper: Helper, private servie: DateFormatSettingsService,
    public config: ConfigService, public homeService: HomeService, private router: Router) {
     this.adminComponent.globalProjectObservable.subscribe(resp => {
       this.adminComponent.setUpModuleForHelpContent('');
        this.spinnerFlag=true;
        this.modal.globalProjectName = resp.value;
        this.modal.globalProjectId =+ resp.key;
        this.adminComponent.loadnavBar();
          this.adminComponent.loadCurrentUserDetails().then(currentUser => {
            this.user = currentUser;
            this.loadOnPageRefresh().then(() => {
              this.spinnerFlag = false;
            }).catch(() => this.spinnerFlag = false);
          
        })
      });
      
    setInterval(() => {
     this.now=new Date();
      if(this.timeZone!=""){
        let aestTime = new Date(this.now).toLocaleTimeString("en-US", {timeZone: this.timeZone});
        this.currentTime= aestTime;
        }
    }, 1);
  }

  ngOnInit() {
    this.loadOrgDateFormat();
    this.adminComponent.taskDocType = "";
    this.adminComponent.taskDocTypeUniqueId = "";
    this.adminComponent.taskEquipmentId = 0;
    this.adminComponent.taskEnbleFlag = true;
  }

  loadOnPageRefresh():Promise<void>{
    var curHr =this.now.getHours()
    if (curHr < 12) {
      this.message = 'Good Morning!';
    } else if (curHr < 18) {
      this.message = 'Good Afternoon!';
    } else {
      this.message = 'Good Evening!';
    }
    return new Promise<void>(resolve=>{
     
      this.loadUserShortCutEnableData().then(()=>{
        this.taskList = new Array();
        this.equipmentList = new Array();
        this.recentActivites=new Array();
        this.approvalCount= new Array();
        if(this.enableData.tasks)
        this.loadTaskDetailsOfTheUser();
        
        if(this.enableData.equipments)
        this.loadEquipmentListOfUserAndPeriod();
        
        if(this.enableData.userApprovalCount)
        this.loadApprovalCountOfDocument();

        this.loaduserShortcutModules();

        this.loadUserActions();
        this.loadUserModules();
        resolve();
      })
    })
    
    
  }

  loadUserShortCutEnableData():Promise<void>{
    return new Promise<void>(resolve=>{
      this.homeService.loadUserShortCutEnableData().subscribe(response=>{
        if('success'==response.result)
        this.enableData = response.userShortcuts;
        resolve();
      },err=>{resolve()})
    })
  }


  loadTaskDetailsOfTheUser(){
    this.taskList=[];
    this.homeService.loadTaskDetailsOfTheUser().subscribe(response => {
      if('success'==response.result)
      this.taskList =  response.tasks;
    });
  }

  loadEquipmentListOfUserAndPeriod(){
    this.equipmentList=[];
    this.homeService.loadEquipmentListOfUserAndPeriod().subscribe(response => {
      if('success'==response.result)
      this.equipmentList =  response.equipments;
    });
  }
  loaduserShortcutModules() {
    this.modulesList=[];
    this.homeService.loaduserShortcutModules().subscribe(response => {
      if(response.result){
        this.modulesList = response.userShortcuts;
      }
    });
  }
  loadUserModules(){
    this.searchErrorMes = '';
    this.filteredList = [];
    this.list = [];
    this.homeService.loadUserModules().subscribe(res =>{
       this.userModules = res;
       this.userModules.forEach((element) =>{
          this.filteredList.push(element.moduleName);
          this.list.push(element.moduleName);
       });
    });
  }

  loadApprovalCountOfDocument(){
    this.approvalCount= new Array();
      this.homeService.loadApprovalCountOfDocument().subscribe(response => {
        if(response.result == 'success'){
            this.approvalCount = response.userApprovalsCount;
        }
    });
  }
  loadUserActions(){
    this.recentActivites=new Array();
    this.homeService.loaduserLastActions().subscribe(response => {
      if(response.result == 'success'){
        if(this.enableData.userDocuments)
           this.recentActivites = response.userDocuments;
      }
    });
  }
  getFilteredList() {
    this.listHidden = false;
    // this.selectedIndex = 0;
    if (!this.listHidden && this.searchText !== undefined) {
      this.filteredList = this.list.filter((item) => item.toLowerCase().startsWith(this.searchText.toLowerCase()));
    }
    if(this.filteredList.length==0)
    this.showError = true;
    else
    this.showError = false;
  }

  selectItem(ind) {
    this.searchText = this.filteredList[ind];
    this.listHidden = true;
    this.selectedIndex = ind;
    this.moduleSearch();
  }

  onKeyPress(event) {
    if (!this.listHidden) {
      if (event.key === 'Escape') {
        this.selectedIndex = -1;
        this.toggleListDisplay(0);
      }

      if (event.key === 'Enter') {

        this.toggleListDisplay(0);
      }
      if (event.key === 'ArrowDown') {

        this.listHidden = false;
        this.selectedIndex = (this.selectedIndex + 1) % this.filteredList.length;
        if (this.filteredList.length > 0 && !this.listHidden) {
          document.getElementsByTagName('list-item')[this.selectedIndex].scrollIntoView();
        }
      } else if (event.key === 'ArrowUp') {

        this.listHidden = false;
        if (this.selectedIndex <= 0) {
          this.selectedIndex = this.filteredList.length;
        }
        this.selectedIndex = (this.selectedIndex - 1) % this.filteredList.length;

        if (this.filteredList.length > 0 && !this.listHidden) {

          document.getElementsByTagName('li')[this.selectedIndex].scrollIntoView();
        }
      }
    } 
  }
  toggleListDisplay(sender: number) {
    if (sender === 1) {
      // this.selectedIndex = -1;
      this.listHidden = false;
      this.getFilteredList();
    } else {
      // helps to select item by clicking
      setTimeout(() => {
      
        this.selectItem(this.selectedIndex);
        this.listHidden = true;
        if (!this.list.includes(this.searchText)) {
          this.showError = true;
          this.filteredList = this.list;
        } else {
          this.showError = false;
        }
        if(this.selectedIndex == -1){
          this.showError = false;
         }
      }, 500);
    }
  }
  
  moduleSearch(){
    this.searchErrorMes= '';
    let url:any;
    for(let i=0; i<this.userModules.length; i++){
      if(this.userModules[i].moduleName == this.searchText){
        url=this.userModules[i].url;
      }
  }
  if(url != undefined && url !='')
      this.redirect(url);
  else
    this.searchErrorMes = "Search string is not found, please try with curect string"
  }
 
  urlRedirect(data:any) {
    if(!data.mappingFlag){
      this.config.checkIndividualModulePermission(data.key).subscribe(resp => {
        if(resp){
          this.redirect(data.url);
        }else{
          swal(
            'Warning!',
            'You do not have permisison to view this page!',
            'error'
          ).then(responseMsg => {
            
          });
        }
    });
    }else{
      this.config.checkGroupFormModulePermission(data.mappingId).subscribe(resp => {
        if(resp){
          this.redirect(data.url);
        }else{
          swal(
            'Warning!',
            'You do not have permisison to view this page!',
            'error'
          ).then(responseMsg => {
            
          });
        }
    });
    }
  }
  reload() {
    location.reload();
  }
  taskDetails(task){
    this.router.navigate(['/taskCreation'], { queryParams: { id: task.id,url:"/home"}, skipLocationChange: true });
    // this.router.navigateByUrl("/taskCreation");
  }
  activitesData(url:any){
    if(url != null)
       this.router.navigateByUrl(url);
  }
  redirect(url, status?) {
    this.adminComponent.redirect(url, status);
  }
  eqDetails(){
    this.router.navigateByUrl("/equipmentStatusUpdate");
  }
  loadOrgDateFormat() {
    this.servie.getOrgDateFormat().subscribe(result => {
        if (!this.helper.isEmpty(result)) {
            this.timeZone = result.timeZoneId;
            this.FTPFileSize = result.ftpFileSize;
        }
    });
}

}
