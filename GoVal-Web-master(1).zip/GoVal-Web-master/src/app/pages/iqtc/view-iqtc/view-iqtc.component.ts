import { AfterViewInit, Component, Inject, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { ChartOptions } from 'chart.js';
import swal from 'sweetalert2';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { WorkflowDocumentStatusDTO } from '../../../models/model';
import { Permissions } from '../../../shared/config';
import { ConfigService } from '../../../shared/config.service';
import { TestCaseType } from '../../../shared/constants';
import { Helper } from '../../../shared/helper';
import { DocumentStatusCommentLogComponent } from '../../document-status-comment-log/document-status-comment-log.component';
import { FileUploadForDocComponent } from '../../file-upload-for-doc/file-upload-for-doc.component';
import { ImageviewComponent } from '../../imageview/imageview.component';
import { projectsetupService } from '../../projectsetup/projectsetup.service';
import { ScreenShotComponent } from '../../screen-shot/screen-shot.component';
import { VideoViewerComponent } from '../../video-viewer/video-viewer.component';
import { ViewTestcaseFileListComponent } from '../../view-testcase-file-list/view-testcase-file-list.component';
import { IQTCService } from '../iqtc.service';
import { StepperClass } from './../../../models/model';


@Component({
    selector: 'app-view-iqtc',
    templateUrl: './view-iqtc.component.html',
    styleUrls: ['./view-iqtc.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
    encapsulation: ViewEncapsulation.None,
})
export class ViewIqtcComponent implements OnInit, AfterViewInit {
    @ViewChild('iqtcTab') tab: any;
    @ViewChild('documentcomments') documentcomments: DocumentStatusCommentLogComponent;
    @ViewChild('viewImageComponent') viewImageComponent: ImageviewComponent;
    @ViewChild('viewVideoComponent') viewVideoComponent: VideoViewerComponent;
    @ViewChild('screenShot') ScreenShot: ScreenShotComponent;
    @ViewChild('fileupload') private file: FileUploadForDocComponent;
    @ViewChild('viewFileOfTestCase')private viewFile : ViewTestcaseFileListComponent;
    
    commonDocumentStatusValue: any;
    spinnerFlag = false;
    data: any=[]=new Array();
    publishedData: any[] = new Array();
    completedData: any[] = new Array();
    testCaseTypes: TestCaseType = new TestCaseType();
    popupdata: any[] = new Array();
    totalSize: any;
    currentDoc: any;
    viewIndividualData: boolean = false;
    public slideIndex = 0;
    model: Permissions = new Permissions('', false);
    
    routeback: any = null;
    roleBack: any = null;
    routebackStatus: any;
    public currentDocType: any;
    public currentDocStatus: any;
    public currentCreatedBy: any;
    public currentModifiedDate: any;
    showCardFlag: boolean = false;
    showRecordCss: boolean = false;
    testCaseCode: any;
    public filteredData: any[] = new Array();
    public filteredPendingDocList: any[] = new Array();
    showAppCard: boolean = true;
    theFlag: boolean = false;
    isSelectedPublishData: boolean = false;
    isSelectedToExecution: boolean = false;
    selectAll:boolean = false;
    imageURL: any;
    videoURL: any;
    selectedVideo: string = "";
    selectedScreenShot: string = "";
    showStatusDropDown = {};
    oldStatus: any = "";
    showPieChart: boolean=false;
    passCount:number=0;
    failCount:number=0;
    inProgressCount:number=0;
    iqtcId:string = 'IQTC';
    naCount:number=0;
    noRunCount:number=0;
    dfCount:number=0;
    pieChartLabels:string[] = ['No Run', 'In-Progress', 'Pass', 'Fail', 'N/A', 'DF'];
    pieChartType:string = 'pie';
    pieChartColors: Array < any > = [{
    backgroundColor: ['#f54296', '#ebe834', '#3D8B37', '#eb5334', '#87CEFA', '#dd42f5'] }];
    chartData:number[] = new Array();
    pieChartOptions: ChartOptions = {
        responsive: false,
        legend: {
          position: 'left',
        },
      };
    isWorkflowDocumentOrderSequence:boolean=false;
    chartDataList: any=[];
    isMultiplePDF: boolean=false;
    pauseSpinner:any;
    search:boolean =true;
    processedChecklistImages=new Array();hideModal=false;
    isTestcaseModulePermission:boolean=false;
    disableSearch:boolean= false;
    constructor(private activeRouter: ActivatedRoute, private renderer2: Renderer2,
        @Inject(DOCUMENT) private _document, public permissionService: ConfigService, public helper: Helper,
        public service: IQTCService, public router: Router, private adminComponent: AdminComponent, private projectsetupService: projectsetupService) {
        this.loadPermissions();
        this.activeRouter.queryParams.subscribe(query => {
            if (!this.helper.isEmpty(query.id)) {
                this.viewRowDetails(query.id, query.status, true)
                if (query.status != undefined) {
                    this.routeback = query.status;
                    this.routebackStatus = query.status;
                } else {
                    this.routeback = null;
                }
                if (query.roleBack != undefined) {
                    this.roleBack = query.roleBack;
                }
            } else {
                this.loaddata();
            }
        })
        this.helper.listen().subscribe((m: any) => {
            this.viewRowDetails(m, "/documentapprovalstatus")
        });
        this.permissionService.isWorkflowDocumentOrderSequence(this.helper.IQTC_VALUE).subscribe(resp => {
            this.isWorkflowDocumentOrderSequence = resp;
          });

    }

    loadPermissions() {
        this.permissionService.loadPermissionsBasedOnModule(this.helper.IQTC_VALUE).subscribe(resp => {
            this.model = resp;
        });
        this.permissionService.checkIndividualModulePermission(this.helper.TEST_CASE_CREATION_VALUE).subscribe(resp => {
            this.isTestcaseModulePermission = resp;
        });
    }

    loaddata(tabId?) {
        this.data =[];
        this.publishedData=[];
        this.completedData=[];
        this.selectAll = false;
        this.isSelectedToExecution = false;
        this.isSelectedPublishData = false;
        var currentTab;
        if (tabId === undefined) {
            if (localStorage.getItem('iqtcTab') != undefined) {
                currentTab = this.helper.decode(localStorage.getItem('iqtcTab'));
            }
        } else {
            currentTab = tabId
        }
        setTimeout(() => {
            this.tab.activeId = currentTab;
        }, 10);
        this.viewIndividualData = false;
        if(currentTab != 'summary' && currentTab !='approve'){
            this.spinnerFlag=true;
            this.service.loadIQTC(this.testCaseTypes.IQTC, currentTab).subscribe(
                jsonResp => {
                    if(jsonResp.unpublishedList && jsonResp.unpublishedList.length >0)
                        this.data = jsonResp.unpublishedList;
                    if(jsonResp.publishedList && jsonResp.publishedList.length >0)
                        this.publishedData = jsonResp.publishedList;
                    if(jsonResp.completedList && jsonResp.completedList.length >0)
                        this.completedData = jsonResp.completedList;
                    if(this.pauseSpinner!='pause')
                    this.spinnerFlag = false;
                    if((this.data.length!=0||this.publishedData.length!=0||this.completedData.length!=0)&&!this.isMultiplePDF){
                        this.permissionService.isMultiplePDF(this.helper.IQTC_VALUE).subscribe(resp => {
                          this.isMultiplePDF = resp;
                        });
                    }
                },
                err => {
                }
            );
    }
}

    ngOnInit() {
        this.adminComponent.setUpModuleForHelpContent(this.helper.IQTC_VALUE);
        this.adminComponent.taskEquipmentId = 0;
        this.adminComponent.taskDocTypeUniqueId = "";
        this.adminComponent.taskDocType = this.helper.IQTC_VALUE;
        this.adminComponent.taskEnbleFlag = true;
        this.activeRouter.queryParams.subscribe(query => {
            if (query.id != undefined) {
                this.adminComponent.taskDocTypeUniqueId = query.id;
            }
        });
    }
    ViewFileList(fileList,isImage){
        if(isImage)
            this.viewFile.viewImage(fileList,isImage);
        else
            this.viewFile.viewVideo(fileList,isImage);
    }

    view(path,isImage){
        if(isImage)
          this.adminComponent.downloadOrViewFile('dummyImage.png',path,true,'ScreenShot Image');
        else
          this.adminComponent.downloadOrViewFile('dummyVideo.webm',path,true,'Recorded Video');
      }

    ngAfterViewInit(): void {
        if (localStorage.getItem('iqtcTab'))
            this.tab.activeId = this.helper.decode(localStorage.getItem('iqtcTab'));
    }

    openSuccessCancelSwal(deleteObj, i) {
        var classObject = this;
        swal({
            title: 'Are you sure?',
            text: 'You wont be able to revert',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success m-r-10',
            cancelButtonClass: 'btn btn-danger',
            allowOutsideClick: false,
            buttonsStyling: false
        }).then(function () {
            classObject.delete(deleteObj, i);
        });
    }

    delete(dataObj, i) {
        this.service.deleteTestCase(dataObj)
            .subscribe((resp) => {
                if (resp.result === "success") {
                    this.theFlag = false;
                    swal({
                        title: 'Deleted!', type: 'success', timer: this.helper.swalTimer, showConfirmButton: false,
                        text: ' Record has been deleted',
                        onClose: () => {
                            if (resp.noData === 'N') {
                                this.viewRowDetails(resp.id,"yes");
                            } else {
                                this.data.splice(i, 1);
                                this.loaddata();
                                this.viewIndividualData = false;
                            }
                        }
                    });
                } else {
                    swal({
                        title: 'Not Deleted!', type: 'error', timer: this.helper.swalTimer,
                        text: ' Record has not been deleted'
                    });
                }
            }, (err) => {
                swal({
                    title: 'Not Deleted!', type: 'error', timer: this.helper.swalTimer,
                    text: ' Record has not been deleted'
                });
            });
    }


    onClickClose() {
        this.adminComponent.taskDocTypeUniqueId = "";
        this.adminComponent.taskEquipmentId = 0;
        setTimeout(() => {
            if (localStorage.getItem('iqtcTab'))
                this.tab.activeId = this.helper.decode(localStorage.getItem('iqtcTab'));
            if ('completed' === this.helper.decode(localStorage.getItem('iqtcTab'))) {
                this.loaddata('completed');
            } else {
                this.loaddata();
            }
        }, 10)
        this.viewIndividualData = false;
        this.isSelectedToExecution = false;
        this.isSelectedPublishData = false;
        this.theFlag = false;
    }

    loadDataBasedViewData(exeFlag: boolean, pubFalg: boolean) {
        if (exeFlag && pubFalg) {
            this.loaddata("completed");
        } else if (exeFlag && !pubFalg) {
            this.loaddata("onGoing");
        } else if (!exeFlag && !pubFalg) {
            this.loaddata("pending");
        }
    }

    viewRowDetails(id, status, isRedirection?) {
        this.adminComponent.taskDocTypeUniqueId = id;
        this.adminComponent.taskEquipmentId = 0;
        this.commonDocumentStatusValue = status;
        this.spinnerFlag = true;
        this.popupdata = [];
        this.selectedScreenShot = "";
        this.selectedVideo = "";
        this.service.getDataForEdit(id).subscribe(jsonResp => {
            this.setUpData(jsonResp, isRedirection);
            this.spinnerFlag = false;
        });
    }

    setUpData(jsonResp, isRedirection?) {
        this.spinnerFlag = true;
        setTimeout(()=>{
            this.file.loadFileListForEdit(jsonResp.result.id, jsonResp.result.ursCode);
          },1000)
        this.workflowfunction(jsonResp)
        if (jsonResp.result.files.length != 0)
            jsonResp.result.files[0].visible = true;
        jsonResp.result.formData = JSON.parse(jsonResp.result.jsonExtraData);
        if (jsonResp.result.executionFlag && jsonResp.result.publishedflag) {
            this.filteredPendingDocList = jsonResp.pendingList;
        }
        this.totalSize = jsonResp.total;
        this.currentDoc = jsonResp.current;
        if (!jsonResp.result.executionFlag && !jsonResp.result.publishedflag) {
            this.isSelectedToExecution = true;
            if(this.data.length === 0){
                this.service.loadIQTC(this.testCaseTypes.IQTC, 'pending').subscribe(
                    jsonResp => {
                        this.data = jsonResp.unpublishedList;
                    },
                    err => {
                    }
                );
            }
        } else {
            this.isSelectedToExecution = false;
        }
        if (jsonResp.result.executionFlag && !jsonResp.result.publishedflag) {
            this.isSelectedPublishData = true;
        } else {
            this.isSelectedPublishData = false;
        }
        if (isRedirection)
            this.loadDataBasedViewData(jsonResp.result.executionFlag, jsonResp.result.publishedflag);

        for(let item of jsonResp.result.checklist){
            if(item.files.length >0){
                item.files[0].visible=true;
            }
        }
        this.popupdata.push(jsonResp.result);
        this.testCaseCode = jsonResp.result.testCaseCode;
        this.viewIndividualData = true;

        let stepperModule: StepperClass = new StepperClass();
        stepperModule.constantName = jsonResp.result.constantName;
        stepperModule.documentIdentity = jsonResp.result.id;
        stepperModule.code = jsonResp.result.testCaseCode;
        stepperModule.publishedFlag = jsonResp.result.publishedflag;
        stepperModule.creatorId = jsonResp.result.creatorId;
        stepperModule.lastupdatedTime= jsonResp.result.updatedTime;
        stepperModule.displayCreatedTime= jsonResp.result.displayCreatedTime;
        stepperModule.displayUpdatedTime= jsonResp.result.displayUpdatedTime;
        stepperModule.documentTitle= jsonResp.result.description;
        stepperModule.createdBy= jsonResp.result.createdBy;
        stepperModule.updatedBy= jsonResp.result.updatedBy;
        this.helper.stepperchange(stepperModule);
        this.spinnerFlag = false;
    }

    workflowfunction(jsonResp: any) {
        if (jsonResp.result.publishedflag) {
            const workflowmodal: WorkflowDocumentStatusDTO = new WorkflowDocumentStatusDTO();
            workflowmodal.documentType = this.helper.IQTC_VALUE;
            workflowmodal.documentId = jsonResp.result.id;
            workflowmodal.currentLevel = jsonResp.result.currentCommonLevel;
            workflowmodal.documentCode = jsonResp.result.testCaseCode;
            workflowmodal.workflowAccess = jsonResp.result.workflowAccess;
            workflowmodal.docName = 'IQTC';
            workflowmodal.publishFlag = jsonResp.result.publishedflag;
            this.helper.setIndividulaWorkflowData(workflowmodal);
        }
    }

    actionList(testCaseCode) {
        this.filteredData = [];
        this.filteredPendingDocList.forEach(element => {
            if (testCaseCode === element.documentCode) {
                this.filteredData.push(element);
            }
        })
    }

    defaultSetup() {
        this.commonDocumentStatusValue = status;
        this.spinnerFlag = true;
        this.popupdata = [];
        this.selectedScreenShot = "";
        this.selectedVideo = "";
    }

    onclickLast(data) {
        if (!data.navigationNextEnds) {
            this.defaultSetup();
            this.spinnerFlag = true;
            this.service.getLastData(data.id).subscribe(jsonResp => {
                this.setUpData(jsonResp);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickFirst(data) {
        if (!data.navigationPreviousEnds) {
            this.defaultSetup();
            this.spinnerFlag = true;
            this.service.getFirstData(data.id).subscribe(jsonResp => {
                this.setUpData(jsonResp);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickPrevious(data) {
        if (!data.navigationPreviousEnds) {
            this.defaultSetup();
            this.spinnerFlag = true;
            this.service.getPreviousData(data.id).subscribe(jsonResp => {
                this.setUpData(jsonResp);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickNext(data) {
        if (!data.navigationNextEnds) {
            this.defaultSetup();
            this.spinnerFlag = true;
            this.service.getNextData(data.id).subscribe(jsonResp => {
                this.setUpData(jsonResp);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    plusSlides(n) {
        if (n == 1) {
            let prev = this.slideIndex;
            let next = this.slideIndex + 1;
            if (next < this.popupdata[0].files.length) {
                this.popupdata[0].files[this.slideIndex].visible = false;
                this.popupdata[0].files[++this.slideIndex].visible = true;
            } else {
                this.popupdata[0].files[this.slideIndex].visible = false;
                this.popupdata[0].files[0].visible = true;
                this.slideIndex = 0;
            }
        } else {
            let prev = this.slideIndex - 1;
            let next = this.slideIndex;
            if (prev < 0) {
                this.popupdata[0].files[this.slideIndex].visible = false;
                this.popupdata[0].files[this.popupdata[0].files.length - 1].visible = true;
                this.slideIndex = this.popupdata[0].files.length - 1;
            } else {
                this.popupdata[0].files[prev].visible = true;
                this.popupdata[0].files[next].visible = false;
                this.slideIndex = prev;
            }
        }
    }

    plusChecklistSlides(n,files) {
        let index = files.findIndex(function (element) {
            return element.visible === true;
          });
        if (n == 1) {
            let next = index + 1;
            if (next < files.length) {
               files[index].visible = false;
                files[++index].visible = true;
            } else {
                files[index].visible = false;
                files[0].visible = true;
                index = 0;
            }
        } else {
            let prev = index - 1;
            let next =index;
            if (prev < 0) {
                files[index].visible = false;
                files[files.length - 1].visible = true;
                index = files.length - 1;
            } else {
                files[prev].visible = true;
                files[next].visible = false;
                index = prev;
            }
        }
    }

    excelExport() {
        this.service.excelExport(1).subscribe(resp => {
            if (resp.result) {
                this.adminComponent.previewOrDownloadByBase64(resp.sheetName + ".xls", resp.sheet, false);
            }
        })
    }

    loadDocumentCommentLog(row) {
        row.constantName = this.helper.IQTC_VALUE;
        this.documentcomments.loadDocumentCommentLog(row);
    }

    publishData() {
        this.spinnerFlag = true;
        this.service.publishTestCases(this.publishedData).subscribe(result => {
            this.isSelectedPublishData = false;
            this.theFlag = false;
            this.loaddata();
            this.spinnerFlag = false;
        });
    }

    onChangePublishData() {
        for (let data of this.publishedData) {
            if (data.publishedflag) {
                this.isSelectedPublishData = true;
                break;
            } else {
                this.isSelectedPublishData = false;
            }
        }
    }

    publishToExecution() {
        this.spinnerFlag = true;
        this.service.publishTestCasesToExecution(this.data).subscribe(result => {
            this.isSelectedToExecution = false;
            this.theFlag = false;
            this.loaddata();
            this.spinnerFlag = false;
        });
    }
    onChangeToExecutionData() {
        for (let data of this.data) {
            if (data.executionFlag) {
                this.isSelectedToExecution = true;
                break;
            } else {
                this.isSelectedToExecution = false;
            }
        }
    }

    publishOrSubmitForApprove(data) {
        var classObject = this;
        swal({
            title: 'Are you sure?',
            text: 'You wont be able to revert',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success m-r-10',
            cancelButtonClass: 'btn btn-danger',
            allowOutsideClick: false,
            buttonsStyling: false
        }).then(function () {
            classObject.publishIndividualData(data);
        });
    }

    publishIndividualData(data) {
        this.defaultSetup();
        this.spinnerFlag = true;
        if (!data.publishedflag && !data.executionFlag) {
            this.data.forEach(element => {
                if (element.id === data.id) {
                    element.executionFlag = true;
                }
            });
            this.service.publishTestCasesToExecution(this.data).subscribe(resp => {
                this.isSelectedToExecution = false;
                this.theFlag = false;
                if (resp.result != null)
                    this.setUpData(resp);
                else
                    this.onClickClose();
                this.spinnerFlag = false;
            });
        } else if (!data.publishedflag && data.executionFlag) {
            this.publishedData.forEach(element => {
                if (element.id === data.id) {
                    element.publishedflag = true;
                }
            });
            this.service.publishTestCases(this.publishedData).subscribe(resp => {
                this.isSelectedPublishData = false;
                this.theFlag = false;
                if (resp.result != null)
                    this.setUpData(resp);
                else
                    this.onClickClose();
                this.spinnerFlag = false;
            });
        }
    }

    show(row) {
        this.adminComponent.openModalForScreenrecording(row, null, "/iqtc/view-iqtc", null);
    }

    

    hide() {
        this.showCardFlag = false;
        this.showRecordCss = false;
        this.showAppCard = true;
        setTimeout(() => {
            if (localStorage.getItem('iqtcTab'))
                this.tab.activeId = this.helper.decode(localStorage.getItem('iqtcTab'));
        }, 10)
        this.loaddata();
    }

    reload(reload?) {
        this.loaddata();
        this.closeView();
    }

    closeView(value?) {
        this.imageURL = "";
        this.selectedScreenShot = "";
        this.selectedVideo = "";
        this.videoURL = ""
    }

    loadVideo(id) {
        this.spinnerFlag = true;
        this.service.loadVideoFile(id, this.selectedVideo).subscribe(jsonResp => {
            if(jsonResp!=null){
                this.adminComponent.downloadOrViewFile('dummyVideo.webm',jsonResp.path,true,'Recorded Video');
            }
        });
        this.spinnerFlag = false;
    }

    loadImage(id) {
        this.spinnerFlag = true;
        this.service.loadImageFile(id, this.selectedScreenShot).subscribe(jsonResp => {
            this.imageURL = jsonResp.image;
            this.viewImageComponent.openView(this.imageURL);
            this.spinnerFlag = false;
        },error=>this.spinnerFlag = false);
        
    }


    public loadScript() {
        var isFound = false;
        var scripts = document.getElementsByTagName("script")
        for (var i = 0; i < scripts.length; ++i) {
            if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes("loader")) {
                isFound = true;
            }
        }

        if (!isFound) {
            var dynamicScripts = ["https://widgets.skyscanner.net/widget-server/js/loader.js"];
            for (var i = 0; i < dynamicScripts.length; i++) {
                let node = document.createElement('script');
                node.src = dynamicScripts[i];
                node.type = 'text/javascript';
                node.async = false;
                node.charset = 'utf-8';
                document.getElementsByTagName('head')[0].appendChild(node);
            }

        }
    }

    editStatus(rowIndex, status) {
        if (status != "Fail") {
            this.oldStatus = status;
            for (let index = 0; index < this.publishedData.length; index++) {
                if (rowIndex == index)
                    this.showStatusDropDown[index] = true;
                else
                    this.showStatusDropDown[index] = false;
            }
        }
    }

    changeStatus(status, id, index) {
        this.showStatusDropDown[index] = false;
        var obj = this
        swal({
            title: 'Are you sure?',
            text: 'You want to update the status to ' + status,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, update it!',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success m-r-10',
            cancelButtonClass: 'btn btn-danger',
            allowOutsideClick: false,
            buttonsStyling: false
        }).then((result) => {
            obj.updateStatus(status, id);
            this.showStatusDropDown[index] = false;
        }).catch(() => {
            this.publishedData[index].status = this.oldStatus;
        });
        this.showStatusDropDown[index] = false;
    }

    updateStatus(status, id) {
        this.spinnerFlag = true;
        this.service.updateStatus(status, id).subscribe(jsonResp => {
            if (jsonResp.result === "success") {
                swal({
                    title: 'Updated Successfully!', type: 'success',
                    timer: this.helper.swalTimer, showConfirmButton: false,
                    text: ' Status has been updated',
                });
                this.loaddata();
                this.spinnerFlag = false;
            } else {
                swal({
                    title: 'Update Failed!', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false,
                    text: ' Status has not been updated. Try again!',
                });
                this.spinnerFlag = false;
            }
        });
    }


    screenShotComponent(row) {
        this.ScreenShot.screenShot(row.testCaseCode, row.id, null);
    }

    tabChange(id: any) {
        this.search=false;
        this.isSelectedToExecution = false;
        this.isSelectedPublishData = false;
        if (id === "pending" || id === "onGoing" || id === "completed") {
            this.search=true;
            this.loaddata(id);
        }
        if(id === "iqtcmatrix"){
            this.disableSearch = true;
        }else{
            this.disableSearch = false;
        }
        
    }
   
    selectAllData(event){
        this.selectAll = event.currentTarget.checked;
        if(event.currentTarget.checked){
          this.data.forEach(d => {
            d.executionFlag = true;
          });
          this.isSelectedToExecution = true;
        }else{
          this.data.forEach(d => {
            d.executionFlag = false;
          });
          this.isSelectedToExecution=false;
        }
      }

      selectAllDataForSubmit(event){
        if(event.currentTarget.checked){
          this.publishedData.forEach(d => {
            if((d.status === 'Fail')||(d.status === null || d.status === '') || (d.status === 'In-Progress')){
                d.publishedflag = false;
            }else{
                d.publishedflag = true;
                this.isSelectedPublishData = true;
            }
          });
        }else{
          this.publishedData.forEach(d => {
            d.publishedflag = false;
          });
          this.isSelectedPublishData=false;
        }
      }

      getColors(rowData) {
        if (rowData == 'In-Progress')
            return '#ebe834 ';
        else if (rowData == 'Pass')
            return '#3D8B37';
        else if (rowData == 'Fail')
            return '#eb5334';
        else if(rowData == 'NA')
            return '#87CEFA'
    }
    getNoRunColor(){
        return '#f54296';
    }
     
     /**
   * @param flag => view or download
   * @param extention =>doc/docx
   */
  documentPreview(flag, extention,data) {
    this.spinnerFlag = true;
    data.downloadDocType = extention;
    this.service.loadPreviewDocument(data).subscribe(resp => {
      this.spinnerFlag = false;
      if (resp != null) {
        this.adminComponent.previewByBlob(data.testCaseCode + '.' + extention, resp, flag, 'IQTC Preview');
      }
    }, err => this.spinnerFlag = false);
  }
  multipleDocumentPreview(flag, extention) {
    this.spinnerFlag = true;
    this.service.loadPreviewForMultipleDocument(extention,this.helper.IQTC_VALUE).subscribe(resp => {
      this.spinnerFlag = false;
      if (resp != null) {
        this.adminComponent.previewByBlob('IQTC' + '.' + extention, resp, flag, 'IQTC Preview');
      }
    }, err => this.spinnerFlag = false);
  }
  createTestCase(){
      if(this.model.createButtonFlag && this.model.userInWorkFlow && this.isTestcaseModulePermission){
        this.router.navigate(["/testCaseCreation"], { queryParams: {type:'IQTC'}})
      }else{
        swal({
            title: 'Warning!', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false,
            text:!this.model.createButtonFlag?"You don't have create permission. Please contact admin!.":"Testcase creation module permission is disabled. Please contact admin!.",
        });
      }  
  }
}