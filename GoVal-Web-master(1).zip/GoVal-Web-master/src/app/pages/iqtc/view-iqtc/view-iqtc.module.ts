import { SharedModule } from '../../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UiSwitchModule } from 'ng2-ui-switch/dist';
import { TagInputModule } from 'ngx-chips';
import { Helper } from '../../../shared/helper';
import { HttpModule } from '@angular/http';

import { ViewIqtcComponent } from './view-iqtc.component';
import { NgxDatatableModule } from '../../../../../node_modules/@swimlane/ngx-datatable';
import { IQTCService } from '../iqtc.service';
import { SqueezeBoxModule } from 'squeezebox';
import { FileUploadModule } from "ng2-file-upload";
import { DocumentsignComponentModule } from '../../documentsign/documentsign.module';
import { stepperProgressModule } from './../../stepperprogress/stepperprogress.module';
import { SharedCommonModule } from '../../../shared/SharedCommonModule';
import {ScreenShot} from '../../screen-shot/screen-shot.module'
import {ImageviewModule} from '../../imageview/imageview.module';
import {VideoViewerModule} from '../../video-viewer/video-viewer.module'
import {DocumentStatusCommentLog} from '../../../pages/document-status-comment-log/document-status-comment-log.module'
import { QuillEditorModule } from 'ngx-quill-editor';
import { FileUploadForDocService } from '../../file-upload-for-doc/file-upload-for-doc.service';
import { ViewTestcaseFileListModule } from '../../view-testcase-file-list/view-testcase-file-list.module';
import { UrsViewModule } from '../../urs-view/urs-view.module';
import { DocumentForumModule } from '../../document-forum/document-forum.module';
import { ChartsModule } from 'ng2-charts';
import { IndividualAuditModule } from '../../individual-audit-trail/individual-audit-trail.module';
import { AuditTrailViewModule } from '../../audit-trail-view/audit-trail-view.module';
import { DynamicFormService } from '../../dynamic-form/dynamic-form.service';
import { projectsetupService } from '../../projectsetup/projectsetup.service';
import { IndividualDocumentSummaryModule } from '../../individual-document-summary/individual-document-summary.module';
import { IndividualDocumentWorkflowModule } from '../../individual-document-workflow/individual-document-workflow.module';
import { GobalTraceModule } from '../../gobal-traceability-matrix/gobal-traceability-matrix.module';
export const ViewIqtcRoutes: Routes = [
    {
        path: '',
        component: ViewIqtcComponent
    }
];
@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( ViewIqtcRoutes ),
        SharedModule,
        FormsModule,
        
        ReactiveFormsModule,
        UiSwitchModule,
        TagInputModule,
        HttpModule,
        NgxDatatableModule,
        SqueezeBoxModule,
        FileUploadModule,
        DocumentsignComponentModule,
        stepperProgressModule,
        DocumentForumModule,
        SharedCommonModule,DocumentStatusCommentLog,ScreenShot,ImageviewModule,
        VideoViewerModule,
        QuillEditorModule,
        ViewTestcaseFileListModule,
        UrsViewModule,
        GobalTraceModule,
        ChartsModule,IndividualAuditModule,AuditTrailViewModule, IndividualDocumentWorkflowModule,IndividualDocumentSummaryModule,
        
    ],
    declarations: [ViewIqtcComponent],
    providers: [Helper, IQTCService, FileUploadForDocService,DynamicFormService,projectsetupService]
} )
export class ViewIqtcModule { }
