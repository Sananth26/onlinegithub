import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-iqtc',
  templateUrl: './iqtc.component.html',
  styleUrls: ['./iqtc.component.css']
})
export class IqtcComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
