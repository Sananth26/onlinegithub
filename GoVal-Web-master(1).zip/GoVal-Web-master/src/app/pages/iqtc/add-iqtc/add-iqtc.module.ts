import { SharedModule } from '../../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UiSwitchModule } from 'ng2-ui-switch/dist';
import { TagInputModule } from 'ngx-chips';
import { Helper } from '../../../shared/helper';
import { HttpModule } from '@angular/http';
import { AddIqtcComponent } from './add-iqtc.component';
import { IQTCService } from '../iqtc.service';
import {UrsService} from '../../urs/urs.service';
import { SelectModule } from 'ng-select';
import { FileUploadModule } from 'ng2-file-upload';
import {QuillEditorModule} from 'ngx-quill-editor';
import { SharedCommonModule} from './../../../shared/SharedCommonModule';
import { FormWizardModule } from 'angular2-wizard';
import { MasterControlService } from '../../master-control/master-control.service';
import { FileUploadForDocService } from '../../file-upload-for-doc/file-upload-for-doc.service';
import { UrsViewModule } from '../../urs-view/urs-view.module';
import { LookUpService } from '../../LookUpCategory/lookup.service';

export const addIqtcRoutes: Routes = [
    {
        path: '',
        component: AddIqtcComponent
        
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( addIqtcRoutes ),
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        UiSwitchModule,
        TagInputModule,
        HttpModule,
        SelectModule,FileUploadModule,
        QuillEditorModule,
        SharedCommonModule,
        FormWizardModule,UrsViewModule
    ],
    declarations: [],
    providers: [Helper, IQTCService, UrsService,
        MasterControlService, DatePipe, FileUploadForDocService, LookUpService]
})
export class AddIqtcModule { }
