import { AfterViewInit, Component, Inject, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { IOption } from 'ng-select';
import swal from 'sweetalert2';
import { ActivatedRoute, Router } from '../../../../../node_modules/@angular/router';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { CheckListTestCaseDTO, IQTC, UserPrincipalDTO } from '../../../models/model';
import { Permissions } from '../../../shared/config';
import { ConfigService } from '../../../shared/config.service';
import { TestCaseType } from '../../../shared/constants';
import { Helper } from '../../../shared/helper';
import { FileUploadForDocComponent } from '../../file-upload-for-doc/file-upload-for-doc.component';
import { FormExtendedComponent } from '../../form-extended/form-extended.component';
import { LookUpService } from '../../LookUpCategory/lookup.service';
import { MasterControlService } from '../../master-control/master-control.service';
import { ScreenShotComponent } from '../../screen-shot/screen-shot.component';
import { UrsService } from '../../urs/urs.service';
import { IQTCService } from '../iqtc.service';
declare function initilizer(): any;
declare var getLocalStorageData: any;

@Component({
    selector: 'app-add-iqtc',
    templateUrl: './add-iqtc.component.html',
    styleUrls: ['./add-iqtc.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
    encapsulation: ViewEncapsulation.None
})
export class AddIqtcComponent implements OnInit,AfterViewInit {
    @ViewChild('formExtendedId') private formExtendedComponent: FormExtendedComponent;
    public inputField: any;
    filterQuery='';
    editorSwap: boolean = false;
    modal: IQTC = new IQTC();
    @ViewChild('screenShot') ScreenShot: ScreenShotComponent;
    @ViewChild('fileupload') private file: FileUploadForDocComponent;
    publishingData: any = [];
    loading: boolean = false;
    model: Permissions = new Permissions(this.helper.IQTC_VALUE, false)
    isSelectedPublishData: boolean = false;
    isSelectedToExecution: boolean = false;
    submitted: boolean = false;
    testCaseTypes: TestCaseType = new TestCaseType();
    ursList: any[];
    simpleOption: Array<IOption> = new Array<IOption>();
    receivedId: string = "";
    isImageDispaly: boolean = false;
    selectedImage: string = "";
    exceptionMessage: boolean = false;
    isCheckListEntered: boolean = false;
    isValidDocumentOrder: boolean = false;
    public slideIndex = 0;
    public editor;
    public isFlag: boolean = false;
    htmlContent: string = "";
    selectedFiles: any;
    processedImages: any[]=new Array();
    images: Array<any> = [];
    fileList: any = [];
    isReadOnly: boolean = false;
    spinnerFlag = false;
    totalSize: any;
    currentDoc: any;
    public videoFile: any;
    showAppCard: boolean = true;
    showCardFlag: boolean = false;
    showRecordCss: boolean = false;
    imageURL: any;
    checklistName: string = "";
    isAddChecklist: boolean = false;
    isAddChecklistName: boolean = false;
    permissionData: any
    editing = {};
    freeze: boolean = false;
    freezeSFAbutton: boolean = false;
    currentUser: UserPrincipalDTO = new UserPrincipalDTO();
    selectedUrsIds: any[] = new Array();
    selectedUrsDetails:any[]=new Array();
    isWorkflowDocumentOrderSequence:boolean=false;
    selectedCheckList:any;
    processedChecklistImages: any[] = new Array();
    checkListImages: Array<any> = [];
    @ViewChild('checkListImageModal') checkListImageModal: any;
    @ViewChild('modalSmall') imageModal: any;
    enviroments: any[]= Array();
    constructor(private renderer2: Renderer2,
        @Inject(DOCUMENT) private _document, private comp: AdminComponent, public helper: Helper, public router: Router, public iqtcServices: IQTCService, public ursService: UrsService,
        private route: ActivatedRoute, public permissionService: ConfigService,
         private masterControlService: MasterControlService,public lookUpService:LookUpService) {
        this.permissionService.loadPermissionsBasedOnModule(this.helper.IQTC_VALUE).subscribe(resp => {
            this.model = resp
        });

        this.masterControlService.loadJsonOfDocumentIfActive(this.helper.IQTC_VALUE).subscribe(res => {
            if (res != null)
                this.inputField = JSON.parse(res.jsonStructure);
        });
    }
    ngAfterViewInit(): void {
        if(this.spinnerFlag)
        this.spinnerFlag=false;
    }

    ngOnInit() {
        this.loadEnvironments();
        this.receivedId = this.route.snapshot.params["id"];
        if (this.receivedId !== undefined) {
            this.spinnerFlag = true;
            this.iqtcServices.getDataForEdit(this.receivedId).subscribe(jsonResp => {
                this.totalSize = jsonResp.total;
                this.currentDoc = jsonResp.current;
                this.loadURS().then(() => {
                    this.setData(jsonResp.result);
                }).catch(() => { this.setData(jsonResp.result); })
                this.spinnerFlag = false;
            }, err => {
            });
        }
        this.permissionService.isWorkflowDocumentOrderSequence(this.helper.IQTC_VALUE).subscribe(resp => {
            this.isWorkflowDocumentOrderSequence = resp;
          });

        this.permissionService.loadCurrentUserDetails().subscribe(resp => {
            this.currentUser = resp;
            this.modal.projectName = this.currentUser.projectName;
        });
        this.isImageDispaly = false;
        this.comp.setUpModuleForHelpContent(this.helper.IQTC_VALUE);
        this.comp.taskEquipmentId = 0;
        this.comp.taskDocType = this.helper.IQTC_VALUE;
        this.comp.taskEnbleFlag = true;
    }
    loadURS():Promise<void>{
        return new Promise<void>((resolve) => {
            this.ursService.getUsrListForProject().subscribe(jsonResp => {
                if (!this.helper.isEmpty(jsonResp.result)) {
                    this.ursList = jsonResp.result;
                    this.simpleOption = jsonResp.result.map(option => ({ value: +option.id, label: option.ursCode }));
                }
                resolve()
            }, err => {
                resolve(); this.ursList = [];
            });
        })
    }
    loadEnvironments() {
        this.lookUpService.getlookUpItemsBasedOnCategory("Environment").subscribe(result => {
          this.enviroments = result.response;
        });
      }
    onCloseUrsPopup(flag) {
        if(flag)
        this.selectedUrsIds = this.ursList.filter(data => data.selected).map(a => a.id);
        this.ursService.getUrsDeatils(this.selectedUrsIds).subscribe(resp=>{
            this.selectedUrsDetails = resp.result;
          });
    }
    onChangeURS() {
        this.ursList.forEach(element => { element.selected = false; });
        this.selectedUrsIds.forEach(data => {
            this.ursList.forEach(element => {
                if (element.id === data)
                    element.selected = true;
            });
        });
        this.ursService.getUrsDeatils(this.selectedUrsIds).subscribe(resp=>{
            this.selectedUrsDetails = resp.result;
          });
    }

    onsubmit(formIsValid: any) {
        this.isCheckListEntered = false;
        this.submitted = true;
        this.spinnerFlag = true;
        this.modal.checklist.forEach(checkList => {
            if (this.helper.isEmpty(checkList.checklistName) || this.helper.isEmpty(checkList.displayOrder))
                this.isCheckListEntered = true;
        });
        let valueArr = this.modal.checklist.map(function (item) { return String(item.displayOrder) });
        this.isValidDocumentOrder = valueArr.some(function (item, idx) {
            return valueArr.indexOf(item) != idx
        });
        if (this.isCheckListEntered || this.isValidDocumentOrder) {
            this.submitted = true;
            this.spinnerFlag = false;
            return;
        }
        if (!formIsValid || !this.formExtendedComponent.validateChildForm()) {
            this.submitted = true;
            this.spinnerFlag = false;
            return;
        }
        if (this.modal.ursListData == []) {
            this.exceptionMessage = true;
            return;
        }
        this.modal.testCaseType = this.testCaseTypes.IQTC;
        this.modal.files = this.processedImages;
        this.modal.ursListData = this.selectedUrsIds;
        this.modal.jsonExtraData = JSON.stringify(this.inputField);
        this.modal.isDefault = "false";
        if (this.receivedId !== undefined) {
            this.modal.id = + this.receivedId;
        }
        this.iqtcServices.createIQTC(this.modal).subscribe(jsonResp => {
            this.freeze = false;
            this.freezeSFAbutton = false;
            this.file.uploadFileList(jsonResp.iqtcDTO, this.helper.IQTC_VALUE).then(re => {
                let responseMsg: string = jsonResp.result;
                if (responseMsg === "success") {
                    this.submitted = false;
                    if (this.modal.status === 'Fail')
                        this.freeze = true;
                    if (this.modal.status === '' || this.modal.status === 'In-Progress' || this.modal.status === null)
                        this.freezeSFAbutton = true;
                    this.spinnerFlag = false;
                    swal({
                        title: 'Success',
                        text: 'Installation Qualification Test Case Updated',
                        type: 'success',
                        timer: this.helper.swalTimer,
                        showConfirmButton: false,
                        onClose: () => {

                        }
                    });
                } else {
                    this.spinnerFlag = false;
                    this.submitted = false;
                    swal({
                        title: 'Error!',
                        text: 'Oops something went Worng..',
                        type: 'error',
                        timer: this.helper.swalTimer,
                        showConfirmButton: false
                    }
                    );
                }
            },
                err => {
                    this.spinnerFlag = false;
                    swal({
                        title: 'Error!',
                        text: 'Oops something went Worng..',
                        type: 'error',
                        timer: this.helper.swalTimer,
                        showConfirmButton: false
                    }
                    );
                });
        }
        );

    }

    onClickClose() {
        this.router.navigate(["/iqtc/view-iqtc"]);
    }

    onclickFirst(id) {
       this.resetValue();
        if (!this.modal.navigationPreviousEnds) {
            this.spinnerFlag = true;
            this.iqtcServices.getFirstData(id).subscribe(jsonResp => {
                this.totalSize = jsonResp.total;
                this.currentDoc = jsonResp.current;
                this.setData(jsonResp.result);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickPrevious(id) {
        this.resetValue();
        if (!this.modal.navigationPreviousEnds) {
            this.spinnerFlag = true;
            this.iqtcServices.getPreviousData(id).subscribe(jsonResp => {
                this.totalSize = jsonResp.total;
                this.currentDoc = jsonResp.current;
                this.setData(jsonResp.result);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickNext(id) {
        this.resetValue();
        if (!this.modal.navigationNextEnds) {
            this.spinnerFlag = true;
            this.iqtcServices.getNextData(id).subscribe(jsonResp => {
                this.totalSize = jsonResp.total;
                this.currentDoc = jsonResp.current;
                this.setData(jsonResp.result);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onclickLast(id) {
        this.resetValue();
        if (!this.modal.navigationNextEnds) {
            this.spinnerFlag = true;
            this.iqtcServices.getLastData(id).subscribe(jsonResp => {
                this.totalSize = jsonResp.total;
                this.currentDoc = jsonResp.current;
                this.setData(jsonResp.result);
                this.spinnerFlag = false;
            },
                err => {
                }
            );
        }
    }

    onFileChangeLargeImage(event) {
        this.images = new Array();
        for (let index = 0; index < event.target.files.length; index++) {
            const file: File = event.target.files[index];
            this.iqtcServices.getFileNameAndURL(file).then((res) => {
                let image = { visible: false, fileName: file.name, imageDataUrl: res };
                this.processedImages.push(image);
                this.processedImages[0].visible = true;
                this.modal.fileName = event.target.files[0].name;
                this.isImageDispaly = true;
            });
        }
    }

    plusSlides(n) {
        let index = this.processedImages.findIndex(function (element) {
            return element.visible === true;
          });
        if (n == 1) {
            let next = index + 1;
            if (next < this.processedImages.length) {
                this.processedImages[index].visible = false;
                this.processedImages[++index].visible = true;
            } else {
                this.processedImages[index].visible = false;
                this.processedImages[0].visible = true;
                index = 0;
            }
        } else {
            let prev = index - 1;
            let next =index;
            if (prev < 0) {
                this.processedImages[index].visible = false;
                this.processedImages[this.processedImages.length - 1].visible = true;
                index = this.processedImages.length - 1;
            } else {
                this.processedImages[prev].visible = true;
                this.processedImages[next].visible = false;
                index = prev;
            }
        }
    }


    onEditorCreated(quill) {
        this.editor = quill;
    }


    setData(data: any) {
        this.spinnerFlag = true;
        this.modal = new IQTC();
        this.freeze = false;
        this.freezeSFAbutton = false;
        this.isAddChecklist = true;
        if (data.id != 0) {
            this.modal = data;
            this.receivedId=data.id
            this.file.loadFileListForEdit(data.id,this.modal.testCaseCode);
            if (this.modal.status === 'Fail')
                this.freeze = true;
            if (this.modal.status === '' || this.modal.status === 'In-Progress' || this.modal.status === null)
                this.freezeSFAbutton = true;
            if (!this.modal.executionFlag && !this.modal.publishedflag) {
                this.isSelectedToExecution = true;
            } else {
                this.isSelectedToExecution = false;
            }
            if (this.modal.executionFlag && !this.modal.publishedflag) {
                this.isSelectedPublishData = true;
            } else {
                this.isSelectedPublishData = false;
            }
            this.modal.organizationName = data.orgName;
            if (this.modal.executionFlag) {
                this.isReadOnly = true;
            }
            if (data.files.length != 0) {
                this.modal.files[0].visible = true;
                this.isImageDispaly = true;
            }
            this.processedImages = this.modal.files;
            this.images = this.processedImages;
            this.selectedUrsIds = data["ursListData"].map(d => +d);
            this.selectedUrsIds.forEach(data => {
                this.ursList.forEach(element => {
                    if (element.id === data)
                        element.selected = true;
                });
            });

            this.ursService.getUrsDeatils(this.selectedUrsIds).subscribe(resp=>{
                this.selectedUrsDetails = resp.result;
              });

            if (!this.helper.isEmpty(this.modal.actualResult) && (this.modal.actualResult.includes('<p>')))
                this.editorSwap = true;
            if (data.jsonExtraData != null)
                this.inputField = JSON.parse(data.jsonExtraData);
        }
        this.spinnerFlag = false;
    }
    deleteSlide(){
        let index = this.processedImages.findIndex(function (element) {
            return element.visible === true;
          });
        this.processedImages.splice(index,1);
        this.modal.fileName = "";
        if(this.processedImages.length > 0){
            this.processedImages.forEach(value => {
                value.visible=false;
            });
            this.processedImages[0].visible=true;
        } else {
            this.imageModal.hide();
        }
    }
    deleteAllSlides(){
        this.processedImages=[];
    }

    publishOrSubmitForApprove() {
        var classObject = this;
        swal({
            title: 'Are you sure?',
            text: 'You wont be able to revert',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
            cancelButtonText: 'No, cancel!',
            confirmButtonClass: 'btn btn-success m-r-10',
            cancelButtonClass: 'btn btn-danger',
            allowOutsideClick: false,
            buttonsStyling: false
        }).then(function () {
            classObject.publishIndividualData();
        });
    }

    publishIndividualData() {
        this.resetValue();
        this.publishingData = [];
        if (this.isSelectedToExecution) {
            this.modal.executionFlag = true;
            this.publishingData.push(this.modal);
            this.publishToExecution(this.publishingData);
        } else if (this.isSelectedPublishData) {
            this.modal.publishedflag = true;
            this.publishingData.push(this.modal);
            this.publishData(this.publishingData);
        }
    }

    publishData(data) {
        this.spinnerFlag = true;
        this.iqtcServices.publishTestCases(data).subscribe(resp => {
            this.isSelectedPublishData = false;
            if (resp.result != null) {
                this.totalSize = resp.total;
                this.currentDoc = resp.current;
                this.setData(resp.result);
            } else
                this.onClickClose();
            this.spinnerFlag = false;
        });
    }

    publishToExecution(data) {
        this.iqtcServices.publishTestCasesToExecution(data).subscribe(resp => {
            this.isSelectedToExecution = false;
            if (resp.result != null) {
                this.totalSize = resp.total;
                this.currentDoc = resp.current;
                this.setData(resp.result);
            } else
                this.onClickClose();
        });
    }
    show() {
        this.comp.openModalForScreenrecording(this.modal, null, "/iqtc/add-iqtc", this.receivedId);
        
    }

    hide() {
        this.showCardFlag = false;
        this.showAppCard = true;
        this.showRecordCss = false;
    }

    screenShotEntry() {
        window.scrollTo(0, 0);
        this.ScreenShot.screenShot(this.modal.testCaseCode, this.modal.id, null);
    }

    addCheckList() {
        this.isAddChecklist = true;
        this.isAddChecklistName = true;
    }

    addChecklistItem() {
        this.isCheckListEntered = false;
        this.modal.checklist.forEach(checkList => {
            if (this.helper.isEmpty(checkList.checklistName) || this.helper.isEmpty(checkList.displayOrder))
                this.isCheckListEntered = true;
        });
        if (!this.isCheckListEntered) {
            let data = new CheckListTestCaseDTO();
            data.id = 0;
            data.checklistName = "";
            data.displayOrder = this.modal.checklist.length + 1;
            this.modal.checklist.push(data);
        }
    }

    deleteCheckList(data) {
        this.modal.checklist = this.modal.checklist.filter(event => event !== data);
    }

    /**
   * @param flag => view or download
   * @param extention =>doc/docx
   */
  documentPreview(flag, extention) {
    this.spinnerFlag = true;
    this.modal.downloadDocType = extention;
    this.iqtcServices.loadPreviewDocument(this.modal).subscribe(resp => {
      this.spinnerFlag = false;
      if (resp != null) {
        this.comp.previewByBlob(this.modal.testCaseCode + '.' + extention, resp, flag, 'IQTC Preview');
      }
    }, err => this.spinnerFlag = false);
  }

    resetValue(){
        this.fileList = new Array();
        this.isImageDispaly = false;
        this.editorSwap = false;
        this.submitted = false;
    }

    onChangeCheckListImage(event,item,index) {
        this.processedChecklistImages=  new Array();
        this.checkListImages = new Array();
        for (let index = 0; index < event.target.files.length; index++) {
            const file: File = event.target.files[index];
            this.iqtcServices.getFileNameAndURL(file).then((res) => {
                let image = { visible: false, fileName: file.name, imageDataUrl: res };
                item.files.push(image);
            });
        }
    }
    plusCheckListSlides(n) {
        let index = this.processedChecklistImages.findIndex(function (element) {
            return element.visible === true;
          });
          if (n == 1) {
            let next = index + 1;
            if (next < this.processedChecklistImages.length) {
                this.processedChecklistImages[index].visible = false;
                this.processedChecklistImages[++index].visible = true;
            } else {
                this.processedChecklistImages[index].visible = false;
                this.processedChecklistImages[0].visible = true;
                index = 0;
            }
        } else {
            let prev = index - 1;
            let next =index;
            if (prev < 0) {
                this.processedChecklistImages[index].visible = false;
                this.processedChecklistImages[this.processedChecklistImages.length - 1].visible = true;
                index = this.processedChecklistImages.length - 1;
            } else {
                this.processedChecklistImages[prev].visible = true;
                this.processedChecklistImages[next].visible = false;
                index = prev;
            }
        }
    } 
    showCheckListModal(item:any) {
        this.selectedCheckList=item;
        this.checkListImages=this.selectedCheckList.files;
        this.processedChecklistImages=this.selectedCheckList.files;
        if(this.processedChecklistImages.length > 0){
            this.processedChecklistImages.forEach(element =>{
                element.visible=false;
            })
            this.processedChecklistImages[0].visible=true;
            this.checkListImageModal.show();
        }
    } 
    deleteCheckListSlide(){
        let index = this.processedChecklistImages.findIndex(function (element) {
            return element.visible === true;
          });
        this.processedChecklistImages.splice(index,1);
        if(this.processedChecklistImages.length > 0){
            this.processedChecklistImages.forEach(value => {
                value.visible=false;
            });
            this.processedChecklistImages[0].visible=true;
        } else {
            this.checkListImageModal.hide();
        }
        this.selectedCheckList.files=this.processedChecklistImages;
    }
    deleteCheckListImages(item){
        item.files=new Array();
    }
    onChangecheckList(){
        this.isCheckListEntered=false;
        this.modal.checklist.forEach(checkList =>{
          if(this.helper.isEmpty(checkList.checklistName) ||this.helper.isEmpty(checkList.displayOrder))
            this.isCheckListEntered=true;
        });
      } 
}
