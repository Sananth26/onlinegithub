import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddIqtcComponent } from './add-iqtc.component';

describe('AddIqtcComponent', () => {
  let component: AddIqtcComponent;
  let fixture: ComponentFixture<AddIqtcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddIqtcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddIqtcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
