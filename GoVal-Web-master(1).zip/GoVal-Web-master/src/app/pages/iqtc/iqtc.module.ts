import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../../layout/auth/AuthGuardService';
import { ConfigService } from '../../shared/config.service';
import { SharedModule } from '../../shared/shared.module';
import { DocumentsignComponentModule } from '../documentsign/documentsign.module';
import { IqtcComponent } from './iqtc.component';

export const iqtc: Routes = [
    {
        path: '',
        canActivate: [ AuthGuardService ],
        data: {
            status: false
        },
        children: [
            {
                path: 'add-iqtc',
                loadChildren: './add-iqtc/add-iqtc.module#AddIqtcModule'

            },
            {
                path: 'view-iqtc',
                loadChildren: './view-iqtc/view-iqtc.module#ViewIqtcModule'

            },
            {
                path: 'add-iqtc/:id',
                loadChildren: './add-iqtc/add-iqtc.module#AddIqtcModule'

            },
           
        ]
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( iqtc ),
        SharedModule,
        DocumentsignComponentModule,
    ],
    declarations: [IqtcComponent],
    providers:[ConfigService]
} )
export class IqtcModule { }
