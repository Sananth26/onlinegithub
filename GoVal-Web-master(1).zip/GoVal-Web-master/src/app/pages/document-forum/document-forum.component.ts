import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { Helper } from '../../shared/helper';
import { DocumentForumDTO, UserPrincipalDTO } from '../../models/model'
import { DocumentForumService } from './document-forum.service';
import { ConfigService } from '../../shared/config.service';
import { FormControl } from '@angular/forms';
import swal from 'sweetalert2';
import { resolve } from 'url';
@Component({
  selector: 'app-document-forum',
  templateUrl: './document-forum.component.html',
  styleUrls: ['./document-forum.component.css']
})
export class DocumentForumComponent implements OnInit {
  @ViewChild('commentField')
  commentField: any;
  @ViewChild('replyCommentField')
  replyCommentField: any;
  @Input() constant: any=null;
  @Input() id: any=null;
  list: any[] = new Array();
  documentType: any;
  documentId: any;
  documentTitle: any;
	documentCode: any;
  isShowSubmit: boolean = false;
  isReplyShowSubmit: boolean = false;
  comments: string = "";
  replyComments: string;
  isDisabled: boolean = false;
  isReplyDisabled: boolean = false;
  spinnerFlag: boolean = false;
  isReply: boolean = false;
  public subscription: any = [];
  currentUser: UserPrincipalDTO = new UserPrincipalDTO();
  pageNo: number = 0;
  isLastPage: boolean = false;
  isShowUsers: boolean = false;
  isReplyShowUsers: boolean = false;
  usersList: any[] = new Array();
  suggestions: any[] = [];
  suggestion: string;
  show: boolean;
  commentForm: FormControl = new FormControl();
  replyCommentsForm: FormControl = new FormControl();
  fieldHistory: any[] = [];
  replyFieldHistory: any[] = [];
  isViewAll:boolean=false;
  constructor(public helper: Helper, private service: DocumentForumService, public configService: ConfigService) { }

  ngOnInit() {
    this.isShowSubmit = false;
    this.isReplyShowSubmit = false;
    this.configService.loadCurrentUserDetails().subscribe(res => {
      this.currentUser = res;
      if ( null != this.constant){
        this.documentType = this.constant;
        this.documentId = 0
        this.loadUsers(this.currentUser.projectId, this.documentType);
        this.isCommentsForDocument();
      }
      if ( null != this.id) 
        this.documentId = this.id;
      else
        this.documentId = 0;
      
      this.subscription.push(this.helper.steppermodel.subscribe(data => {
        if (data !== 'no data') {
          this.documentType = (<any>data).constantName;
          this.documentId = (<any>data).documentIdentity;
          this.documentTitle = (<any>data).documentTitle;
          this.documentCode= (<any>data).code;
          this.list=new Array();
          this.loadUsers(this.currentUser.projectId, this.documentType);
          this.isCommentsForDocument();
        }
      }));
    });
  }
  isCommentsForDocument(){
    this.service.isCommentsForDocument(this.documentType, this.documentId).subscribe(res => {
      this.isViewAll = res;
    });
  }
  loadUsers(projectId: any, documentType: any) {
    this.configService.getAllUsersForProjectAndDocumentType(projectId, documentType).subscribe(res => {
      this.usersList = res;
    });
  }
  onClickViewAll(){
    this.loadAll();
  }
  loadAllForDocumentStatus(documentType){
    return new Promise<any>(resolve => {
      try {
        this.documentType = documentType;
        this.pageNo = 0;
        this.documentId = 0;
        this.list = new Array();
        this.loadUsers(this.currentUser.projectId, this.documentType);
        this.isCommentsForDocument();
      } catch (error) {
        resolve();
      }
      resolve()
    })
    
  }
  loadAll() {
    this.isViewAll=false;
    this.isLastPage = false;
    this.spinnerFlag = true;
    this.service.loadDocumentForum(this.documentType, this.documentId, this.pageNo).subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.list = this.list.concat(response.result);
        console.log(this.list);
        this.isLastPage = response.isLastPage;
      }
    }, error => { this.spinnerFlag = false });
  }
  onClickMore() {
    this.pageNo = this.pageNo + 1;
    this.loadAll()
  }
  focusInput() {
    this.isShowSubmit = true;
  }
  onTypeComments(event) {
    this.isShowUsers = false;
    this.isDisabled = false;
    if(event){
      this.comments = event;
      this.suggestions.forEach(data =>{
        let index = this.fieldHistory.findIndex(function (element) {
          return element === data;
        });
        if(this.comments.includes('@'+data.userName)){
          this.comments=this.comments.replace('@'+data.userName,'');
        }else{
          this.comments=this.comments.trim();
          if(this.comments.includes(("@"))){
            let split=this.comments.split("@");
            split.forEach(f =>{
              let d=f.trim();
              if(d.length>0){
                let names= d.split(" ");
                names.forEach(n =>{
                  let name=n.trim();
                  if(data.userName.includes(name)){
                    this.comments= this.comments.replace(name,'');
                  }
                });
              }
            });
          }
          if(index !=-1)
            this.fieldHistory.splice(index,1);
        }
      });
      if (this.comments) {
        this.isDisabled = true;
        this.isShowUsers = this.comments.includes('@');
        this.show= this.isShowUsers;
      }
    }else{
      this.fieldHistory=[];
    }
  }
  onTypeReplyComments(event) {
    this.isReplyShowUsers = false;
    this.isReplyDisabled = false;
    this.replyComments = event;
    if(event){
      this.suggestions.forEach(data =>{
        let index = this.replyFieldHistory.findIndex(function (element) {
          return element === data;
        });
        if(this.replyComments.includes('@'+data.userName)){
          this.replyComments=this.replyComments.replace('@'+data.userName,'');
        }else{
          this.replyComments=this.replyComments.trim();
          let split=this.replyComments.split("@");
          split.forEach(f =>{
            let d=f.trim();
            if(d.length>0){
              let names= d.split(" ");
              names.forEach(n =>{
                let name=n.trim();
                if(data.userName.includes(name)){
                  this.replyComments= this.replyComments.replace(name,'');
                }
              });
            }
          });
          if(index !=-1)
            this.replyFieldHistory.splice(index,1);
        }
      })
      if (this.replyComments) {
        this.isReplyDisabled = true;
        this.isReplyShowUsers = this.replyComments.includes('@');
        this.show= this.isReplyShowUsers;
      }
    }else{
      this.replyFieldHistory=[];
    }
  }
  onSubmit() {
    if (this.comments) {
      const data: DocumentForumDTO = new DocumentForumDTO();
      data.comments = this.comments;
      data.documentId = this.documentId;
      data.documentType = this.documentType;
      data.documentTitle = this.documentTitle;
      data.documentCode = this.documentCode;
      const users=this.fieldHistory.map(data => data.id);
      data.selectedUsersList=users;
      this.save(data);
    }
  }
  onReplySubmit(item: any) {
    if (this.replyComments) {
      const data: DocumentForumDTO = new DocumentForumDTO();
      if(item.editIndividualFlag){
        data.id=item.id;
        data.replyId=0;
      }else if(item.replyFlag){
        data.replyId = item.id;
        data.id=0;
      }
      data.comments = this.replyComments;
      data.documentId = this.documentId;
      data.documentType = this.documentType;
      data.documentTitle = this.documentTitle;
      data.documentCode = this.documentCode;
      const users=this.replyFieldHistory.map(data => data.id);
      data.selectedUsersList=users;
      this.save(data);
    }
  }
  save(data: any) {
    this.spinnerFlag = true;
    this.service.createDocumentForum(data).subscribe(jsonResp => {
      this.pageNo = 0;
      this.list = [];
      this.fieldHistory=[];
      this.replyFieldHistory=[];
      this.loadAll();
      this.comments = "";
      this.replyComments = "";
      this.commentForm.reset();
      this.replyCommentsForm.reset();
      this.isReplyShowSubmit = false;
      this.isShowSubmit = false;
      this.spinnerFlag = false;
    },
      err => {
        this.spinnerFlag = false
      }
    );
  }
  onClickLike(item: any) {
    item.userLikeFlag = !item.userLikeFlag;
    this.spinnerFlag = true;
    this.service.saveuserLikes(item).subscribe(jsonResp => {
      this.pageNo = 0;
      this.list = [];
      this.loadAll();
      this.spinnerFlag = false;
    },
      err => {
        this.spinnerFlag = false
      }
    );
  }
  onCLickReply(item: any) {
    this.isReplyShowSubmit = true;
    this.replyComments = "";
    this.list.map(data => {
      data.replyFlag = false;
      data.editIndividualFlag = false;
    });
    item.replyFlag = true;
  }
  onClickEdit(item: any) {
    this.isReplyDisabled = true;
    this.isReplyShowSubmit = true;
    this.replyComments = "";
    this.list.map(data => {
      data.replyFlag = false;
      data.editIndividualFlag = false;
    });
    item.editIndividualFlag = true;
      this.replyComments=" "+item.comments;
      if(item.selectedUsersList.length>0){
        this.isReplyShowUsers = true;
        item.selectedUsersList.forEach(element => {
          this.usersList.forEach(f =>{
            if(element === f.id)
             this.replySelectSuggestion(f);
          })
        });
      }else{
        this.replyCommentsForm.patchValue(item.comments);
      }
      
  }
  suggest() {
    this.suggestions = this.usersList;
    this.show = true;
  }

  replySelectSuggestion(s) {
    this.suggestion = "";
    var index = this.replyFieldHistory.findIndex(function (element) {
      return element === s;
    });
    if (index === -1) {
      this.replyFieldHistory.push(s);
    } else {
      var firstPart = this.replyFieldHistory.slice(0, index);
      var secondPart = this.replyFieldHistory.slice(++index);
      if(firstPart.length>0 && secondPart.length>0)
        this.replyFieldHistory = firstPart.concat(secondPart);
    }
    for (let i = 0; i < this.replyFieldHistory.length; i++)
      this.suggestion = this.suggestion + "  @" + this.replyFieldHistory[i].userName;
    
    this.replyComments=this.replyComments.trim();
    let split=this.replyComments.split("@");
    split.forEach(f =>{
      let d=f.trim();
      if(d.length>0){
        this.replyFieldHistory.forEach(element => {
         let names= d.split(" ");
         names.forEach(n =>{
           let name=n.trim();
          if(element.userName.includes(name)){
            this.replyComments= this.replyComments.replace(name,'');
          }
         });
        });
      }
    });
    this.replyComments= this.replyComments.replace('@','');
    this.replyCommentsForm.patchValue(this.suggestion+" "+this.replyComments);
    this.show = false;
    if(this.replyCommentField)
      this.replyCommentField.nativeElement.focus();
  }
  selectSuggestion(s) {
    this.suggestion = "";
     let index = this.fieldHistory.findIndex(function (element) {
        return element === s;
      });
    
    if (index === -1) {
      this.fieldHistory.push(s);
    } else {
      let firstPart = this.fieldHistory.slice(0, index);
      let secondPart = this.fieldHistory.slice(++index);
      if(firstPart.length>0 && secondPart.length>0)
        this.fieldHistory = firstPart.concat(secondPart);
    }
    for (let i = 0; i < this.fieldHistory.length; i++)
      this.suggestion = this.suggestion + "  @" + this.fieldHistory[i].userName;

    this.comments=this.comments.trim();
    let split=this.comments.split("@");
    split.forEach(f =>{
      let d=f.trim();
      if(d.length>0){
        this.fieldHistory.forEach(element => {
         let names= d.split(" ");
         names.forEach(n =>{
           let name=n.trim();
          if(element.userName.includes(name)){
            this.comments= this.comments.replace(name,'');
          }
         });
        });
      }
    });
    this.comments= this.comments.replace('@','');
    this.commentForm.patchValue(this.suggestion+" "+this.comments);
    this.show = false;
    this.commentField.nativeElement.focus();
  }
  onClickOut(){
    if(!this.commentForm.value)
      this.isShowSubmit=false;
  }
  onReplyClickOut(){
    if(!this.replyComments)
      this.isReplyShowSubmit=false;
    else
      this.isReplyShowSubmit=true;
  }
  onClickDelete(item){
    var obj = this;
      swal({title: 'Are you sure?', text: 'You wont be able to revert',type: 'warning',
      showCancelButton: true,confirmButtonColor: '#3085d6',cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',cancelButtonClass: 'btn btn-danger',allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      obj.service.deleteDocumentForum(item.id).subscribe(jsonResp => {
        obj.pageNo = 0;
        obj.list = [];
        obj.loadAll();
      });
    });
  }
}

