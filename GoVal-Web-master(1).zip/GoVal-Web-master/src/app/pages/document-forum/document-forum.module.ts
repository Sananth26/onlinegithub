import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {SharedModule} from '../../shared/shared.module';
import { Helper } from '../../shared/helper';
import { ConfigService } from '../../shared/config.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentForumComponent } from './document-forum.component';
import {DocumentForumService} from './document-forum.service';
import {FocusModule} from 'angular2-focus';
@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    FocusModule.forRoot()
  ],
  exports:[DocumentForumComponent],
  declarations: [DocumentForumComponent],
  providers : [DocumentForumService,Helper,ConfigService],
})
export class DocumentForumModule { }
