import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions,ResponseContentType } from '@angular/http';
import { Observable } from "rxjs/Observable";
import { Helper } from '../../shared/helper';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ConfigService } from '../../shared/config.service';
@Injectable()
export class DocumentForumService {
  constructor(private http: Http, public helper: Helper, public config: ConfigService) { }
  url_save: string = this.helper.common_URL + 'documentForum/saveDocumentForum';
  url_user_like: string = this.helper.common_URL + 'documentForum/saveUserLike';
  url_load: string = this.helper.common_URL + 'documentForum/loadAllDocumentForum';
  url_delete: string = this.helper.common_URL + 'documentForum/deleteDocumentForum';
  url_isCommentsForDocument: string = this.helper.common_URL + 'documentForum/isCommentsForDocument';

  createDocumentForum(data: any) {
    return this.http.post(this.url_save, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  deleteDocumentForum(data: any) {
    return this.http.post(this.url_delete, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  saveuserLikes(data: any) {
    return this.http.post(this.url_user_like, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  loadDocumentForum(documentType:any,documentId:any,pageNo:any) {
    const formdata: FormData = new FormData();
    formdata.append('documentType', documentType);
    formdata.append('documentId', documentId);
    formdata.append('pageNo', pageNo);
    return this.http.post(this.url_load,formdata, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  isCommentsForDocument(documentType:any,documentId:any) {
    const formdata: FormData = new FormData();
    formdata.append('documentType', documentType);
    formdata.append('documentId', documentId);
    return this.http.post(this.url_isCommentsForDocument,formdata, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
}