import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs/Observable';
import { Helper } from '../../shared/helper';
import { Department } from '../../models/model';
import { ConfigService } from '../../shared/config.service';
@Injectable()
// tslint:disable-next-line:class-name
export class DepartmentService {
  

  constructor(private http: Http, public helper: Helper, public config: ConfigService) { }
  url_save: string = this.helper.common_URL + 'department/save';
  url_load: string = this.helper.common_URL + 'department/load';
  url_delete: string = this.helper.common_URL + 'department/delete';
  url_edit: string = this.helper.common_URL + 'department/edit';
  getDefaultDepartmentDetailsURL: string = this.helper.common_URL + 'department/loadDefaultDepartmentDetails';
  url_departmentIsExist: string = this.helper.common_URL + 'department/isExists';
  url_isDepartmentUsed:string = this.helper.common_URL + 'department/isDepartmentUsed';

  createDepartment(data: Department) {
    return this.http.post(this.url_save, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  loadDepartment() {
    return this.http.post(this.url_load, "", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  deleteDepartment(data: any) {

    return this.http.post(this.url_delete, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  editDepartment(data: any) {

    return this.http.post(this.url_edit, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  loadDefaultDepartmentDetails() {
    return this.http.post(this.getDefaultDepartmentDetailsURL, "", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  departmentIsExist(departmentName) {
    return this.http.post(this.url_departmentIsExist, departmentName, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
departmentIsUsed(departmentId){
  return this.http.post(this.url_isDepartmentUsed, departmentId, this.config.getRequestOptionArgs())
    .map((resp) => resp.json())
    .catch(res => {
      return Observable.throw(res.json());
    });
}

}
