import { SharedModule } from '../../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { TagInputModule } from 'ngx-chips';
import { Helper } from '../../../shared/helper';
import { HttpModule } from '@angular/http';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { DepartmentService } from '../department.service';
import { ViewDepartmentComponent } from './view-department.component';


export const ViewDepartmentRoutes: Routes = [
    {
        path: ' ', 
        component: ViewDepartmentComponent
        
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( ViewDepartmentRoutes ),
        SharedModule,
        TagInputModule,
        HttpModule,
        NgxDatatableModule
    ],
    
    providers: [Helper, DepartmentService]
} )
export class ViewDepartmentModule { }
