import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { DepartmentService } from '../department.service';
import { Department } from '../../../models/model';
import swal from 'sweetalert2';
import { Helper } from '../../../shared/helper';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { Permissions } from '../../../shared/config';
import { ConfigService } from '../../../shared/config.service';
@Component({
  selector: 'app-view-department',
  templateUrl: './view-department.component.html',
  styleUrls: ['./view-department.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class ViewDepartmentComponent implements OnInit {
  @ViewChild('myTable') table: any;
  data: any;
  modal: Department = new Department();

  permisionModal:Permissions=new Permissions('103',false);
  updateFlag: boolean = false;
  public rowsOnPage = 10;
  public filterQuery = '';
  public sortBy = '';
  public sortOrder = 'desc';
  spinnerFlag = false;
  permissionData:any;
  constructor(private comp: AdminComponent, public service: DepartmentService, public helper: Helper,public permissionService:ConfigService) { }

  ngOnInit() {
    this.loadAll();
    this.comp.setUpModuleForHelpContent("103");
    this.permissionService.loadPermissionsBasedOnModule("103").subscribe(resp=>{
      this.permisionModal=resp
    });
  }

  toggleExpandRow(row) {
    this.table.rowDetail.toggleExpandRow(row);
  }


  loadAll() {
    this.spinnerFlag = true;
    this.service.loadDepartment().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.data = response.result
      }
    }, error => { this.spinnerFlag = false });
  }

  editDepartment(id: any) {
    this.updateFlag = true;
    this.service.editDepartment(id).subscribe(response => {
      if (response.result != null) {
        this.modal = response.result;
      }
    });
  }

  // deleteDepatment(id:any){
  //
  //   this.service.deleteDepartment(dept).subscribe(response=>{
  //     if(response.result==true){
  //     this.loadAll();
  //     }
  //    })
  // }

  openSuccessCancelSwal(dataObj, id) {
    this.service.departmentIsUsed(dataObj.id).subscribe(
      jsonResp => {
          let responseMsg: boolean = jsonResp;
          if (responseMsg == true) {
            swal({
              title: 'Info',
              text: 'Cannot be deleted as this department is mapped to a project!!',
               type: 'warning',
               showConfirmButton:false,
                timer: 3000,allowOutsideClick: false });
          } else {
            var classObject = this;
            swal({
              title: 'Are you sure?',
              text: 'You wont be able to revert',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes, delete it!',
              cancelButtonText: 'No, cancel!',
              confirmButtonClass: 'btn btn-success m-r-10',
              cancelButtonClass: 'btn btn-danger',
              allowOutsideClick: false,
              buttonsStyling: false,
            }).then(function () {
              classObject.deleteCategory(dataObj);
            });
          }
      }
  );
  }

 

  deleteCategory(dataObj): string {
    let status = '';
    let dept = new Department();
    dept.id = dataObj.id;
    this.service.deleteDepartment(dept)
      .subscribe((response) => {
        let timerInterval;
        if (response.result == true) {
          status = "success";
          swal({
            title: 'Deleted!',
            text: 'Department ' + dataObj.departmentName + '  has been deleted.',
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              this.loadAll();
              clearInterval(timerInterval)
            }
          });

        } else {
          status = "failure";
          swal({
            title: 'Not Deleted!',
            text: 'Department ' + dataObj.departmentName + '  has not been deleted.',
            type: 'error',
            timer: this.helper.swalTimer,
            showConfirmButton:false,
          }
          );
        }
      }, (err) => {
        status = "failure";

        swal({
          title: 'Not Deleted!',
          text: dataObj.departmentName + 'is not deleted...Something went wrong',
          type: 'error',
          timer: this.helper.swalTimer,
          showConfirmButton:false,
        }

        );
      });
    return status;
  }
}
