import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ViewDepartmentComponent } from './view-department/view-department.component';
import { Helper } from '../../shared/helper';
import { DepartmentService } from './department.service';
import { NgxDatatableModule } from '../../../../node_modules/@swimlane/ngx-datatable';
import {AuthGuardService} from '../../layout/auth/AuthGuardService';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import {DepartmentComponent} from './department.component';
export const DepartmentRoutes: Routes = [
    {
        path: '',
        component:ViewDepartmentComponent,
        canActivate: [ AuthGuardService ],
        data: {
            
            status: false
        },
        
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( DepartmentRoutes ),
        SharedModule,
        NgxDatatableModule,
        FormsModule,
        ReactiveFormsModule,
    ],
    declarations: [DepartmentComponent,ViewDepartmentComponent],
    providers: [Helper, DepartmentService ]
} )
export class DepartmentModule { }
