import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Department, UserPrincipalDTO } from '../../../models/model';
import { DepartmentService } from '../department.service';
import { Helper } from '../../../shared/helper';
import swal from 'sweetalert2';
import { ActivatedRoute, Router } from '../../../../../node_modules/@angular/router';
import { OraganizationService } from '../../organization/organization.service';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { ConfigService } from '../../../shared/config.service';
import { departmentErrorTypes } from '../../../shared/constants';
import { Permissions } from '../../../shared/config';

@Component({
  selector: 'app-add-department',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddDepartmentComponent implements OnInit {
  spinnerFlag = false;
  modal: Department = new Department();
  loading: boolean = false;
  toggleEditoractualresult = false;
  submitted: boolean = false;
  validationMessage: string;
  updateFlag: boolean = false;
  errorMessage: string;
  receivedId: string;
  isUpdate: boolean = false;
  isSave: boolean = false;
  isLoading: boolean = false;
  organizationName: string;
  isDefault: boolean = false;
  showButtonFlag: boolean = false;
  currentUser: UserPrincipalDTO = new UserPrincipalDTO();
  permissionModal=new Permissions('103',false);
  disableButtonFlag=false;
  departmentActualName="";
  constructor(public configService: ConfigService, private comp: AdminComponent, public service: DepartmentService, public helper: Helper, private route: ActivatedRoute, private routers: Router,
     public Service: DepartmentService, public organizationService: OraganizationService,public departmentErrorTypes: departmentErrorTypes) { }

  ngOnInit() {
    this.configService.loadPermissionsBasedOnModule("103").subscribe(resp => {
      this.permissionModal = resp;
    });
    this.validationMessage='';
    this.configService.loadCurrentUserDetails().subscribe(jsonResp => {
      this.currentUser = jsonResp;
      this.showButtonFlag = true;
      this.organizationService.getDataForEdit(this.currentUser.orgId).subscribe(jsonResp => {
        this.modal.organizationName = jsonResp.organizationName;
      },err => {
        }
      );
      this.receivedId = this.route.snapshot.params["id"];
      if (this.receivedId !== undefined) {
        this.updateFlag = true;
        this.isUpdate = true;
        this.Service.editDepartment(this.receivedId).subscribe(jsonResp => {
          this.modal = jsonResp.result;
         this.departmentActualName= this.modal.departmentName.trim();
        },
          err => {
          }
        );
      } else {
        this.service.loadDefaultDepartmentDetails().subscribe(jsonResp => {
          this.modal.departmentName = jsonResp.departmentName;
        });
        this.organizationService.getDataForEdit(this.currentUser.orgId).subscribe(jsonResp => {
          this.modal.organizationName = jsonResp.organizationName;
        }
        );
        this.isSave = true;
      }
      this.comp.setUpModuleForHelpContent("103");
    });
  }

  onsubmit(formIsValid) {
    if (formIsValid && this.validationMessage =='') {
      this.spinnerFlag = true;
      this.modal.loginUserId = this.currentUser.id;
      this.modal.organizationOfLoginUser = this.currentUser.orgId;
      if (this.routers.url.search("masterControl") != -1) {
        this.modal.isDefault = "true";
      }
      else {
        this.modal.isDefault = "false";
        if (this.receivedId !== undefined) {
          this.modal.id = + this.receivedId;
        } else { this.modal.id = 0; }

      }
      this.service.createDepartment(this.modal).subscribe(jsonResp => {
        this.spinnerFlag = false
        let responseMsg: string = jsonResp.result;
        if (responseMsg === "success") {
          this.loading = false;
          // let mes = 'New Department ' + this.modal.departmentName + ' is created';
          let mes = 'New Department is created';
          if (this.updateFlag) {
            // mes = this.modal.departmentName + "Department is updated"
            mes = 'Department is updated';
          }
          swal({
            title: '',
            text: mes,
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              if (this.routers.url.search("masterControl") != -1) {
                this.routers.navigate(["/masterControl"]);
                this.showButtonFlag = false;
              } else {
                this.routers.navigate(["/department"]);
              }
            }
          });
        } else {
          this.loading = false;
          this.submitted = false;
          swal({
            title: '',
            text: 'Something went Wrong ...Try Again',
            type: 'error',
            timer: this.helper.swalTimer,
            showConfirmButton:false,
          }

          )
        }
      },
        err => {
          this.spinnerFlag = false
          this.loading = false;
        }
      );
    }
    else {
      this.spinnerFlag = false;
      this.loading = false;
      this.submitted = true;
      return;
    }
  }



showNext = (() => {
  return () => {
   setTimeout(() => {
     let dept= this.modal.departmentName.trim();
      if(!this.helper.isEmpty(this.modal.departmentName)){
        if(this.departmentActualName!=dept){
        this.disableButtonFlag=true;
        this.service.departmentIsExist(this.modal.departmentName).subscribe(
          jsonResp => {
            this.disableButtonFlag=false;
              let responseMsg: boolean = jsonResp;
              if (responseMsg == true) {
                  this.validationMessage =this.departmentErrorTypes.validationMessage;
              } else {
                  this.validationMessage = "";
              }
          },err=> {this.disableButtonFlag=false}
      );
      }else{
        this.validationMessage = "";  
      }
      }else{
        this.validationMessage = "";
      }
    }, 600);
  }
})();
}
