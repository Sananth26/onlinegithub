import { SharedModule } from '../../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UiSwitchModule } from 'ng2-ui-switch/dist';
import { TagInputModule } from 'ngx-chips';
import { Helper } from '../../../shared/helper';
import { HttpModule } from '@angular/http';
import { AddDepartmentComponent } from './add-department.component';
import { DepartmentService } from '../department.service';
import { SelectModule } from 'ng-select';
import { OraganizationService } from '../../organization/organization.service';
import { SharedCommonModule } from '../../../shared/SharedCommonModule';
import { departmentErrorTypes } from '../../../shared/constants';

export const addDepartmentRoutes: Routes = [
    {
        path: '',
        component: AddDepartmentComponent
        
    }
];

@NgModule( {
    imports: [
        CommonModule,
        RouterModule.forChild( addDepartmentRoutes ),
        SharedModule,
        FormsModule,
        ReactiveFormsModule,
        UiSwitchModule,
        TagInputModule,
        HttpModule,
        SelectModule,
        SharedCommonModule
    ],
    declarations: [],
   providers: [Helper, DepartmentService,OraganizationService,departmentErrorTypes]
} )
export class AddDepartmentModule { }
