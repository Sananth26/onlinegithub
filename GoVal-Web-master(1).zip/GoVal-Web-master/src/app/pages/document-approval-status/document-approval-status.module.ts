import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DataTableModule } from 'angular2-datatable';
import { FormsModule } from '../../../../node_modules/@angular/forms';
import { AuthGuardService } from '../../layout/auth/AuthGuardService';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from '../../shared/SharedCommonModule';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { AuditTrailService } from '../audit-trail/audit-trail.service';
import { DocumentApprovalStatusComponent } from './document-approval-status.component';
import { DashBoardService } from '../dashboard/dashboard.service';
import { AdminComponent } from '../../layout/admin/admin.component';
import { DocumentsignComponentModule } from '../documentsign/documentsign.module';
import {DocumentStatusCommentLog} from '../document-status-comment-log/document-status-comment-log.module'
import { AuditTrailViewModule } from '../audit-trail-view/audit-trail-view.module';
import { DocumentForumModule } from '../document-forum/document-forum.module';

export const DocumentapprovalstatusRoutes: Routes = [
  {
      path: '',
      component: DocumentApprovalStatusComponent,
      canActivate: [ AuthGuardService ],
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild( DocumentapprovalstatusRoutes ),
    SharedModule,
    DataTableModule,
    FormsModule,
    NgxDatatableModule,
    HttpModule,
    SharedCommonModule,
    DocumentsignComponentModule,
    DocumentStatusCommentLog,AuditTrailViewModule,DocumentForumModule
],
declarations: [DocumentApprovalStatusComponent],
providers: [Helper, ConfigService, AuditTrailService,DashBoardService,AdminComponent]

})
export class DocumentApprovalStatusModule { }
