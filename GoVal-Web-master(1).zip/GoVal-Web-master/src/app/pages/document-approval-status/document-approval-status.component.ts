import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core'
import { Http } from '@angular/http'
import { Router, ActivatedRoute } from '@angular/router'
// tslint:disable-next-line: import-blacklist
import { Observable } from 'rxjs'
import swal from 'sweetalert2'
import { AdminComponent } from '../../layout/admin/admin.component'
import { CommonModel, UserPrincipalDTO, WorkflowDocumentStatusDTO } from '../../models/model'
import { ConfigService } from '../../shared/config.service'
import { Helper } from '../../shared/helper'
import { AuditTrailViewComponent } from '../audit-trail-view/audit-trail-view.component'
import { DashBoardService } from '../dashboard/dashboard.service'
import { DocumentForumComponent } from '../document-forum/document-forum.component'
import { StepperClass } from './../../models/model'
import { CommonFileFTPService } from './../common-file-ftp.service'

@Component({
  selector: 'app-document-approval-status',
  templateUrl: './document-approval-status.component.html',
  styleUrls: ['./document-approval-status.component.css', '../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None,
})
export class DocumentApprovalStatusComponent implements OnInit {
  dataFilter='';
  validationMessage='';
  public isSelectedPublishData: Boolean = false
  public isSelectedEsignPublishData: Boolean = false
  constructor(public admin: AdminComponent,
  public dashboardService: DashBoardService,
  public router: Router, public config: ConfigService,
  private commonService:CommonFileFTPService,
  private http: Http, public helper: Helper,private route: ActivatedRoute) { }
  public commonModel: CommonModel = new CommonModel()
  public filteredPendingDocList: any[] = new Array()
  public selectAllFlag: Boolean = true
  public comments: any = null
  public docinfo: any
  public getStatus:any=[]
  public previewdoc:any=[]
  private fileViewTitle='Uploaded File'
  public row: any
public viewpdf:boolean =true;
public currenttab=null;

  public esignActionData: WorkflowDocumentStatusDTO[] = new Array<WorkflowDocumentStatusDTO>()
  public Title:any = ''
  public tabchangeId: Number = 0
  public spinnerFlag: Boolean = true
  public show: Boolean = false
  @ViewChild('auditView') auditView: AuditTrailViewComponent;
  @ViewChild('forumView') forumView: DocumentForumComponent;
  @ViewChild('documentApprvalStatusTab') tab: any
  @ViewChild('documentSign') documentChildComponent
  @ViewChild('esignmodal') closeEsignModal: any
  @ViewChild('documentcomments') documentcomments: any;
  @ViewChild('modalLarge') approvalModal: any;
  public currentDocType: any
  public currentModifiedDate: any
  public currentDocStatus: any
  public currentCreatedBy: any
  public filteredData: any
  public filteredApprovalData: any
  public docItemList: any
  public filteredpending: any[] = new Array()
  public searchData: any
  public filteredcompleted: any[] = new Array()
  public esignHistoryList: any[] = new Array()
  public filteredCompletedDocList: any[] = new Array()
  currentUser: UserPrincipalDTO = new UserPrincipalDTO()
  private subscription: any
  public approvalValue: any
  public esignValue: any
  ngOnInit() {
    this.admin.setUpModuleForHelpContent('181');
    this.admin.taskDocType = "181";
    this.admin.taskDocTypeUniqueId = "";
    this.admin.taskEquipmentId = 0;
    this.config.loadCurrentUserDetails().subscribe(response => {
      this.currentUser = response
    });
    this.route.queryParams.subscribe(rep => {
      if (rep.documentId !== undefined) {
        localStorage.removeItem('documentApprovalStatus');
        this.Title =  { key: rep.documentId, value: rep.documentName };
        localStorage.setItem('documentApprovalStatus', this.helper.encode(rep.documentId))
        this.loaddata()
        localStorage.setItem('documentApprvalStatusTab', this.helper.encode("2"));
        this.tab.activeId ="2";
        this.commonModel.categoryName = this.tab.activeId == "1" ? 'completed' : 'pending'
        this.commonModel.dataType = 'opt1';
        this.onTabChange(2);
      
      }else{
        if (localStorage.getItem('documentApprvalStatusTab'))
      this.tab.activeId = this.helper.decode(localStorage.getItem('documentApprvalStatusTab'))
      this.commonModel.categoryName = this.tab.activeId == "1" ? 'completed' : 'pending'
      this.commonModel.dataType = 'opt1';
      localStorage.removeItem('documentApprovalStatus');
      this.subscription = this.helper.currentId.subscribe(
        data => {
          if (data !== 'no data') {
            this.isSelectedEsignPublishData = false
            this.closeEsignModal.hide()
            this.loadParentData()
          } else {
            this.loadParentData()
          }
        })
      }
    });
 
  }

  loadParentData() {
      this.spinnerFlag = true
      this.loadproj()
      this.loaddata()
  }

  changedatafilter() {
    this.spinnerFlag = true
    this.loadproj()
  }
  loadproj(id?:any): any {
    this.commonModel.type = 'workflowapprovalStatus'
    this.Api(this.commonModel, 'workFlow/loadDocumentsForUser').subscribe(response => {
      this.filteredpending = response.pendingList
      this.filteredcompleted = response.completedList
      let data = ""
      if (localStorage.getItem('documentApprovalStatus') != "undefined" && localStorage.getItem('documentApprovalStatus'))
        data = this.helper.decode(localStorage.getItem('documentApprovalStatus'))
      this.filteredPendingDocList = new Array()
      this.filteredCompletedDocList = new Array()
      if (data === "") {
        this.filteredPendingDocList = this.filteredpending
        this.filteredCompletedDocList = this.filteredcompleted
      } else {
        this.helper.setworkflowdropdownValues(data)
       const docList= this.docItemList.filter(d=>d.key==data);
       let doc={key:'',value:''};
       if(docList.length>0){
        doc=docList[0];
       }
        this.filteredpending.forEach(element => {
          if (element.documentType === doc.key || element.documentTitle === doc.value) {
            this.filteredPendingDocList.push(element)
          }
        })
        this.filteredcompleted.forEach(element => {
          if (element.documentType === doc.key || element.documentTitle === doc.value) {
            this.filteredCompletedDocList.push(element)
          }
        })
      }
        if(this.tab.activeId==2){
          this.viewpdf=true;
          this.bulkApprovalTimeLine()
        }



      this.spinnerFlag = false
    },
      err => {
        this.spinnerFlag = false
        console.log('error occured in getting the categories')
      })
  }
  Api(data, url) {
    return this.http.post(this.helper.common_URL + url, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json())
      })
  }
  loadesignDocs(row) {
    this.esignHistoryList = new Array()
    if (null != row) {
      this.esignHistoryList = row
    }
  }

  onTabChange(id: any) {
    this.spinnerFlag = true
    this.tabchangeId = id
    this.isSelectedEsignPublishData = false
    this.isSelectedPublishData = false
    if (id === '0' || id === '2') {
      this.commonModel.categoryName = 'pending'
    } else if (id === '1') {
      this.commonModel.categoryName = 'completed'

    }
    if(id=='audit'){
      if(this.auditView)
      this.auditView.loadData(this.Title.key).then(()=>{
        this.spinnerFlag = false;
      })
    }else if(id=='documentForum'){
      if(this.forumView)
      this.forumView.loadAllForDocumentStatus(this.Title.key).then(()=>{
        this.spinnerFlag = false;
      })
    }else if(id=='0'||id=='1'||id=='2'){
      this.loadproj(id)
    }
    
    


  }


  routeToComponent(row) {
    if (row.url.indexOf('dynamicForm') >= 0) {
      this.admin.redirect(row.url, '/documentapprovalstatus')
      if (row.selectedDocuments.length > 0) {
        this.helper.changeMessage({ "session": row.session, "documentList": row.selectedDocuments, "completionFlag": row.esignCompletionFlag, "permission": row.permissionFlag })
      }
    }
    if (row.selectedDocuments.length > 0 && row.url.indexOf('dynamicForm') < 0) {
      let id = row.selectedDocuments[0].documentId
      this.helper.changeMessage({ "session": row.session, "documentList": row.selectedDocuments, "completionFlag": row.esignCompletionFlag, "permission": row.permissionFlag })
      this.router.navigate([row.url], { queryParams: { id: id, status: '/documentapprovalstatus', list: row.selectedDocuments } })
    }
    if (row.selectedDocuments.length == 0 && row.url.indexOf('dynamicForm') < 0) {
      this.router.navigate([row.url], { queryParams: { id: row.documentId, status: '/documentapprovalstatus', exists: true, list: row.selectedDocuments } })
    }
  }

  routeView(row) {
    if (row.url.toLowerCase().indexOf('ynamic') >= 0) {
      this.admin.redirect(row.url, '/documentapprovalstatus')
    }
    if (row.url.toLowerCase().indexOf('ynamic') < 0) {
      this.router.navigate([row.url], { queryParams: { id: row.documentId, status: '/documentapprovalstatus', exists: true, list: row.selectedDocuments } })
    }
  }

  getdata(data?: any,permission?:any) {
    this.esignActionData  = new Array<WorkflowDocumentStatusDTO>()
    this.comments = null;
    if(data && data.length>0 && null != data){
      let currentdata=data[0];
        data.forEach(element => {
          this.filteredPendingDocList.forEach(s => {
            if (s.documentId == element.documentId)
              s.approvedFlag = true
          })
        })
      this.filteredData = this.filteredPendingDocList.filter(
        data => (data.currentLevel=== currentdata.currentLevel) && (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Approval" || data.actionType === 1))
      this.filteredApprovalData = this.filteredPendingDocList.filter(
        data => (data.currentLevel=== currentdata.currentLevel) && (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Esign" || data.actionType === 2))
  
      if (undefined != this.documentChildComponent) {
        this.documentChildComponent.loadDocumentList(this.filteredApprovalData)
        this.documentChildComponent.closeMyModal('effect-12')
        this.bulkApprovalTimeLine()
      }
      if (this.filteredApprovalData.length > 0) {
        this.filteredApprovalData.forEach(element => {
          element.approvedFlag = true
          if (element.groupedItems.length > 0) {
            element.groupedItems.push(element.groupedItems)
          }
          this.esignActionData.push(element)
        })
      }
      if(permission){
        if( this.filteredData.length >0)
          this.approvalModal.show();
        if( this.filteredApprovalData.length >0)
          this.closeEsignModal.show();
      }
    }else{
      permission=true;
      if (null != data) {
        data.forEach(element => {
          this.filteredPendingDocList.forEach(s => {
            if (s.documentId == element.documentId)
              s.approvedFlag = true
          })
        })
      }
      this.filteredData = this.filteredPendingDocList.filter(
        data => (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Approval" || data.actionType === 1))
      this.filteredApprovalData = this.filteredPendingDocList.filter(
        data => (data.approvedFlag === true || data.rejectedFlag === true) && (data.actionTypeName === "Esign" || data.actionType === 2))
  
      if (undefined != this.documentChildComponent) {
        this.documentChildComponent.loadDocumentList(this.filteredApprovalData)
        this.documentChildComponent.closeMyModal('effect-12')
        this.bulkApprovalTimeLine()
      }
      if (this.filteredApprovalData.length > 0) {
        this.filteredApprovalData.forEach(element => {
          element.approvedFlag = true
          if (element.groupedItems.length > 0) {
            element.groupedItems.push(element.groupedItems)
          }
          this.esignActionData.push(element)
        })
      }
      if(permission){
        if( this.filteredData.length >0)
          this.approvalModal.show();
        if( this.filteredApprovalData.length >0)
          this.closeEsignModal.show();
      }
    }
  }

  loadDocumentCommentLog(row, current: boolean,status?) {
    row.displayUpdatedTime = row.lastModifiedTime
    row.constantName = row.documentType
    row.id = row.documentId
    if (status != undefined)
      row.status = status
    else
      row.status = row.levelName
    this.documentcomments.loadDocumentCommentLog(row)

  }
  onChange(data: any) {
    this.searchData = "";
    this.selectAllDocument(false);
    localStorage.removeItem('documentApprovalStatus');
    this.filteredPendingDocList = new Array();
    this.filteredCompletedDocList = new Array();
    if (data === "") {
      this.filteredPendingDocList = this.filteredpending
      this.filteredCompletedDocList = this.filteredcompleted
    } else {
      localStorage.setItem('documentApprovalStatus', this.helper.encode(data.key))
      this.helper.setworkflowdropdownValues(data)
      this.filteredpending.forEach(element => {
        if (element.documentType === data.key || element.documentTitle === data.value) {
          this.filteredPendingDocList.push(element)
        }
      })
      this.filteredcompleted.forEach(element => {
        if (element.documentType === data.key || element.documentTitle === data.value) {
          this.filteredCompletedDocList.push(element)
        }
      })
    }
    if (this.tab.activeId !='0'&&this.tab.activeId!='1')//for pending and compelete not need to load 
      this.onTabChange(this.tab.activeId) // for rest we need to load  like pdf,audit,forum
  }
  loaddata() {
    this.docItemList = new Array<any>()
    
    this.config.getDocumentsOfProjectForUserForApproval().subscribe(resp => {
      this.docItemList = resp;
      
      if (localStorage.getItem('documentApprovalStatus') != "undefined" && localStorage.getItem('documentApprovalStatus'))
        this.docItemList.forEach(element => {
          if (element.key == this.helper.decode(localStorage.getItem('documentApprovalStatus')))
            this.Title = element
        })

    },
      err => {
        this.spinnerFlag = false
        console.log("error occured in getting the categories")
      })
  }


  selectAll() {
    this.selectAllFlag = !this.selectAllFlag
    this.filteredpending.filter(row => row.session == null && row.permission).forEach(d => {
      d.approvedFlag = !d.approvedFlag
    })
    this.onChangePublishData()
  }

  selectAllData() {
    this.selectAllFlag = !this.selectAllFlag
    this.filteredpending.filter(row => row.permission==this.Title ).forEach(d => {
      d.approvedFlag = !d.approvedFlag
    })

  }

  EsignData() {
    this.filteredApprovalData.forEach(element => {
      element.approvedFlag = true
      element.rejectedFlag = false
      element.globalProjectId = this.currentUser.projectId
      element.comments = this.comments
      element.currentUser = this.currentUser.id
    })
  }

  approve() {
    this.isSelectedPublishData = false
    this.filteredData.forEach(element => {
      element.approvedFlag = true
      element.rejectedFlag = false
      element.globalProjectId = this.currentUser.projectId
      element.comments = this.comments
      element.currentUser = this.currentUser.id
    })

    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, Approve All!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then((data) => {
      this.ApproveOrReject()
      this.isSelectedPublishData = false
      this.isSelectedEsignPublishData = false
    })
  }



  reject() {
    this.isSelectedPublishData = false
    this.filteredData.forEach(element => {
      element.approvedFlag = false
      element.rejectedFlag = true
      element.globalProjectId = this.currentUser.projectId
      element.comments = this.comments
      element.currentUser = this.currentUser.id
    })
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, reject All!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then((data) => {
      this.ApproveOrReject()
      this.isSelectedPublishData = false
      this.isSelectedEsignPublishData = false
    })
  }
  ApproveOrReject() {
    this.spinnerFlag=true
    this.Api(this.filteredData, 'workFlow/approveOrReject').subscribe(response => {

this.spinnerFlag=false
      if (response.dataType  === 'Multiple access for same Data') {
  swal({
    title: '',
    text: 'Multiple access for same Data',
    type: 'warning',
    timer: this.helper.swalTimer,
    showConfirmButton: false
  })
  this.loadParentData()
  this.onChange(this.Title)
} else {


      swal({
        title: '',
        text: 'Success',
        type: 'success',
        timer: this.helper.swalTimer,
        showConfirmButton: false
      })
}
      setTimeout(() => { this.loadproj(); this.bulkApprovalTimeLine(); }, 1000)
    })
  }

  onChangePublishData() {
    let esignName = ''
    let approvalName = ''
    this.esignValue = ''
    this.approvalValue = ''
    for (let data of this.filteredPendingDocList) {
      if (data.approvedFlag && data.actionType === 1) {
        this.isSelectedPublishData = true
        approvalName = data.actionTypeName
        break
      } else {
        this.isSelectedPublishData = false
      }
    }
    for (let data of this.filteredPendingDocList) {
      if (data.approvedFlag && data.actionType === 2) {
        this.isSelectedEsignPublishData = true
        esignName = data.actionTypeName
        break
      } else {
        this.isSelectedEsignPublishData = false
      }
    }
    let approvalCount = this.filteredPendingDocList.filter(result => result.actionType === 1 && result.approvedFlag == true).length
    let esignCount = this.filteredPendingDocList.filter(result => result.actionType === 2 && result.approvedFlag == true).length
    if (esignCount > 0)
      this.esignValue = esignName + ":" + esignCount + " Selected"
    if (approvalCount > 0)
      this.approvalValue = approvalName + ":" + approvalCount + " Selected"
  }

  selectAllDocument(checked: any) {
    let esignName = ''
    let approvalName = ''
    this.esignValue =''
    this.approvalValue =''
    if (checked) {
      this.filteredPendingDocList.forEach(element => {
        if (element.actionType === 1 && this.isSelectedPublishData) {
          element.approvedFlag = true
          approvalName = element.actionTypeName
        }
        if (element.actionType === 2 && this.isSelectedEsignPublishData) {
          element.approvedFlag = true
          esignName = element.actionTypeName
        }
      })
    } else {
      this.filteredPendingDocList.forEach(element => {
        if (element.actionType === 1 && this.isSelectedPublishData) {
          element.approvedFlag = false
        }
        if (element.actionType === 2 && this.isSelectedEsignPublishData) {
          element.approvedFlag = false
        }
      })
      this.isSelectedEsignPublishData = false
      this.isSelectedPublishData = false
    }
    let approvalCount = this.filteredPendingDocList.filter(result => result.actionType === 1 && result.approvedFlag == true).length
    let esignCount = this.filteredPendingDocList.filter(result => result.actionType === 2 && result.approvedFlag == true).length

    if (esignCount > 0)
    this.esignValue = esignName + ":" + esignCount + " Selected"
  if (approvalCount > 0)
    this.approvalValue = approvalName + ":" + approvalCount + " Selected"
  }


  bulkApprovalTimeLine() {
    if(''+this.tabchangeId =='2'){
    this.viewpdf = false;
    this.previewdoc=null;
    this.fileViewTitle=(<any>this.Title).value
    const stepperModule: StepperClass = new StepperClass()
    stepperModule.constantName = (<any>this.Title).key
    this.Api(stepperModule, 'workFlow/bulkDocumentApproveTimeLine').subscribe(response => {
      this.getStatus = response.timeLine;
      this.getStatus.forEach(element => {
        element.errorList = this.filteredPendingDocList.filter(e=>e.currentLevel===element.levelId)
        if(this.filteredPendingDocList.length>0 && null==this.previewdoc && null!=element.errorList && element.errorList.length>0){
          this.previewdoc=element.errorList;
          this.pdfpreview(this.previewdoc)
          element.thisIsCurrent=true;
        }
      })
    })
  }
  }

  clearall() {
    this.filteredPendingDocList.forEach(element => {
      element.approvedFlag = false;
    });
  }

pdfpreview(data,individual?:any) {
  this.spinnerFlag=true;
  const ids: any[] = new Array();
  data.forEach(ee => {
      ids.push(ee.documentId);
    });
  const stepperModule: StepperClass = new StepperClass();
    stepperModule.constantName = (null!=(<any>this.Title).key)?(<any>this.Title).key:data[0].docName;
    stepperModule.documentIds = ids;
  this.Api(stepperModule, 'workFlow/pdfPreviewfortimeline').subscribe(response => {
    this.viewpdf = true;
    if ((<any>this.Title).key != '128')
      var responseBolb: any[] = this.b64toBlob(response.pdf)
    const blob: Blob = new Blob(responseBolb, { type: "application/pdf" });
    setTimeout(() => { this.createIFrame(URL.createObjectURL(blob)) }, 10);
  })

}

  private createIFrame(blob_url: string) {
    var iframe;
    var elementExists = document.getElementById('iframeView');
    if (!elementExists)
      iframe = document.createElement('iframe');
    else
      iframe = elementExists;
    iframe.setAttribute('id', 'iframeView')
    iframe.setAttribute("height", window.innerHeight);
    iframe.setAttribute("width", "100%");
    iframe.src = blob_url + '#view=FitH';
    const find = document.querySelector('#fileUploadIdBulkApproval');
    find.setAttribute('class', 'well well-lg row');
    find.appendChild(iframe);
    this.spinnerFlag = false;
  }

private b64toBlob(b64Data) {
  var sliceSize = sliceSize || 512;
  var byteCharacters = atob(b64Data);
  var byteArrays = [];
  for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    var slice = byteCharacters.slice(offset, offset + sliceSize);
    var byteNumbers = new Array(slice.length);
    for (var i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    var byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
  return byteArrays;
}




}
