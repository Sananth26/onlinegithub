import { Component, OnInit, Input } from '@angular/core';
import { GobalTraceabilitymatrixService } from './gobal-traceability-matrix.service';

@Component({
  selector: 'app-gobal-traceability-matrix',
  templateUrl: './gobal-traceability-matrix.component.html',
  styleUrls: ['./gobal-traceability-matrix.component.css']
})
export class GobalTraceabilityMatrixComponent implements OnInit {
  spinnerFlag: boolean = false;
  public traceabilityData:any[]= new Array();
  @Input() public testCaseId:string;
  constructor(private gobaltraceservice:GobalTraceabilitymatrixService) { }

  ngOnInit(){
    this.spinnerFlag = true;
    this.gobaltraceservice.getTraceDetailData(this.testCaseId).subscribe(resp =>{
      this.spinnerFlag = false;
      this.traceabilityData = resp;
      console.log(this.traceabilityData);
   },(err)=>{
      this.spinnerFlag = false;
   });
 }

}
