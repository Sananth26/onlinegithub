import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import swal from 'sweetalert2';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { Permissions } from '../../../shared/config';
import { ConfigService } from '../../../shared/config.service';
import { Helper } from '../../../shared/helper';
import { CommonFileFTPService } from '../../common-file-ftp.service';
import { FileUploadForDocComponent } from '../../file-upload-for-doc/file-upload-for-doc.component';
import { ImageviewComponent } from '../../imageview/imageview.component';
import { IQTCService } from '../../iqtc/iqtc.service';
import { VideoViewerComponent } from '../../video-viewer/video-viewer.component';
import { ViewTestcaseFileListComponent } from '../../view-testcase-file-list/view-testcase-file-list.component';
import { DiscrepancyFormRoutesService } from '../discrepancy-form.service';
import { StepperClass, WorkflowDocumentStatusDTO } from './../../../models/model';
@Component({
  selector: 'app-view-discrepancy-form',
  templateUrl: './view-discrepancy-form.component.html',
  styleUrls: ['./view-discrepancy-form.component.css','../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class ViewDiscrepancyFormComponent implements OnInit ,AfterViewInit {
  @ViewChild('discrepancyTab') tab:any;
  @ViewChild('viewImageComponent') viewImageComponent:ImageviewComponent;
  @ViewChild('viewVideoComponent') viewVideoComponent:VideoViewerComponent;
  @ViewChild('modalFileViewer') preViewModal: any;
  @ViewChild('fileupload') private file: FileUploadForDocComponent;
  @ViewChild('viewFileOfTestCase')private viewFile : ViewTestcaseFileListComponent;
  data: any=[];
  completedData:any;
  publishedData : any=[];
  public spinnerFlag: boolean = false;
  isSelectedPublishData:boolean=false;
  popupDFData = [];
  viewDFDetails:boolean = false;
  imageURL:any;
  videoURL:any;
  routeback:any=null;
  selectedVideo:string="";
  selectedScreenShot:string="";
  tableView:boolean = false;
  commonDocumentStatusValue:any;
  isTestCaseVersionCreated:boolean= false;
   isSelectedToExecution:boolean=false;
   selectAll:boolean = false;
  @ViewChild('myTable') table: any;
  permissionData:any;
  permisionModal:Permissions=new Permissions('134',false);
  pauseSpinner:any;
  constructor(public permissionService:ConfigService,private commonService:CommonFileFTPService,private comp: AdminComponent,public route: ActivatedRoute,private router: Router,private dfServices:DiscrepancyFormRoutesService,public helper: Helper,public iqtcServices:IQTCService) { }

  ngOnInit() {

    this.tableView = true;
    this.loadData();
    this.comp.setUpModuleForHelpContent("134");
    this.comp.taskDocType = "134";
    this.comp.taskDocTypeUniqueId = "";
    this.comp.taskEquipmentId = 0;
    this.permissionService.loadPermissionsBasedOnModule("134").subscribe(resp=>{
      this.permisionModal=resp
    });
    this.route.queryParams.subscribe(rep => {
      if (rep.id !== undefined) {
        this.routeback=rep.id
        if(rep.status!=undefined){
          this.commonDocumentStatusValue = rep.status;
        }else{
          this.routeback= null;
        }
        if(rep.testcase!=undefined){
          this.viewDFOfTestCase(rep.id);
        }else{
          this.viewDF(rep.id);
        }
    }
    });
    this.helper.listen().subscribe((m:any) => {
      this.viewDF(m)
  })
  }

  ngAfterViewInit(): void {
    setTimeout(()=>{
      if(localStorage.getItem('discrepancyTab'))
        this.tab.activeId=this.helper.decode(localStorage.getItem('discrepancyTab'));
    },10)
  }

  loadData(tabId?){
    this.selectAll = false;
    var currentTab;
    if (tabId === undefined) {
      if (localStorage.getItem('discrepancyTab') != undefined) {
        currentTab = this.helper.decode(localStorage.getItem('discrepancyTab'));
      } else {
        currentTab = "pending";
      }
    } else {
      currentTab = tabId
    }
    this.spinnerFlag = true;
    this.dfServices.getDfData(currentTab).subscribe(responce=>{
    this.data = responce.unpublishedList;
    this.publishedData = responce.publishedList;
    this.completedData = responce.completedList;
    this.spinnerFlag = false;
  })
  }

  view(path,isImage){
    if(isImage)
      this.comp.downloadOrViewFile('dummyImage.png',path,true,'ScreenShot Image');
    else
      this.comp.downloadOrViewFile('dummyVideo.webm',path,true,'Recorded Video');
  }

  openSuccessCancelSwal(id) {
    var obj=this
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      obj.deleteForm(id);
    });
  }
  deleteForm(id){
    this.spinnerFlag = true;
    this.dfServices.deleteFormData(id).subscribe(response=>{

      if (response.result === "success") {
        status = "success";
        swal({
          title:'Deleted Successfully!',
          text:'Record has been deleted',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        }

        );
        this.loadData();
        this.spinnerFlag = false;
      }else{
        swal({
          title:'Delete Failed!',
          text:'Record has not been uploaded. Try again!',
          type:'error',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        }

        );
        this.spinnerFlag = false;
      }
    })
  }

  ViewFileList(fileList, isImage) {
    if (isImage)
      this.viewFile.viewImage(fileList, isImage);
    else
      this.viewFile.viewVideo(fileList, isImage);
  }

  onChangePublishData(){
    for(let data of this.publishedData){
      if(data.publishFlag){
        this.isSelectedPublishData=true;
        break;
      }else{
        this.isSelectedPublishData=false;
      }
    }
  }
  enableTableView(){
    this.comp.taskDocType = "";
    this.comp.taskDocTypeUniqueId = "";
    this.comp.taskEquipmentId = 0;
    setTimeout(() => {
      if (localStorage.getItem('discrepancyTab'))
        this.tab.activeId = this.helper.decode(localStorage.getItem('discrepancyTab'));
    }, 10)
    this.tableView = true;
    this.viewDFDetails = false;
  }
  viewDF(rowId: any) {
    this.tableView = false;
    this.spinnerFlag = true;
    this.popupDFData = [];
    this.dfServices.getDfDataById(rowId).subscribe(jsonResp => {
      if (jsonResp.data.length != 0){
        this.popupDFData.push(jsonResp.data);
        this.comp.taskDocType = this.popupDFData[0].documentType.toString();
        this.comp.taskDocTypeUniqueId = this.popupDFData[0].testCaseId;
        this.comp.taskEquipmentId = 0;
      }
     
      this.dfServices.isTestCaseCreated(rowId).subscribe(jsonResp => {
        this.isTestCaseVersionCreated = jsonResp.result;
      })
       this.workflowfunction(jsonResp);
       this.stepperfunction(jsonResp);
      setTimeout(()=>{
        this.file.loadFileListForEdit(jsonResp.data.id, jsonResp.data.testCaseName);
      },1000)
    })
  }
 wait(ms){
    var start = new Date().getTime();
    var end = start;
    while(end < start + ms) {
      end = new Date().getTime();
   }
 }
  onClickTestCase(type,id,dfId){
    if(type===+this.helper.IQTC_VALUE){
      this.router.navigate(['/iqtc/view-iqtc'], { queryParams: { id:id, status: '/df/view-df', roleBack:dfId} });
    }else if(type===+this.helper.PQTC_VALUE){
      this.router.navigate(['/pqtc/view-pqtc'], { queryParams: { id:id, status: '/df/view-df',roleBack:dfId} });
    }else if(type===+this.helper.OQTC_VALUE){
      this.router.navigate(['/oqtc/view-oqtc'], { queryParams: { id:id, status: '/df/view-df',roleBack:dfId} });
    }
    }
  viewDFOfTestCase(testcaseId: any) {
    this.tableView = false;
    this.spinnerFlag = true;
    this.popupDFData = [];
    this.iqtcServices.loadDFData(testcaseId).subscribe(jsonResp => {
      if (jsonResp.data.length != 0)
        this.popupDFData.push(jsonResp.data);
      this.viewDFDetails = true;
      this.spinnerFlag = false;
    })
  }

  stepperfunction(jsonResp: any) {
    const stepperModule: StepperClass = new StepperClass();
    stepperModule.constantName = this.helper.DISCREPANCY_VALUE;
    stepperModule.code = jsonResp.data.testCaseName;
     stepperModule.documentIdentity = jsonResp.data.id;
     stepperModule.publishedFlag = jsonResp.data.publishFlag;
     stepperModule.creatorId = jsonResp.data.creatorId;
     stepperModule.lastupdatedTime= jsonResp.data.updatedTime;
     stepperModule.displayCreatedTime= jsonResp.data.displayCreatedTime;
     stepperModule.displayUpdatedTime= jsonResp.data.displayUpdatedTime;
     stepperModule.documentTitle= jsonResp.data.testCaseName;
     stepperModule.createdBy= jsonResp.data.createdBy;
     stepperModule.updatedBy= jsonResp.data.updatedBy;
     this.wait(1000);
     this.helper.stepperchange(stepperModule);
     this.viewDFDetails = true;
     this.spinnerFlag = false;
     
  }
workflowfunction(jsonResp: any) {
  if ( jsonResp.data.publishFlag) {
    const workflowmodal: WorkflowDocumentStatusDTO = new WorkflowDocumentStatusDTO();
      workflowmodal.documentType = this.helper.DISCREPANCY_VALUE;
      workflowmodal.documentId = jsonResp.data.id;
      workflowmodal.currentLevel = jsonResp.data.currentCommonLevel;
      workflowmodal.documentCode = jsonResp.data.testCaseName;
      workflowmodal.workflowAccess = jsonResp.data.workflowAccess;
      workflowmodal.docName = 'Discripancy form';
      workflowmodal.publishFlag = jsonResp.data.publishFlag;
      this.helper.setIndividulaWorkflowData(workflowmodal);
      }
}
  publishData(){
    this.spinnerFlag = true;
    this.dfServices.publishTestCases(this.publishedData).subscribe(response => {
      if (response.result === "success") {
        status = "success";
        swal({
          title:'Submitted Successfully!',
          text:'Record has been Submitted',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        }
        );
        this.spinnerFlag = false;
        this.isSelectedPublishData=false;
      }else{
        swal({
          title:'Submittion Failed!',
          text:'Record has not been Submitted. Try again!',
          type:'error',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        }
         );
        this.spinnerFlag = false;
      }
      this.loadData();
    });
  }

  loadVideo(id) {
    this.spinnerFlag = true;
    this.dfServices.loadVideoFile(id, this.selectedVideo).subscribe(jsonResp => {
      if (jsonResp != null) {
        this.comp.downloadOrViewFile('dummyVideo.webm', jsonResp.path, true, 'Recorded Video');
      }
      this.spinnerFlag = false;
    });
  }

  reload(){
    this.loadData();
    this.closeView();
  }

  closeView(){
    this.imageURL="";
    this.selectedScreenShot="";
    this.selectedVideo="";
    this.videoURL=""
  }

  loadImage(id){
    this.spinnerFlag = true;
    this.dfServices.loadImageFile(id,this.selectedScreenShot).subscribe(jsonResp =>{
        this.imageURL = jsonResp.image;
        this.viewImageComponent.openView(this.imageURL);
        this.spinnerFlag = false;
      },error=>this.spinnerFlag = false);

  }

  publishToExecution(){
    this.dfServices.publishTestCasesToExecution(this.data).subscribe(response => {
      if (response.result === "success") {
        status = "success";
        swal({
          title:'Published Successfully!',
            text:'Record has been published',
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false
        }
        );
        this.spinnerFlag = false;
        this.isSelectedPublishData=false;
      }else{
        swal({
          title:'Published Failed!',
          text:'Record has not been published. Try again!',
          type:'error',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        }

        );
        this.spinnerFlag = false;
      }
        this.loadData();
        this.isSelectedToExecution=false;
      });
  }

  onChangeToExecutionData(){
    for(let data of this.data){
      if(data.executionFlag){
        this.isSelectedToExecution=true;
        break;
      }else{
        this.isSelectedToExecution=false;
      }
    }
  }

  tabChange(id: any){
    if(id==="pending"){
      this.loadData(id);
      this.isSelectedPublishData=false;
    }else if(id==="onGoing"){
      this.loadData(id);
      this.isSelectedToExecution=false;
    }else if(id === "completed"){
      this.loadData(id);
      this.isSelectedToExecution=false;
      this.isSelectedPublishData=false;
    }
}

selectAllData(event){
  this.selectAll = event.currentTarget.checked;
  if(event.currentTarget.checked){
    this.data.forEach(d => {
      d.executionFlag = true;
    });
    this.isSelectedToExecution = true;
  }else{
    this.data.forEach(d => {
      d.executionFlag = false;
    });
    this.isSelectedToExecution=false;
  }
}

selectAllDataForSubmit(event){
  if(event.currentTarget.checked){
    this.publishedData.forEach(d => {
      if(d.dfStatus!='Resolved')
      d.publishFlag = false;
      else
      d.publishFlag = true;
    });
    this.isSelectedPublishData = true;
  }else{
    this.publishedData.forEach(d => {
      d.publishFlag = false;
    });
    this.isSelectedPublishData=false;
  }
}
}
