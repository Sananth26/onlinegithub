import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-discrepancy-form',
  templateUrl: './discrepancy-form.component.html',
  styleUrls: ['./discrepancy-form.component.css','../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class DiscrepancyFormComponent implements OnInit {
  
  
  constructor() {  }

  ngOnInit() {
  }
  
}
