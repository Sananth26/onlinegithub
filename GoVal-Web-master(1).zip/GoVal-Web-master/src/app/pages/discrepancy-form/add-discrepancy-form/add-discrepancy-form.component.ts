import { AfterViewInit, Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IOption } from 'ng-select';
import { ISubscription } from 'rxjs/Subscription';
import swal from 'sweetalert2';
import { AdminComponent } from '../../../layout/admin/admin.component';
import { CheckListDTO, DiscrepancyForm, LookUpItem } from '../../../models/model';
import { Helper } from '../../../shared/helper';
import { DashBoardService } from '../../dashboard/dashboard.service';
import { DepartmentService } from '../../department/department.service';
import { FileUploadForDocComponent } from '../../file-upload-for-doc/file-upload-for-doc.component';
import { IQTCService } from '../../iqtc/iqtc.service';
import { projectPlanService } from '../../projectplan/projectplan.service';
import { projectsetupService } from '../../projectsetup/projectsetup.service';
import { UserService } from '../../userManagement/user.service';
import { DiscrepancyFormRoutesService } from '../discrepancy-form.service';

@Component({
  selector: 'app-discrepancy-form',
  templateUrl: './add-discrepancy-form.component.html',
  styleUrls: ['./add-discrepancy-form.component.css', '../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddDiscrepancyFormComponent implements OnInit, AfterViewInit {
  hideModal=false;
  @ViewChild('fileupload') public file: FileUploadForDocComponent;
  public docItemList: any;
  public departmentList: any;
  public simpleOption: Array<IOption> = new Array<IOption>();
  public simpleOptionDepartment: Array<IOption> = new Array<IOption>();
  public receivedId: string;
  public isUpdate: boolean = false;
  public isSave: boolean = false;
  public userList: any;
  public dynamicId: any;
  public isClicked: boolean = false;
  public selectdocument: any;
  public blockdocument: boolean;
  public disableFeild: boolean = false;
  public subscription: ISubscription;
  public spinnerFlag: boolean = true;
  public documentType: string;
  public modal: DiscrepancyForm = new DiscrepancyForm();
  editorSwap = false;
  public editor;
  submitted: boolean = false;
  actionTaken = false;
  resultAction = false;
  public errorMessage: string;
  public requestNoEnable = true;
  public dfStatus: LookUpItem;
  public failDocCodes: any[] = new Array();
  checklistName: string = "";
  isAddChecklist: boolean = false;
  fileList: any[] = new Array();
  isAddChecklistName: boolean = false;
  holdImage: boolean = false;
  holdvideo: boolean = false;
  testcaseName :any;
  videoFile: any = null;
  showAppCard: boolean = true;
  showCardFlag: boolean = false;
  testCaseType: string;
  editing = {};
  selectedCheckList:any;
    processedChecklistImages: any[] = new Array();
    checkListImages: Array<any> = [];
    @ViewChild('checkListImageModal') checkListImageModal: any;
    public slideIndex = 0;
  constructor(private comp: AdminComponent, public dfServices: DiscrepancyFormRoutesService,
    public dashBoardService: DashBoardService, public userService: UserService,
    public helper: Helper, public Service: projectsetupService,
    public deptService: DepartmentService, public route: ActivatedRoute,
    public projectplanService: projectPlanService, public _eref: ElementRef,
    public router: Router, public adminComponent: AdminComponent,
    public IqtcService: IQTCService) {

  }
  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this.receivedId != undefined) {
        this.spinnerFlag = true;
        this.file.loadFileListForEdit(this.receivedId, this.modal.testCaseName);
        this.spinnerFlag = false;
      }
    }, 1000);
  }

  ngOnInit() {
    this.route.queryParams
      .subscribe(params => {
        if (params.id != undefined && params.fileId === undefined) {
          this.IqtcService.getDataForEdit(params.id).subscribe(jsonResp => {
            this.loadall();
            this.modal.requestRaised = false;
            this.testCaseType = jsonResp.result.testCaseType;
            this.modal.testCaseName = jsonResp.result.testCaseCode;
            if (this.testCaseType.toUpperCase() == "IQTC") {
              this.modal.documentType = "" + 108
            } else if (this.testCaseType.toUpperCase() == "PQTC") {
              this.modal.documentType = "" + 109
            } else {
              this.modal.documentType = "" + 110
            }
            this.modal.testCaseId = "" + params.id
            this.documentType = this.testCaseType.toUpperCase();
            this.failDocCodes = new Array();
            this.failDocCodes.push({ 'key': this.modal.testCaseId, 'value': this.modal.testCaseName });

            this.disableFeild = true;
          })
        }
        if (params.fileId != undefined) {
          this.loadall();
          this.fileList = new Array();
          this.failDocCodes = new Array();
          this.modal = JSON.parse(params.rowData);
          this.modal.videoFileId = params.fileId;
          this.onChangeDocument();
          this.documentType = this.modal.documentCode;
          this.disableFeild = true;
        }
      });

    this.receivedId = this.route.snapshot.params["id"];
    if (this.receivedId != undefined)
      this.dfServices.getDfDataById(this.receivedId).subscribe(result => {
        this.loadall();
        this.modal = result.data;
        this.fileList = new Array();
        this.modal.documentType = "" + result.data.documentType;
        this.modal.testCaseId = "" + result.data.testCaseId;
        this.documentType = this.modal.documentCode;
        this.failDocCodes = new Array();
        this.failDocCodes.push({ 'key': this.modal.testCaseId, 'value': this.modal.testCaseName });
      })
    this.loadAllUsersBasedOnProject();
    this.dfServices.getDFStatus().subscribe(responce => {
      this.dfStatus = responce.statusList;
    })
    this.subscription = this.adminComponent.globalProjectObservable.subscribe(
      data => {
        this.loadall();
      },
      err => console.log(err),
      () => console.log('complete'),
    );
    this.spinnerFlag = false;
    this.comp.setUpModuleForHelpContent("134");
  }
  loadall() {
    this.dashBoardService.loadProjectDocs().subscribe(resp => {
      this.docItemList = [];
      this.docItemList = new Array<any>();
      this.selectdocument = new Array<any>();
      for (const key in resp.result) {
        if (key == "108" || key == "109" || key == "110") {
          this.selectdocument.push({ 'id': key, 'name': resp.result[key] });
        }
      }
      this.projectplanService.load().subscribe(jsonResp => {
        this.receivedId = this.route.snapshot.params["id"];
        if (this.receivedId === undefined) {
          this.loadAllUsersBasedOnProject();
        }
        else {
          this.blockdocument = true;
        }
      });
    },
      err => {
      }
    );
    this.deptService.loadDepartment().subscribe(jsonResp => {
      this.simpleOptionDepartment = this.helper.cloneOptions(jsonResp.result);
    });
    this.receivedId = this.route.snapshot.params["id"];
    if (this.receivedId !== undefined) {
      this.isUpdate = true;
      this.spinnerFlag = false;
    } else {
      this.spinnerFlag = false;
      this.isSave = true;
    }

  }
  onEditorBlured(quill) {
  }

  onEditorFocused(quill) {
  }

  onEditorCreated(quill) {
    this.editor = quill;
  }

  onContentChanged({ quill, html, text }) {
  }

  loadAllUsersBasedOnProject() {
    this.userService.loadAllUserBasedOnProject().subscribe(response => {
      this.simpleOption = this.helper.cloneOptions(response.result);
    });
  }

  onChangeDocument() {
    this.failDocCodes = [];
    switch ("" + this.modal.documentType) {
      case "108":
        this.documentType = "IQTC";
        this.populateFailDocuments("Fail", 1);
        break;
      case "109":
        this.documentType = "PQTC";
        this.populateFailDocuments("Fail", 3);
        break;
      case "110":
        this.documentType = "OQTC";
        this.populateFailDocuments("Fail", 2);
        break;
    }
  }
  populateFailDocuments(status: any, testCaseId: any) {
    this.spinnerFlag = true
    this.dfServices.populateFailDocument(status, testCaseId).subscribe(responce => {
      this.failDocCodes = responce.failDocList;
      this.spinnerFlag = false;
    });
  }
  getTestCaseCode(id){
    this.testcaseName = "";
    this.failDocCodes.forEach(element=>{
      if(id===element.key){
        this.testcaseName = element.value;
      }
    });
  }
  saveAndGoto(formIsValid) {
    this.submitted = false;
    this.spinnerFlag = true;
    if (!formIsValid) {
      this.submitted = true;
      this.spinnerFlag = false;
      return
    }
    this.modal.documentCode = this.documentType;
    this.dfServices.saveDF(this.modal).subscribe(responce => {
      this.failDocCodes = [];
      this.file.uploadFileList(responce.dto, this.helper.DISCREPANCY_VALUE).then(re=>{
      if (responce.result === "success") {
        this.modal = responce.dto;
        this.spinnerFlag = false;
       let message= this.isUpdate?"updated successfully":"saved successfully";
        swal({
          title: 'Success',
          text: 'Discrepancy form '+message,
          type: 'success',
          timer: this.helper.swalTimer,
          showConfirmButton: false,
          onClose: () => {
            if (this.router.url.search("masterControl") != -1) {
              this.router.navigate(["/masterControl"]);
            } else {
              this.router.navigate(["/df/view-df"]);
            }
            this.spinnerFlag = false;
            this.isUpdate = false;
          }
        });
      } else {
        swal({
          title: 'Error!',
          text: 'Oops something went Worng..',
          type: 'error',
          timer: this.helper.swalTimer,
          showConfirmButton: false,
          onClose: () => {
            if (this.router.url.search("masterControl") != -1) {
              this.router.navigate(["/masterControl"]);
            } else {
              this.router.navigate(["/df/view-df"]);
            }
            this.spinnerFlag = false;
          }
        });
      }
    });
    });

  }

  screenShot() {
    window.scrollTo(0, 0);
   
  }

  saveImage() {
    this.holdImage = true;
  }

  cancelImage() {
    this.modal.imageBase64 = null;
    this.holdImage = false;
  }

  show() {
    this.comp.openModalForScreenrecording(this.modal, 0, "/df/add-df", this.receivedId);
  }

  hide() {
    this.showCardFlag = false;
    this.showAppCard = true;
  }

  addCheckList() {
    this.isAddChecklist = true;
    this.isAddChecklistName = true;
  }

  editRow(rowIndex) {
    for (let index = 0; index < this.modal.checklist.length; index++) {
      if (rowIndex == index)
        this.editing[index] = true;
      else
        this.editing[index] = false;
    }
  }

  deleteChecklistItem(index) {
    this.modal.checklist.splice(index, 1);
  }

  addChecklistItem() {
    this.isAddChecklistName = true;
  }

  saveChecklistItem() {
    let data = new CheckListDTO();
    data.checklistName = this.checklistName;
    this.modal.checklist.push(data);
    this.isAddChecklistName = false;
    this.checklistName = "";
  }

  closeChecklistItem() {
    this.isAddChecklistName = false;
    this.checklistName = "";
  }

  onSelectChecklist(item: CheckListDTO) {
    item.updatedTime = new Date();
    // this.IqtcService.updateChecklist(item).subscribe(jsonResp => {
    // });
  }
  onChangeCheckListImage(event,item) {
    this.processedChecklistImages=  new Array();
    this.checkListImages = new Array();
    for (let index = 0; index < event.target.files.length; index++) {
      const file: File = event.target.files[index];
      this.IqtcService.getFileNameAndURL(file).then((res) => {
          let image = { visible: false, fileName: file.name, imageDataUrl: res };
          item.files.push(image);
      });
  }
   
}
plusCheckListSlides(n) {
    let index = this.processedChecklistImages.findIndex(function (element) {
        return element.visible === true;
      });
      if (n == 1) {
        let next = index + 1;
        if (next < this.processedChecklistImages.length) {
            this.processedChecklistImages[index].visible = false;
            this.processedChecklistImages[++index].visible = true;
        } else {
            this.processedChecklistImages[index].visible = false;
            this.processedChecklistImages[0].visible = true;
            index = 0;
        }
    } else {
        let prev = index - 1;
        let next =index;
        if (prev < 0) {
            this.processedChecklistImages[index].visible = false;
            this.processedChecklistImages[this.processedChecklistImages.length - 1].visible = true;
            index = this.processedChecklistImages.length - 1;
        } else {
            this.processedChecklistImages[prev].visible = true;
            this.processedChecklistImages[next].visible = false;
            index = prev;
        }
    }
} 
showCheckListModal(item:any) {
    this.selectedCheckList=item;
    this.checkListImages=this.selectedCheckList.files;
    this.processedChecklistImages=this.selectedCheckList.files;
    if(this.processedChecklistImages.length > 0){
        this.processedChecklistImages.forEach(element =>{
            element.visible=false;
        })
        this.processedChecklistImages[0].visible=true;
        this.checkListImageModal.show();
    }
} 
deleteCheckListSlide(){
    let index = this.processedChecklistImages.findIndex(function (element) {
        return element.visible === true;
      });
    this.processedChecklistImages.splice(index,1);
    if(this.processedChecklistImages.length > 0){
        this.processedChecklistImages.forEach(value => {
            value.visible=false;
        });
        this.processedChecklistImages[0].visible=true;
    } else {
        this.checkListImageModal.hide();
    }
    this.selectedCheckList.files=this.processedChecklistImages;
}
deleteCheckListImages(item){
    item.files=new Array();
} 
}
