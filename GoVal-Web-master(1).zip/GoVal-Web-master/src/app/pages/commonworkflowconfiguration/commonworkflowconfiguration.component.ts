import { Component, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { IOption } from 'ng-select';
import swal from 'sweetalert2';
import { ModalBasicComponent } from '../../shared/modal-basic/modal-basic.component';
import { WorkflowConfigurationService } from '../workflow-configuration/workflow-configuration.service';
import { WorkFlowLevelsService } from '../workflow-levels/workflow-levels.service';
import { AdminComponent } from './../../layout/admin/admin.component';
import { CommonModel, flowMasterDto, flowNotificationDto, WorkFlowLevelDTO } from './../../models/model';
import { Helper } from './../../shared/helper';
import { userRoleservice } from './../role-management/role-management.service';
import { WorkflowFlowchartComponent } from './../workflow-flowchart/workflow-flowchart.component';
import { CwfService } from './commonworkflowconfiguration.service';
import { Permissions } from '../../shared/config';
import { ConfigService } from '../../shared/config.service';
@Component({
  selector: 'app-wokflowconfiguration',
  templateUrl: './commonworkflowconfiguration.component.html',
  styleUrls: ['./commonworkflowconfiguration.component.css','./../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})

export class CommonworkflowconfigurationComponent implements OnInit {
public data: any;
public workflowSettingsList: any[] = new Array();
@Input('projectId') projectId;
@Input('projectName') projectName;
@ViewChild('emailNotificationSettings') emailNotificationSettings:any;
@ViewChild('copyConfigurationModal') copyConfigurationModal:any;
@ViewChild('copyLevelConfigurationModal') copyLevelConfigurationModal:any;
@ViewChild('modalWorkFlowSetting') modalWorkFlowSetting:ModalBasicComponent;
public droppedItems: any[] = new Array();
public documentList: any[] = new Array();
public formList: any[] = new Array();
public temp:any;
public changetab:false;
@ViewChild('tabRef') tabset;
public templateList: any[] = new Array();
public formGroupList: any[] = new Array();
public workflowLevelList: any[] = new Array();
public workflowConfigurationformGroup = null;
public workflowLevelDto: WorkFlowLevelDTO = new WorkFlowLevelDTO();
public levelId: any[] =new Array();
public add: Boolean = false;
public value1: any;
public minvalueforweek:any;
public value2: any;
public filterQuery:any;
public createLevel: Boolean = false;
@ViewChild('workFlowChart') workFlowChart:WorkflowFlowchartComponent;
public levelName: any;
public roles: Array<IOption> = new Array<IOption>();
public users: Array<IOption> = new Array<IOption>();
public rolesId: any[] = new Array();
public usersId: any[] = new Array();
public checkedRoles: Boolean = false;
public checkedUsers: Boolean = false;
public notificationModalList: flowNotificationDto[]=new Array();
public validSave: Boolean;
public saveModal: flowMasterDto = new flowMasterDto();
public documentNumber: any = null;
public documentConstant: any = null;
public documentDisplayOrder=0;
public documentName: any;
public freezeComments: any;
public freezeData: any;
map = new Map<string, any>();
isLoading=false;
spinnerFlag=false;
copyConfigurationList:any=new Array();
documentConfigurationNeedToBeApplied="";
copyLevelConfigurationList:any=new Array();
levelConfigurationToBeApplied:any=null;
freezeFlagForLevel=false;
switchButtonColorFlag=false;
documentlockData:any;
modal:Permissions=new Permissions('222',false);
documentlockDataLogs:any[]=new Array();

  constructor(private sservice: CwfService,public service: WorkflowConfigurationService,public permissionService:ConfigService,
    public levelService: WorkFlowLevelsService, private helper: Helper, private rolesService: userRoleservice,private adminComponent:AdminComponent) {
      this.weekminvalidation()
      $(document).ready(function () {
    $('.card').on('click', function() {
  if ($(this).hasClass('open')) {
    $('.card').removeClass('open');
    $('.card').removeClass('shadow-2');
    $(this).addClass('shadow-1');
    return false;
  } else {
    $('.card').removeClass('open');
    $('.card').removeClass('shadow-2');
    $(this).addClass('open');
    $(this).addClass('shadow-2');
  }
});
    });
  }

  ngOnInit() {
    this.loaddata()
    this.permissionService.loadPermissionsBasedOnModule('222').subscribe(resp => {
      this.modal = resp;
    });
    this.workflowConfigurationformGroup = new FormGroup({
      levelname: new FormControl(this.workflowLevelDto.workFlowLevelName, [Validators.required]),
      password: new FormControl(this.workflowLevelDto.value, [Validators.required]),
    });
    this.adminComponent.setUpModuleForHelpContent("222");
   }

   loaddata(){
    this.sservice.loadall().subscribe((resp) => {
      this.data = resp;
      this.temp=this.data;
      console.log(this.data)

    });
   }




  loadLevels(list?:any[]) {
    this.workflowLevelList = new Array();
    this.levelService.loadWorkFlow().subscribe((resp) => {
      this.workflowLevelList = resp.list;
      if(list){
      let levelIdsArray: any[] = list.map(df => df.levelId);
      this.workflowLevelList = this.workflowLevelList.filter(d => ! levelIdsArray.includes(d.id));
      }

      this.workflowLevelList= this.workflowLevelList.map(option => ({ value: option.id, label: option.workFlowLevelName }));
    });
  }

  addAll(list, addFlag) {
    list.forEach(element => {
    });
  }

  moveUpOrDown(list: any[], index, upFlag) {
    this.switchButtonColorFlag=true;
    let i
    if (upFlag) {
      i = index - 1;
    } else {
      i = index + 1;
    }
    if (i !== undefined) {
      let element = list[index];
      list[index] = list[i];
      list[i] = element;
    }

    this.updateLevelOrderOfDocument(list)
  }


  createWorkflowLevel() {
    this.isLoading = true;
    this.spinnerFlag=true;
    this.workflowLevelDto.workFlowLevelName = this.levelName;
    this.levelService.saveWorkFlow(this.workflowLevelDto).subscribe((resp) => {
      this.isLoading = false;
      this.spinnerFlag=false;
      let responseMsg: string = resp.result;
      let data: any = resp.dto;
      if (responseMsg === "success") {
        if (data.id != 0) {
          this.loadLevels(this.saveModal.documentFlows);
          this.createLevel = false;
          this.levelId=new Array();
          this.levelId.push(data.id);
          this.validateSave();
          swal({ title: 'Success', text: 'Level Saved Successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
        } else {
          swal({ title: 'Waring', text: data.errorMessage, type: 'warning', timer: 2000 ,showConfirmButton:false });
        }
      } else {
        swal({ title: 'Not Saved!', text: 'Level has  not been saved', type: 'error', timer: 2000 ,showConfirmButton:false });
      }
    },
      err => {
      this.isLoading = false;
        swal({ title: 'Not Saved!', text: 'Level has  not been saved', type: 'error', timer: 2000 ,showConfirmButton:false });
      });
  }


  loadSettingsAndUsers(flowId: any) {
    this.loadroles();

    const commonmodal: CommonModel = new CommonModel();
    commonmodal.currentCommonLevel = flowId;
    this.service.loadworkFlowSettingsAndUsers(commonmodal).subscribe((resp) => {
      this.workflowSettingsList = resp.data;
      this.notificationModalList=resp.users;
      if(this.notificationModalList!=null){
        this.rolesId=this.notificationModalList.map(u=>''+u.roleIdOfUser);
        this.loadUser( this.rolesId);
        this.usersId=this.notificationModalList.map(u=>''+u.userId);
        this.add = true;
      }else{
        this.add = true;
      }
      this.validateSave();
    });

  }

  removeoptions(item: any) {
    this.workflowSettingsList.forEach(element => {
      if (element.settingsName === item.settingsName && !item.check) {
        element.flowSubSettings.forEach(e => {
          e.blocked = true;
        });
      }
      if (element.settingsName === item.settingsName && item.check) {
        element.flowSubSettings.forEach(e => {
          e.blocked = false;
        });
      }
    });

  }



  loadroles() {
    this.rolesService.loadListOfrolesIfUserExists().subscribe((resp) => {
      this.roles = resp.map(option => ({ value: option.key, label: option.value }));
    });
  }
  loadNotification(userIds,viewFlag) {
    this.usersId=userIds;
    if (!this.notificationModalList) {
      this.notificationModalList = new Array();
    }
    const usersSelected = this.users.filter(el => this.usersId.includes(el.value));
    const userSelectedNotification = this.notificationModalList.map(option => '' + option.userId);
    const userNotHavingNotification = usersSelected.filter(fl => !userSelectedNotification.includes(fl.value));

    if (userNotHavingNotification.length > 0) {
      for (let index = 0; index < userNotHavingNotification.length; index++) {
        const element = userNotHavingNotification[index];
        if (this.usersId.includes(element.value)) {
          let data: flowNotificationDto = new flowNotificationDto();
          data.userId = Number(element.value);
          data.userName = element.label;
          this.notificationModalList.push(data);
        }
      }
    }
    for (let nIndex = 0; nIndex < this.notificationModalList.length; nIndex++) {
      const nele = this.notificationModalList[nIndex];
      if (!this.usersId.includes('' + nele.userId))
        delete this.notificationModalList[nIndex];
    }
    this.notificationModalList=this.notificationModalList.filter(m=>m);
    this.notificationModalList.sort((a, b) => a.userName.localeCompare(b.userName));
    if (viewFlag)
      this.emailNotificationSettings.show();
  }


  loadUser(roleIds:any[]) {
    this.usersId=new Array()
    this.rolesService.loadListOfusers(roleIds).subscribe((resp) => {
      this.users = resp.map(option => ({ value: option.key, label: option.value }));
    });
  }

  selectAllRoles() {
    this.rolesId = new Array();
    if (this.checkedRoles) {
      this.roles.forEach(element => {
        this.rolesId.push(element.value);
      });
    }
    this.loadUser( this.rolesId);
    setTimeout(()=> this.validateSave(),1000);

  }

  selectAllUsers() {
    this.usersId = new Array();
    if (this.checkedUsers) {
      this.users.forEach(element => {
        this.usersId.push(element.value);
      });
      this.loadNotification(this.usersId,false);
    }
    setTimeout(()=> this.validateSave(),1000);
  }

  validateSave() {
    const data = this.workflowSettingsList.filter(element =>
      element.mainPageCheck && true === element.check
    );
    if (data.length > 0 && this.rolesId.length > 0 && this.usersId.length > 0 && this.levelId.length!=0) {
      this.validSave = true;
    } else {
      this.validSave = false;
    }
  }
  onChangeusers(event){
    const data = this.workflowSettingsList.filter(element =>
      element.mainPageCheck && true === element.check
    );
    if (data.length > 0 && event.length > 0) {
      this.validSave = true;
    } else {
      this.validSave = false;
    }
  }

   loadFlowDatasOfDocument(data):Promise<void> {
    return new Promise<void>(resolve => {
    const modal: CommonModel = new CommonModel();
    modal.projectSetupconstantName = data.key;
    modal.projectSetupProjectId =this.projectId
    this.saveModal = new flowMasterDto();
    this.saveModal.projectName=this.projectName;
    this.saveModal.documentName=data.value;
    this.service.loadFlowData(modal).subscribe((resp) => {
      if(resp.result!=null)
      this.saveModal=resp.result
      this.documentName = data.value;
      this.documentConstant = data.key;
      this.documentDisplayOrder=data.displayOrder;
      this.documentNumber=this.saveModal.documentNumber;
      this.workFlowChart.loadAllDataForDocumentForProject(this.projectId,data.key);
      resolve()
    });
  })
  }


  saveLevelData() {
    if (this.validSave) {
      this.modalWorkFlowSetting.spinnerShow();
      this.saveModal.documentNumber = this.documentNumber;
      this.saveModal.levelId = Number(this.levelId);
      this.saveModal.flowNotificationDto = this.notificationModalList;
      this.saveModal.settings = this.workflowSettingsList;
      this.saveModal.documentDisplayOrder = this.documentDisplayOrder;
      this.saveModal.saveType="CommonWorkflow";
      this.service.saveWorkFlowData(this.saveModal).subscribe((resp) => {
        this.modalWorkFlowSetting.spinnerHide();
        if (resp.result === 'success') {
          this.modalWorkFlowSetting.hide()
          this.loaddata()
          swal({ title: 'Success', text: 'Workflow Level Saved Successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
        } else {
          swal({ title: 'Not Saved!', text: 'Workflow Level has not been saved', type: 'error', timer: 2000 ,showConfirmButton:false });
        }
      }, err => {
        this.modalWorkFlowSetting.spinnerHide();
          swal({ title: 'Not Saved!', text: 'Workflow Level has not been saved', type: 'error', timer: 2000 ,showConfirmButton:false });
      });
    }
  }

  loadDataForFlow(index,item){
    this.switchButtonColorFlag=false;
    this.freezeFlagForLevel=item.freezeFlag;
    this.add=false
    this.loadFlowDatasOfDocument(item);
    this.modalWorkFlowSetting.show();
}

addNewLevelForDocument(alreadyFlowList:any[],item){

  this.loadLevels(alreadyFlowList);
  this.loadSettingsAndUsers(0);
  this.checkedRoles = false;
  this.documentName=item.documentName;
  this.checkedUsers = false;
  this.rolesId = new Array();
  this.usersId = new Array();
  this.loadroles();
  this.levelId = new Array();
  this.levelName = null;
  this.createLevel = false;
  let levelOrder = 1;
  if (null!=alreadyFlowList && alreadyFlowList.length != 0)
    levelOrder = alreadyFlowList.length + 1;
  this.saveModal = new flowMasterDto();
  this.saveModal.documentConstantName=item.documentConstantName;
  this.saveModal.url=window.location.href

  this.saveModal.levelOrder = levelOrder;
 this.validateSave();
  this.add = true;
}
  editLevelOfDocument(item,mainitem) {

    this.loadLevels(this.saveModal.documentFlows.filter(df=>df.levelId!==item.levelId));
    this.loadSettingsAndUsers(item.id);
    this.saveModal.url=window.location.href
    if(mainitem.exists)
    this.freezeFlagForLevel=true;
    else
    this.freezeFlagForLevel=false;
    this.saveModal.flowId = item.id;
    this.saveModal.documentConstantName=mainitem.documentConstantName;
    this.saveModal.levelId = item.levelId;
    this.levelId=[];
    this.levelId.push(item.levelId);
    this.saveModal.levelOrder = item.orderId;
    this.saveModal.documentCurrentFlowId = item.documentMasterId;

  }

  diableOtherSetting(item, workflowSettingsList: any[]) {
    item.check = !item.check;
    workflowSettingsList.forEach(element => {
      if (element.settingsName !== item.settingsName)
        element.check = false;
    })
    setTimeout(()=> this.removeoptions(item),1000);
    setTimeout(()=> this.validateSave(),1000);

  }
  disableOtherSubSetting(s, list) {
    s.check = !s.check;
    list.forEach(element => {
      if (element.subSettingsName !== s.subSettingsName)
        element.check = false;
    })
    this.validateSave();
  }


  updateLevelOrderOfDocument(list){
    for (let index = 0; index < list.length; index++) {
      list[index].orderId=index+1;
    }
    this.service.updateLevelOrderOfDocument(list).subscribe(resp=>{
      if (resp.result === 'success')
      swal({ title: 'Success', text: 'Level Order Updated Successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
      else
      swal({ title: 'Not Updated!', text: 'Level Order has not been updated', type: 'error', timer: 2000 ,showConfirmButton:false });
    })
  }

  loadAllDataForDocumentForProject(data){
    this.workFlowChart.loadAllDataForDocumentForProject(this.projectId,data.key);
  }

  updateDocumentOrderOfProject(list:any[]){
    let sortedList=new Array();
    for (let index = 0; index < list.length; index++) {
      list[index].displayOrder=index+1;
      sortedList.push({
        "displayOrder": list[index].displayOrder,
        "key": list[index].key
      })
    }


    this.service.updateDocumentOrderOfProject(sortedList,this.projectId).subscribe(resp=>{
      if (resp.result === 'success')
      swal({ title: 'Success', text: 'Document Order Updated Successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
      else
      swal({ title: 'Not Updated!', text: 'Document Order has not been updated', type: 'error', timer: 2000 ,showConfirmButton:false });
    })
  }


  deleteLevelOfDocumentSwal(item,flagLevelDelete,freezeFlag) {
    var obj = this;
    if(freezeFlag){
      swal({ title: 'Info', text: 'Cannot be deleted as workflow has started', type: 'warning', timer: 3000,allowOutsideClick: false });
    }else{
      swal({title: 'Are you sure?', text: 'You wont be able to revert',type: 'warning',
      showCancelButton: true,confirmButtonColor: '#3085d6',cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',cancelButtonClass: 'btn btn-danger',allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      if(flagLevelDelete)
      obj.deleteLevelOfDocument(item);
      else{
        obj.deleteDocumentOfProject(item.mappingFlag?item.mappingId:item.key,item.mappingFlag);
        let category = item.mappingFlag ? obj.helper.PERMISSION_CATEGORY_FORM_GROUP : item.mappingId;
        if (localStorage.getItem(category)) {
        let list = JSON.parse(atob(localStorage.getItem(category))).filter(d => d.key != item.key);
        localStorage.setItem(category,btoa(JSON.stringify(list)))
      }
      }

    });
    }

  }
  deleteLevelOfDocument(id) {

    this.spinnerFlag = true;
    this.service.deleteLevelOfDocument(id,"CommonWorkflow").subscribe((resp) => {
        this.spinnerFlag = false;
        let responseMsg: string = resp.result;
        this.loadFlowDatasOfDocument({key:this.documentConstant,value:this.documentName,displayOrder:this.documentDisplayOrder})
        if (responseMsg === "success") {
          swal({ title: 'Success', text: 'Level is deleted successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
       this.loaddata()
        } else {
          swal({ title: 'Error!', text: 'Error in deleting level', type: 'error', timer: 2000 ,showConfirmButton:false });
        }
      }, (err) => {swal({ title: 'Error!', text: 'Error in deleting level', type: 'error', timer: 2000 ,showConfirmButton:false });this.spinnerFlag = false;
      });
  }

  deleteDocumentOfProject(documentConstant,mappingFlag) {
    this.spinnerFlag = true;
    this.service.deleteDocumentOfProject(this.projectId,documentConstant,mappingFlag).subscribe((resp) => {
        this.spinnerFlag = false;
        let responseMsg: string = resp.result;

        if (responseMsg === "success") {
          swal({ title: 'Success', text: 'Document is deleted successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
        } else {
          swal({ title: 'Error!', text: 'Error in deleting document', type: 'error', timer: 2000 ,showConfirmButton:false });
        }
      }, (err) => {swal({ title: 'Error!', text: 'Error in deleting document', type: 'error', timer: 2000 ,showConfirmButton:false });this.spinnerFlag = false;
      });
  }

  copyConfiguration(list:any[],item){
    let newArray = JSON.parse(JSON.stringify(list))
    let fGchild = newArray.filter(l => !l.configuration && l.mappingFlag).map(c => c.child);
    let formGrouping=new Array();
    fGchild.forEach(i => {
      i.forEach(element => {
        formGrouping.push(element)
      });
    });
    this.copyConfigurationList = newArray.filter(l => !l.configuration && !l.mappingFlag);
    this.copyConfigurationList.push(...formGrouping.filter(l => !l.configuration));
    this.documentConfigurationNeedToBeApplied = item.key;
    this.copyConfigurationModal.show();
  }

  applyConfigurationSwal(list,flag) {
    var obj = this
    swal({
      title: 'Are you sure?', text: 'You wont be able to revert', type: 'warning',
      showCancelButton: true, confirmButtonColor: '#3085d6', cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, apply it!', cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10', cancelButtonClass: 'btn btn-danger',allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      if(flag)
      obj.applyConfigurationOfDocument(list, obj.documentConfigurationNeedToBeApplied, obj.projectId);
      else
      obj.applyConfigurationOfLevel(list, obj.levelConfigurationToBeApplied);
    });
  }

  applyConfigurationOfDocument(list,documentConstant,projectId){
     let keyList=JSON.parse(JSON.stringify(list)).filter(d=>d.configuration).map(l=>l);
      this.service.copyConfiguration(keyList,documentConstant,projectId).subscribe(resp=>{
          if (resp.result === "success") {
            swal({ title: 'Success', text: 'Document configuration copy is done successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
            this.copyConfigurationModal.hide();

          } else {
            swal({ title: 'Error!', text: 'Error in copying configuration', type: 'error', timer: 2000 ,showConfirmButton:false });
          }

      })
}

copyLevelConfiguration(item){
  this.loadLevels(this.saveModal.documentFlows);
  this.levelId=new Array()
  this.levelName;
  this.levelConfigurationToBeApplied=item;
  this.copyLevelConfigurationModal.show();
}

applyConfigurationOfLevel(list,item){
  this.service.copyConfigurationOfLevel(list,item).subscribe(resp=>{
    if (resp.result === "success") {
      swal({ title: 'Success', text: 'Level configuration copy is done successfully', type: 'success', timer: 2000 ,showConfirmButton:false });
      this.loadDataForFlow(0, { 'key': this.documentConstant, 'value': this.documentName,'freezeFlag':this.freezeFlagForLevel,'displayOrder':this.documentDisplayOrder });
      this.copyLevelConfigurationModal.hide();
    } else {
      swal({ title: 'Error!', text: 'Error in copying configuration', type: 'error', timer: 2000 ,showConfirmButton:false });
    }

})

}
  addToLocalStorage(key, data) {
    if (localStorage.getItem(key)) {
      let list: any[] = JSON.parse(atob(localStorage.getItem(key)))
      list.push(data)
      localStorage.setItem(key, btoa(JSON.stringify(list)));
    } else {
      localStorage.setItem(key, btoa(JSON.stringify([data])));
    }
  }

  filtermodule(){
    if(this.filterQuery!=undefined && this.filterQuery!="")
    this.data=this.data.filter(d=>( d.documentName.toLowerCase().includes(this.filterQuery.toLowerCase())))
        else {
          this.data=this.temp;
        }
      }


  weekminvalidation(){
  let year=  new Date().getFullYear();
  var elm = document.createElement('input')
  elm.type = 'week'
  elm.valueAsDate = new Date()
  var week = elm.value.split('W').pop()
  this.minvalueforweek=year+"-W"+week;
  }

test(){
  console.log("sdfsfsd");
}

}
