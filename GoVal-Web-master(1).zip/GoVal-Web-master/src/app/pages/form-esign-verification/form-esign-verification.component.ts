import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import swal from 'sweetalert2';
import { ConfigService } from '../../shared/config.service';
import { eSignErrorTypes } from '../../shared/constants';
import { ModalAnimationComponent } from '../../shared/modal-animation/modal-animation.component';
import { SignaturePad } from 'angular2-signaturepad/signature-pad';

@Component({
  encapsulation:ViewEncapsulation.None,
  selector: 'app-form-esign-verification',
  templateUrl: './form-esign-verification.component.html',
  styleUrls: ['./form-esign-verification.component.css','./../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'
]
})
export class FormEsignVerificationComponent implements OnInit {
  @ViewChild(SignaturePad) signaturePad: SignaturePad;
  @ViewChild('formVerification') formVerificationModal:ModalAnimationComponent;
  modal = {
    emailOrUserName: '',
    password: '',
    comments: '',
    documentCode: '',
    documentId: '',
    documentType:'',
    signature:''
  }
  errorMessage = '';
  verificationFormBuilder:FormGroup = null;
  submitted = false;
  viewSignature=false;
  public signaturePadOptions: Object = {
    'minWidth': 1,
    'canvasWidth': 540,
    'canvasHeight': 200,
  };
  constructor(public formBuilder: FormBuilder,private config:ConfigService,private errorMessageHelper:eSignErrorTypes) { }

  ngOnInit() {
    this.modal.comments='';
    this.verificationFormBuilder = this.formBuilder.group({
      emailOrUserName: [this.modal.emailOrUserName, [Validators.required]],
      password: [this.modal.password, [Validators.required]],
      comments: [this.modal.comments],
      signature: [this.modal.signature]
    });
  }

  openMyModal(documentType,documentCode, documentId) {
    this.modal = {
      emailOrUserName: '',
      password: '',   
      comments: '',
      documentCode: documentCode,
      documentId: documentId,
      documentType:documentType,
      signature:''
    }
    this.verificationFormBuilder.reset();
    this.submitted = false;
    this.errorMessage = '';
    try {
      document.querySelector('#effect-1').classList.add('md-show');
      this.clearSignature();
      this.viewSignature=false;
    } catch (error) {

    }
    setTimeout(() => {
      $('#formVerificationComments').focus();
    }, 1000);

  }

  closeMyModal() {
    return new Promise<any>((resolve)=>{
      try {
        this.verificationFormBuilder.reset();
        document.querySelector('#effect-1').classList.remove('md-show');
        resolve();
      } catch (error) {
        resolve();
      }
      
    })
   
  }

  onSubmit(valid){
    this.submitted=true;
   
    if(valid){
      this.formVerificationModal.spinnerShow();
      this.modal.emailOrUserName = this.verificationFormBuilder.get('emailOrUserName').value;
      this.modal.password = this.verificationFormBuilder.get('password').value;
      this.modal.comments = this.verificationFormBuilder.get('comments').value;
      this.modal.signature = this.verificationFormBuilder.get('signature').value;
       this.config.HTTPPostAPI(this.modal,'dynamicForm/verifyFromWithSignature').subscribe(resp=>{
        this.formVerificationModal.spinnerHide();
         if(resp){
           this.errorMessage=resp.message;
           if(resp.result=='success'){
             if(resp.message==''){
              this.closeMyModal().then(()=>{
                swal({
                  title: '',
                  text: 'Verification Done Successfully',
                  type: 'success',
                  timer: this.config.helper.swalTimer,
                  showConfirmButton: false
                });
              })
              
             }
           }
         }
       },err=> this.formVerificationModal.spinnerHide());
    }

  }


  signatureComplete(){
    this.verificationFormBuilder.get('signature').setValue(this.signaturePad.toDataURL());
  }
  clearSignature(){
    this.verificationFormBuilder.get('signature').setValue('');
    this.signaturePad.clear();
  }
}
