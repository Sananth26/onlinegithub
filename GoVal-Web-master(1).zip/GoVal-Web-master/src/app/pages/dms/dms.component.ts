import { Component, OnInit, TemplateRef, ViewChild,ViewEncapsulation } from '@angular/core';
import { NgbModal, NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { AdminComponent } from '../../layout/admin/admin.component';
import { Helper } from '../../shared/helper';
import { CommonFileFTPService } from '../common-file-ftp.service';
import { DocStatusService } from '../document-status/document-status.service';
import { DMSService } from './dms.service';
import swal from 'sweetalert2';
import { DatePipe } from '@angular/common';
import { DmsExcelExportDto } from '../../models/model';
@Component({
  selector: 'app-dms',
  templateUrl: './dms.component.html',
  styleUrls: ['./dms.component.css','../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None,
  styles:[
    `:host >>> .md-tabs >>> .nav-item {
      background-color: #fff;
      width: calc(100% / 7);
      text-align: center;
    }
    `],
})
export class DmsComponent implements OnInit {
  modalSpinner:boolean=false;
  nodes:any;
  public vendorDocuments: any;
  pdfSrc: Uint8Array;
  zoom: any = 1;
  originalSize: boolean = true;
  showAll: boolean = true;
  pdfPage: any;
  totalNumberOfPdfPages: any;
  statusLog:any;
  infoData:any;
  infoForms:any;
  isNodesThere:boolean=false;
  ftpFolderSize:any;
  ftpFileSize:any;
  @ViewChild('pdfaddEventmodal') pdfaddEventmodal: TemplateRef<any>;
  @ViewChild('modalOverflow') infoCard: any;
  spinnerFlag:boolean=false;

  ftpFilePaths: Array<String> = new Array();
  ftpFileNames: Array<String> = new Array();
  documentTypes:Array<String> = new Array();
  documentIds:Array<number> = new Array();
  dmsExcelmodal:DmsExcelExportDto = new DmsExcelExportDto();
  selectedDocument:string="";
  enableCsv:boolean = false;
  constructor(public datePipe: DatePipe,private commonService:CommonFileFTPService,private ngmodal: NgbModal,private comp: AdminComponent,public dMSService:DMSService,public helper:Helper,public docStatusService:DocStatusService) {
   
   }

  ngOnInit() {
    this.loadDmsFolderStructure();
    this.comp.setUpModuleForHelpContent("136");
    this.loadApplicationFileSize();
  }
  
  tabChange($event: NgbTabChangeEvent){
   
  }
  loadDmsFolderStructure(){
    this.spinnerFlag = true;
    this.dMSService.loadDocuments().subscribe(res => {
      this.nodes = res.list;
      if (this.nodes.length > 0)
        this.isNodesThere = true;
      this.spinnerFlag = false;
        
    },err=>this.spinnerFlag = false);
    
  }
loadApplicationFileSize(){
  this.dMSService.applicationFileSize("data").subscribe(data =>{
if(data !='' && data != null){
this.ftpFolderSize = data.ftpSize;
this.spinnerFlag = false;
}
  });
}
  fetchFileFromFtp(data){
    this.spinnerFlag = true;
    if(!this.helper.isEmpty(data.filePath)){
      this.dMSService.loadDMSFileFromFTP(data.name,data.filePath,data.documentType).subscribe(resp =>{
        this.spinnerFlag = false;
        this.comp.previewByBlob(data.name,resp,true);
      },er=>this.spinnerFlag = false);
    }
  }
  addPdfEvent(){
    this.ngmodal.open(this.pdfaddEventmodal, { size: 'lg' });
  }
  zoomInPDF(i:any) {
    this.originalSize = true;
    if (i < 1.30) {
    this.zoom = i + 0.05;
    }
  }
  zoomOutPDF(i:any) {
    this.originalSize = true;
    if (i != 1) {
      this.zoom = i - 0.05;
    }
  }
  callBackFn(event:any) {
    this.totalNumberOfPdfPages = event.pdfInfo.numPages;
  }
  gotoPage(page:any) {
    this.pdfPage=1;
    let presentPage = this.pdfPage;
    if (page <= this.totalNumberOfPdfPages) {
      this.showAll = false;
      this.pdfPage = page;
    } else {
      this.pdfPage = presentPage;
    }
  }
  onChangePdf(document:any){
    this.pdfSrc=this.convertBase64DataToBinary(document.fileContent);
  }
  convertBase64DataToBinary(base64:any) {
    var raw = window.atob(base64);
    var rawLength = raw.length;
    var array = new Uint8Array(new ArrayBuffer(rawLength));
    for(let i = 0; i < rawLength; i++) {
      array[i] = raw.charCodeAt(i);
    }
    return array;
  }
  onEvent($event){
  }
  loadDocumentCommentLog(row:any){
    this.infoForms = "";
    this.infoData = "";
    this.spinnerFlag=true;
      this.dMSService.loadDocumentCommentLog(row).subscribe(result=>{
        if(result.list!=null){
          this.statusLog=result.list;
        }
        this.infoData = result.data;
        this.infoForms = result.forms;
        this.ftpFileSize = result.fileSize;
          this.spinnerFlag=false;
          this.infoCard.show();
      });
   }

   onCickForMergePdf(event:any,data:any){
     if(event.srcElement.checked){
       this.ftpFilePaths.push(data.filePath);
       this.dmsExcelmodal.selectedFileName.push(data.name);
       this.documentTypes.push(data.documentType);
       this.selectedDocument = data.documentType;
       this.checkCustomeSettings(data.documentType,data.id);
       
    }else{
      this.ftpFilePaths = this.ftpFilePaths.filter(f => f!=data.filePath);
      this.dmsExcelmodal.selectedFileName = this.dmsExcelmodal.selectedFileName.filter(f => f!=data.name);
      this.documentTypes = this.documentTypes.filter(d => d!= data.documentType);
      this.selectedDocument = data.documentType;
      this.checkCustomeSettings("",data.id);
    }
   
   }
  checkCustomeSettings(documentType:string,docId:number){
    this.spinnerFlag = true;
    if(documentType != ''){
      let data = {"docType":documentType,"pdfDocSettingsId":docId}
     this.dMSService.checkCsvSettings(data).subscribe(result=>{
      this.spinnerFlag = false;
             this.enableCsv = result.value;
             this.dmsExcelmodal.mappingId = result.mappingId;
             if(this.enableCsv === true){
              this.dmsExcelmodal.projectDocPdfIds.push(docId);
             }
     });
    }else{
      let index:number = this.dmsExcelmodal.projectDocPdfIds.indexOf(docId);
      if(index !== -1){
        this.dmsExcelmodal.projectDocPdfIds.splice(index,1);
      }
      if(this.dmsExcelmodal.projectDocPdfIds.length == 0){
        this.enableCsv = false;
        }
        this.spinnerFlag = false;
    }
  }
  /**
 * Method for CSV Export
 */
downloadExcel() {
  this.dmsExcelmodal.docType = this.selectedDocument;
  this.spinnerFlag = true;
  this.dMSService.excelExport(this.dmsExcelmodal).subscribe(resp => {
    this.spinnerFlag = false;
    if (resp.result) {
      var nameOfFileToDownload = resp.sheetName + ".xls";
      this.comp.previewOrDownloadByBase64(nameOfFileToDownload, resp.sheet, false);
    }else{
      this.spinnerFlag = false;
      swal({
        title: '400',
        text: 'Oops, something went wrong ,try again..',
        type: 'error',
        timer: this.helper.swalTimer,
        showConfirmButton: false
      })
    }
  },(err)=>{
      this.spinnerFlag = false;
      swal({
        title: '400',
        text: 'Oops, something went wrong ,try again..',
        type: 'error',
        timer: this.helper.swalTimer,
        showConfirmButton: false
      })
  });
}
   mergePfs(){
     if(this.ftpFilePaths.length != 0){
     this.spinnerFlag = true;
     this.dMSService.downloadMergePdf(this.ftpFilePaths).subscribe(res =>{
       this.spinnerFlag = false;
       if(res != null)
          this.comp.previewByBlob("dms-merge-pdfs.pdf",res,false);
       else{
        swal({
          title: 'Files not merged properly',
          text: 'Oops, something went wrong ,files not merged properly, please try again..',
          type: 'error',
          timer: this.helper.swalTimer,
          showConfirmButton: false
        })
       }
     }, (err) =>{
      this.spinnerFlag = false;
      swal({
        title: '400',
        text: 'Oops, something went wrong ,try again..',
        type: 'error',
        timer: this.helper.swalTimer,
        showConfirmButton: false
      })
     });
    }else{
      swal({
        title: 'warning',
        text: 'Please select at least one file',
        type: 'warning',
        timer: this.helper.swalTimer,
        showConfirmButton: false
      })
    }
   }
}
