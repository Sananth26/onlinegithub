import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { EquipmentService } from '../equipment/equipment.service';
import { Facility } from './../../models/model';
import swal from 'sweetalert2';
import { Helper } from './../../shared/helper';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LocationService } from '../location/location.service';
import { FacilityService } from './facility.service';
import { IOption } from 'ng-select';
import { Permissions } from './../../shared/config';
import { AdminComponent } from '../../layout/admin/admin.component';
import { ConfigService } from '../../shared/config.service';
import { facilityErrorTypes } from '../../shared/constants';
@Component({
  selector: 'app-facility',
  templateUrl: './facility.component.html',
  styleUrls: ['./facility.component.css', './../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class FacilityComponent implements OnInit {


  @ViewChild('myTable') table: any;
  public onFacilityForm: FormGroup;
  data: any;
  modal: Facility = new Facility();
  public rowsOnPage = 10;
  public filterQuery = '';
  spinnerFlag = false;
  iscreate: boolean = false;
  isUpdate: boolean = false;
  isSave: boolean = false;
  locationList: any;
  equipmentList: Array<IOption> = new Array<IOption>();
  permissionsfromlocalstorage: any;
  permissionModal: Permissions = new Permissions('142', false);
  isValidName: boolean = false;
  equipmentFlag: boolean = false;
  locationFlag: boolean = false;
  nameFlag: boolean = false;
  constructor(public permissionService: ConfigService, private comp: AdminComponent, public fb: FormBuilder, public service: FacilityService,
     public equipmentService: EquipmentService, public helper: Helper, public locationService: LocationService,public facilityErrorTypes:facilityErrorTypes) { }

  ngOnInit() {
    this.comp.setUpModuleForHelpContent("142");
    this.comp.taskDocType = "142";
    this.comp.taskDocTypeUniqueId = "";
    this.comp.taskEquipmentId  = 0;
    
    this.loadAll();
    this.loadAllActiveLocations();
    this.loadAllEquipments();
    this.onFacilityForm = this.fb.group({
      name: ['', Validators.compose([
        Validators.required
      ])],
      locationId: ['', Validators.compose([
        Validators.required
      ])],
      equipmentId: ['', Validators.compose([
        Validators.required
      ])],
      active: ['', Validators.compose([
        Validators.required
      ])],
    });
    this.permissionService.loadPermissionsBasedOnModule("142").subscribe(resp => {
      this.permissionModal = resp
    });
  }

  loadAllActiveLocations() {
    this.spinnerFlag = true;
    this.locationService.loadAllActiveLocations().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.locationList = response.result
      }
    }, error => { this.spinnerFlag = false });
  }

  loadAllEquipments() {
    this.spinnerFlag = true;
    this.equipmentService.loadEquipmentsByuser().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.equipmentList = response.result.map(option => ({ value: option.id, label: option.name }))
      }
    }, error => { this.spinnerFlag = false });
  }

  onClickCreate() {
    this.isSave = true;
    this.iscreate = true;
    this.isUpdate = false;
    this.onFacilityForm.reset();
    this.modal.id = 0;
    this.onFacilityForm.get("active").setValue(true);
  }

  onChangeName() {
    this.isValidName = false;
    this.nameFlag = false;
    this.data.forEach(element => {
      if (element.name === this.onFacilityForm.get("name").value && this.modal.id != element.id)
        this.isValidName = true;
    });
  }
  onClickCancel() {
    this.iscreate = false;
  }

  loadAll() {
    this.spinnerFlag = true;
    this.service.loadFacility().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.data = response.result
      }
    }, error => { this.spinnerFlag = false });
  }

  editLocation(data: Facility) {
    this.iscreate = true;
    this.isSave = false;
    this.isUpdate = true;
    this.modal = data;
    this.onFacilityForm.get("active").setValue(data.active==='Y'?true:false);
    this.onFacilityForm.get("name").setValue(data.name);
    this.onFacilityForm.get("locationId").setValue(data.locationId);
    this.onFacilityForm.get("equipmentId").setValue(data.equipmentId);
  }

  openSuccessCancelSwal(dataObj, id) {
    var classObject = this;
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      classObject.deleteLocation(dataObj);
    });
  }

  deleteLocation(dataObj): string {
    let timerInterval;
    let status = '';
    let facility = new Facility();
    facility.id = dataObj.id;
    this.service.deleteFacility(facility)
      .subscribe((response) => {
        let responseMsg: string = response.result;
        if (responseMsg === "success") {
          swal({
            title: 'Deleted!',
            text: 'Facility ' + dataObj.name + '  has been deleted.',
            type: 'success',
            timer: this.helper.swalTimer,
            showConfirmButton: false,
            onClose: () => {
              this.loadAll();
              clearInterval(timerInterval)
            }
          });
        } else {
          status = "failure";
          swal({
            title: 'Not Deleted!',
            text: 'Facility ' + dataObj.name + '  has not been deleted.',
            type: 'error',
            timer: this.helper.swalTimer
          }
          );
        }
      }, (err) => {
        status = "failure";
        swal({
          title: 'Not Deleted!',
          text: dataObj.name + 'is not deleted...Something went wrong',
          type: 'error',
          timer: this.helper.swalTimer
        }
        );
      });
    return status;
  }
  onClickSave() {
    let timerInterval
    if (this.onFacilityForm.valid) {
      if (!this.isValidName) {
        this.equipmentFlag = false;
        this.locationFlag = false;
        this.nameFlag = false;
        this.spinnerFlag = true;
        this.modal.name = this.onFacilityForm.get("name").value;
        this.modal.locationId = this.onFacilityForm.get("locationId").value;
        this.modal.equipmentId = this.onFacilityForm.get("equipmentId").value;
        if (this.onFacilityForm.get("active").value)
          this.modal.active = "Y";
        else
          this.modal.active = "N";

        this.service.createFacility(this.modal).subscribe(jsonResp => {
          this.spinnerFlag = false;
          let responseMsg: string = jsonResp.result;
          if (responseMsg === "success") {
            this.loadAll();
            let mes = 'New Facility is created';
            if (this.isUpdate) {
              mes ="Facility is updated"
            }
            swal({
              title: '',
              text: mes,
              type: 'success',
              timer: this.helper.swalTimer,
              showConfirmButton: false,
              onClose: () => {
                this.iscreate = false;
                clearInterval(timerInterval)
              }
            });
          } else {
            swal({
              title: '',
              text: 'Something went Wrong ...Try Again',
              type: 'error',
              timer: this.helper.swalTimer
            }
            )
          }
        },
          err => {
            this.spinnerFlag = false
          }
        );
      }
    } else {
      Object.keys(this.onFacilityForm.controls).forEach(field => {
        const control = this.onFacilityForm.get(field);            
        control.markAsTouched({ onlySelf: true });      
      });
    }
  }
}
