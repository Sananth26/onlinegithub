import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgbDateStruct } from "@ng-bootstrap/ng-bootstrap";
import { NgbDateISOParserFormatter } from "@ng-bootstrap/ng-bootstrap/datepicker/ngb-date-parser-formatter";
import swal from 'sweetalert2';
import { AdminComponent } from '../../layout/admin/admin.component';
import { ConfigService } from '../../shared/config.service';
import { equipmentErrorTypes } from '../../shared/constants';
import { FormExtendedComponent } from '../form-extended/form-extended.component';
import { LocationService } from '../location/location.service';
import { MasterControlService } from '../master-control/master-control.service';
import { CheckListEquipmentDTO, Equipment } from './../../models/model';
import { Permissions } from './../../shared/config';
import { Helper } from './../../shared/helper';
import { EquipmentService } from './equipment.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DateFormatSettingsService } from '../date-format-settings/date-format-settings.service';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-equipment',
  templateUrl: './equipment.component.html',
  styleUrls: ['./equipment.component.css', './../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None,
  host: {
    '(document:click)': 'onClick($event)',
  },
})
export class EquipmentComponent implements OnInit {
  @ViewChild('formExtendedId') private formExtendedComponent: FormExtendedComponent;
  public inputField:any=[];
  submitted: boolean = false;
  @ViewChild('myTable') table: any;
  @ViewChild('a') a: any;
  @ViewChild('b') b: any;
  @ViewChild('d') d: any;
  @ViewChild('e') e: any;
  @ViewChild('f') f: any;
  @ViewChild('g') g: any;
  @ViewChild('h') h: any;
  @ViewChild('c') c: any;
  public onEquipmentForm=null;
  data: any;
  modal: Equipment = new Equipment();
  public rowsOnPage = 10;
  public filterQuery = '';
  spinnerFlag = false;
  iscreate: boolean = false;
  isUpdate: boolean = false;
  isSave: boolean = false;
  public today: NgbDateStruct;
  public validDate: NgbDateStruct;
  locationList: any;
  permissionsfromlocalstorage: any;
  permissionModal: Permissions = new Permissions('',false);
  isValidName:boolean=false;
  selecetdFile : File;
  isAddChecklist:boolean=false;
  isAddChecklistName:boolean=false;
  editing = {};
  equipmentCountFlag=true;
  isCheckListEntered:boolean=false;
  isValidDocumentOrder: boolean = false;
  viewIndividualEquipmentData: boolean = false;
  equipmentViewData: any;
  popupdata = [];
  completeTaskList:any[]=new Array();
  pendingTaskList:any[]=new Array();
  datePipeFormat='yyyy-MM-dd';
  pattern="d-m-Y";
  constructor(public permissionService:ConfigService,private comp: AdminComponent,public fb: FormBuilder, public service: EquipmentService,
     public helper: Helper,public locationService:LocationService,public _eref: ElementRef,public equipmentErrorTypes:equipmentErrorTypes,
     public masterControlService:MasterControlService,public router: Router,private route: ActivatedRoute,private servie: DateFormatSettingsService,private datePipe: DatePipe) { }


  ngOnInit() {
    this.loadOrgDateFormat();
    this.loadOrgDateFormatAndTime();
    this.canCreateEquipment();
    this.modal.selectedFile = "";
    this.comp.setUpModuleForHelpContent("141");
    this.comp.taskDocType = "141";
    this.comp.taskDocTypeUniqueId = "";
    this.comp.taskEnbleFlag = true;
    this.comp.taskEquipmentId = 0;
    this.route.queryParams.subscribe(rep => {
      if (rep.id != undefined) {
        this.viewRowDetails(rep.id);
      }
    });
    let now = new Date();
    let tempData = new NgbDateISOParserFormatter;
    this.today = tempData.parse(now.toISOString());
    this.loadAll();
    this.loadAllActiveLocations();
    this.onEquipmentForm =this.fb.group({
      code:  ['', Validators.required],
      name: ['', Validators.required],
      dateOfPurchase:new FormControl( []),
      manufacturer:new FormControl( []),
      soldBy: new FormControl( []),
      model :new FormControl( []),
      totalCapacity: new FormControl( []),
      usageCapacity: new FormControl( []),
      locationId:new FormControl( []),
      IQCompletionDate: new FormControl( []),
      OQCompletionDate:new FormControl( []),
      checklistName:new FormControl( []),
      sequence:new FormControl( []),
      active: new FormControl( []),
    });
    this.permissionService.loadPermissionsBasedOnModule("141").subscribe(resp=>{
      this.permissionModal=resp
    }); 
  }
  canCreateEquipment(){
    this.service.canCreateEquipment().subscribe(res=>{
      this.equipmentCountFlag=res;
    });
  }
  loadAllActiveLocations() {
    this.spinnerFlag = true;
    this.locationService.loadAllActiveLocations().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.locationList = response.result
      }
    }, error => { this.spinnerFlag = false });
  }
  toggleExpandRow(row) {
    this.table.rowDetail.toggleExpandRow(row);
  }
  onSelectFile(event){
    this.selecetdFile = event.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
    this.modal.selectedFile = reader.result;
    this.modal.selectedFileName = event.target.files[0].name;
    };
    reader.readAsDataURL(this.selecetdFile);
    }
  onClickCreate() {
    this.isSave = true;
    this.iscreate = true;
    this.isUpdate= false;
    this.onEquipmentForm.reset();
    this.modal.id = 0;
    this.modal.checklist=[];
    this.onEquipmentForm.get("active").setValue(true);
    this.onEquipmentForm.get("locationId").setValue("");
    this.modal.selectedFile = "";
    this.laodJsonStrucutre();
  }

  addChecklistItem(){
    this.isCheckListEntered=false;
    this.modal.checklist.forEach(checkList =>{
      if(this.helper.isEmpty(checkList.checklistName) ||this.helper.isEmpty(checkList.displayOrder))
      this.isCheckListEntered=true;
    });
    if(!this.isCheckListEntered){
      let data=new CheckListEquipmentDTO();
      data.id=0;
      data.checklistName="";
      data.displayOrder=this.modal.checklist.length+1;
      this.modal.checklist.push(data);
    }
  }

  deleteCheckList(data){
    this.modal.checklist = this.modal.checklist.filter(event => event !== data);
  }
  editRow(rowIndex) {
    for (let index = 0; index <this.modal.checklist.length; index++) {
      if (rowIndex == index)
        this.editing[index] = true;
      else
        this.editing[index] = false;
    }
  }
  onClickCancel() {
    this.iscreate = false;
    this.ngOnInit();
  }

  loadAll() {
    this.spinnerFlag = true;
    this.service.loadEquipment().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.data = response.result;
      }
    }, error => { this.spinnerFlag = false });
  }
  onChangeName(){
    this.isValidName=false;
    this.data.forEach(element => {
      if(element.name === this.onEquipmentForm.get("name").value && this.modal.id !=element.id )
        this.isValidName=true;
    });
  }
  editEquipmet(data: Equipment) {
    this.iscreate = true;
    this.isSave = false;
    this.isUpdate = true;
    this.modal = data;
    if(this.modal.jsonExtraData!=null&&this.modal.jsonExtraData!='[]'){
      this.inputField=JSON.parse(this.modal.jsonExtraData);
    }else{
      this.laodJsonStrucutre();
    }
    this.onEquipmentForm.reset();
    this.onEquipmentForm.get("active").setValue(data.active==='Y'?true:false);
    this.onEquipmentForm.get("sequence").setValue(data.selectedFile);
    this.onEquipmentForm.get("code").setValue(data.code);
    this.onEquipmentForm.get("name").setValue(data.name);
    this.onEquipmentForm.get("locationId").setValue(data.locationId);
    this.onEquipmentForm.get("manufacturer").setValue(data.manufacturer);
    this.onEquipmentForm.get("soldBy").setValue(data.soldBy);
    this.onEquipmentForm.get("model").setValue(data.model);
    this.onEquipmentForm.get("totalCapacity").setValue(data.totalCapacity);
    this.onEquipmentForm.get("usageCapacity").setValue(data.usageCapacity);
    if(!this.helper.isEmpty(data.dateOfPurchase))this.onEquipmentForm.get("dateOfPurchase").setValue(data.dateOfPurchase);
    if(!this.helper.isEmpty(data.iqCompletionDate))this.onEquipmentForm.get("IQCompletionDate").setValue(data.iqCompletionDate);
    if(!this.helper.isEmpty(data.oqCompletionDate))this.onEquipmentForm.get("OQCompletionDate").setValue(data.oqCompletionDate);
    this.isAddChecklist=true;
  }
populateDate(date: any):any{
  let result;
  if(!this.helper.isEmpty(date)){
    let tempData = new NgbDateISOParserFormatter;
    let dateString = date.split("-");
    let validDate = new Date();
    validDate.setDate(dateString[2]);
    validDate.setMonth(dateString[1] - 1);
    validDate.setFullYear(dateString[0]);
    result= tempData.parse(validDate.toISOString());
  }else{
    result="";
  }
  return result;
}
  openSuccessCancelSwal(dataObj, id) {
    var classObject = this;
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      classObject.deleteLocation(dataObj);
    });
  }

  deleteLocation(dataObj): string {
   let timerInterval;
    let status = '';
    let equipment = new Equipment();
    equipment.id = dataObj.id;
    this.service.deleteEquipment(equipment)
      .subscribe((response) => {
        let responseMsg: string = response.result;
        if (responseMsg === "success") {
          swal({
            title:'Deleted!',
            text:'Equipment ' + dataObj.name + '  has been deleted.',
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              this.loadAll();
              clearInterval(timerInterval)
            }
          });
        } else {
          status = "failure";
          swal({
            title:'Not Deleted!',
            text:'Equipment ' + dataObj.code + '  has not been deleted.',
            type:'error',
            timer:this.helper.swalTimer,
            showConfirmButton:false
          }
          );
        }
      }, (err) => {
        status = "failure";
        swal({
          title:'Not Deleted!',
          text:dataObj.name + 'is not deleted...Something went wrong',
          type:'error',
          timer:this.helper.swalTimer,
          showConfirmButton:false
        });
      });
    return status;
  }
  onClickSave(onEquipmentForm) {
    this.submitted=false;
    let timerInterval;
    this.isCheckListEntered=false;
    this.isValidDocumentOrder=false;
    this.modal.checklist.forEach(checkList =>{
      if(this.helper.isEmpty(checkList.checklistName) ||this.helper.isEmpty(checkList.displayOrder))
        this.isCheckListEntered=true;
    });
    let valueArr = this.modal.checklist.map(function (item) { return String(item.displayOrder) });
    this.isValidDocumentOrder = valueArr.some(function (item, idx) {
      return valueArr.indexOf(item) != idx
    });
    if(onEquipmentForm.valid &&this.formExtendedComponent.validateChildForm()){
    if(!this.isValidName && !this.isCheckListEntered && !this.isValidDocumentOrder){
      this.spinnerFlag = true;
      this.modal.code = this.onEquipmentForm.get("code").value;
      this.modal.name=this.onEquipmentForm.get("name").value;
      this.modal.locationId=this.onEquipmentForm.get("locationId").value;
      this.modal.manufacturer=this.onEquipmentForm.get("manufacturer").value;
      this.modal.soldBy=this.onEquipmentForm.get("soldBy").value;
      this.modal.model=this.onEquipmentForm.get("model").value;
      this.modal.totalCapacity=this.onEquipmentForm.get("totalCapacity").value;
      this.modal.usageCapacity=this.onEquipmentForm.get("usageCapacity").value;
      this.modal.jsonExtraData=JSON.stringify(this.inputField);
      if(this.onEquipmentForm.get("active").value)
        this.modal.active="Y";
      else
        this.modal.active="N";

      if(this.onEquipmentForm.get("sequence").value)
          this.modal.sequence = "Y";
      else
          this.modal.sequence = "N";
          if(!this.helper.isEmpty(this.onEquipmentForm.get("dateOfPurchase").value))
      this.modal.dateOfPurchase = this.datePipe.transform(new Date(this.onEquipmentForm.get("dateOfPurchase").value), 'yyyy-MM-dd hh:mm:ss');
     else 
     this.modal.dateOfPurchase =null;
     if(!this.helper.isEmpty(this.onEquipmentForm.get("IQCompletionDate").value))
      this.modal.iqCompletionDate = this.datePipe.transform(new Date(this.onEquipmentForm.get("IQCompletionDate").value), 'yyyy-MM-dd hh:mm:ss');
     else
     this.modal.iqCompletionDate =null;
     if(!this.helper.isEmpty(this.onEquipmentForm.get("OQCompletionDate").value))
      this.modal.oqCompletionDate = this.datePipe.transform(new Date(this.onEquipmentForm.get("OQCompletionDate").value), 'yyyy-MM-dd hh:mm:ss');
     else
     this.modal.oqCompletionDate = null;
      this.service.createEquipment(this.modal).subscribe(jsonResp => {
        this.spinnerFlag = false;
        let responseMsg: string = jsonResp.result;
        if (responseMsg === "success") {
          this.loadAll();
          this.canCreateEquipment();
          let mes = 'New Equipment is created';
          if (this.isUpdate) {
            mes = "Equipment is updated"
          }
          swal({
            title:'',
            text:mes,
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              this.iscreate = false;
              clearInterval(timerInterval)
            }
          });
        } else {
          swal({
           title: '',
            text:'Something went Wrong ...Try Again',
            type:'error',
            timer:this.helper.swalTimer,
            showConfirmButton:false
          })
        }
      },
        err => {
          this.spinnerFlag = false
        }
      );
    }
  }else{
    this.submitted=true;
      Object.keys(this.onEquipmentForm.controls).forEach(field => {
        const control = this.onEquipmentForm.get(field);            
        control.markAsTouched({ onlySelf: true });      
      });
    }
  }

  openDatepicker(id) {
   id.toggle()
  }

  onClick(event) {
    // let path = event.path;
    // let a = false, b = false, c = false, d = false, e = false, f = false, g = false, h = false;
    // for (var index = 0; index < path.length; index++) {
    //   if(this.a)
    //   if (path[index].id == this.a._elRef.nativeElement.name) {
    //     a = true;
    //     break;
    //   }
    //   if(this.b)
    //   if (path[index].id == this.b._elRef.nativeElement.name) {
    //     b = true;
    //     break;
    //   }
    //   if(this.c)
    //   if (path[index].id == this.c._elRef.nativeElement.name) {
    //     c = true;
    //     break;
    //   }
    //   if(this.d)
    //   if (path[index].id == this.d._elRef.nativeElement.name) {
    //     d = true;
    //     break;
    //   }
    //   if(this.e)
    //   if (path[index].id == this.e._elRef.nativeElement.name) {
    //     e = true;
    //     break;
    //   }
    //   if(this.f)
    //   if (path[index].id == this.f._elRef.nativeElement.name) {
    //     f = true;
    //     break;
    //   }
    //   if(this.g)
    //   if (path[index].id == this.g._elRef.nativeElement.name) {
    //     g = true;
    //     break;
    //   }
    //   if(this.h)
    //   if (path[index].id == this.h._elRef.nativeElement.name) {
    //     h = true;
    //     break;
    //   }
    // }
    // if (!a) { this.a.close(); }
    // if (!b) { this.b.close(); }
    // if (!c) { this.c.close(); }
    // if (!d) { this.d.close(); }
    // if (!e) { this.e.close(); }
    // if (!f) { this.f.close(); }
    // if (!g) { this.g.close(); }
    // if (!h) { this.h.close(); }

  }

  laodJsonStrucutre(){
    this.masterControlService.loadJsonOfDocumentIfActive(this.helper.EQUIPMENT_VALUE).subscribe(res=>{
      if(res!=null)
        this.inputField=JSON.parse(res.jsonStructure);
      });
  }
  viewRowDetails(row) {
    this.comp.taskEquipmentId = row;
    this.service.editEquipment(row).subscribe(response=>{
      if(response.result){
        this.equipmentViewData=response.result;
        this.popupdata = [];
        this.equipmentViewData.formData = JSON.parse(this.equipmentViewData.jsonExtraData);
        this.popupdata.push(this.equipmentViewData);
        this.service.loadEquipmentTasks(row).subscribe(res=>{
          if(res.completeList &&res.pendingList){
            this.completeTaskList=res.completeList;
            this.pendingTaskList=res.pendingList;
          }
          });
          this.viewIndividualEquipmentData = true;
      }
      });
  }
  redirect(row){
    this.router.navigate(["taskCreation"], { queryParams: { id: row.id,equipmentId:this.equipmentViewData.id, url: '/equipment'} })
  }

  loadOrgDateFormatAndTime() {
    this.servie.getOrgDateFormat().subscribe(result => {
        if (!this.helper.isEmpty(result)) {
          this.datePipeFormat=result.datePattern.replace("mm", "MM")
          this.datePipeFormat=this.datePipeFormat.replace("YYYY", "yyyy");
        }
    });
}

loadOrgDateFormat() {
  this.servie.getOrgDateFormatForDatePicker().subscribe(result => {
      if (!this.helper.isEmpty(result)) {
          this.pattern = result.replace("y","Y");
      }
  });
}
}
