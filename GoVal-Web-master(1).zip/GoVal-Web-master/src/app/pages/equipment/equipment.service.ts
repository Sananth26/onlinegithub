import { Injectable } from '@angular/core';
import { Headers, Http, Response, RequestOptions,ResponseContentType } from '@angular/http';
import { Observable } from "rxjs/Observable";
import { Helper } from '../../shared/helper';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { ConfigService } from '../../shared/config.service';
@Injectable()
export class EquipmentService {
  constructor(private http: Http, public helper: Helper, public config: ConfigService) { }
  url_save: string = this.helper.common_URL + 'equipment/saveEquipment';
  url_load: string = this.helper.common_URL + 'equipment/loadAllEquipments';
  url_loadActiveEquipments = this.helper.common_URL + 'equipment/loadAllActiveEquipments';
  url_delete: string = this.helper.common_URL + 'equipment/deleteEquipmentById';
  url_edit: string = this.helper.common_URL + 'equipment/loadEquipmentById';
  url_load_equipments_by_user: string = this.helper.common_URL + 'equipment/loadEquipmentsByUser';
  url_form_limit : string = this.helper.common_URL + 'equipment/canCreateEquipmentForOrganization'; 
  url_equipment_tasks : string = this.helper.common_URL + 'projectTask/loadTasksForEquipment'; 
  
  createEquipment(data: any) {
    return this.http.post(this.url_save, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  loadEquipment() {
    return this.http.post(this.url_load,"", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  loadAllActiveEquipment() {
    return this.http.post(this.url_loadActiveEquipments,"", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  deleteEquipment(data: any) {
    return this.http.post(this.url_delete, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }

  editEquipment(data: any) {
    return this.http.post(this.url_edit, data, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  loadEquipmentsByuser() {
    return this.http.post(this.url_load_equipments_by_user,"", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  canCreateEquipment() {
    return this.http.post(this.url_form_limit,"", this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
  loadEquipmentTasks(equipmentId:any) {
    return this.http.post(this.url_equipment_tasks,equipmentId, this.config.getRequestOptionArgs())
      .map((resp) => resp.json())
      .catch(res => {
        return Observable.throw(res.json());
      });
  }
}