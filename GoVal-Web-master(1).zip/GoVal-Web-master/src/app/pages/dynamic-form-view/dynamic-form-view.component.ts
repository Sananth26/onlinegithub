import { DatePipe } from '@angular/common';
import { AfterViewInit, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IOption } from 'ng-select';
import swal from 'sweetalert2';
import { AdminComponent } from '../../layout/admin/admin.component';
import { DynamicFormDTO, UserPrincipalDTO } from '../../models/model';
import { Permissions } from '../../shared/config';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { AuditTrailViewComponent } from '../audit-trail-view/audit-trail-view.component';
import { DocumentStatusCommentLogComponent } from '../document-status-comment-log/document-status-comment-log.component';
import { DocStatusService } from '../document-status/document-status.service';
import { DynamicFormService } from '../dynamic-form/dynamic-form.service';
import { WorkFlowDynamicFormService } from '../work-flow-dynamic-form/work-flow-dynamic-form.service';
import { StepperClass, User } from './../../models/model';
import { DashBoardService } from './../dashboard/dashboard.service';
import { DynamicFormViewService } from './dynamic-form-view.service';
import { FormEsignVerificationComponent } from '../form-esign-verification/form-esign-verification.component';

@Component({
  encapsulation:ViewEncapsulation.None,
  selector: 'app-dynamic-form-view',
  templateUrl: './dynamic-form-view.component.html',
  styleUrls: ['./dynamic-form-view.component.css','./../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
})
export class DynamicFormViewComponent implements OnInit,AfterViewInit{
  formName='';
  configOfCkEditior={
    removeButtons: 'Source,Save,NewPage,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteFromWord,Undo,Redo,find,selection,spellchecker,Find,Replace,SelectAll,Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,Bold,Italic,Underline,Strike,Subscript,Superscript,CopyFormatting,RemoveFormat,list,indent,blocks,align,bidi,NumberedList,BulletedList,Outdent,Indent,Blockquote,CreateDiv,JustifyLeft,JustifyCenter,JustifyRight,JustifyBlock,BidiLtr,BidiRtl,Language,Link,Unlink,Anchor,Image,Flash,Table,HorizontalRule,Smiley,SpecialChar,PageBreak,Iframe,Styles,Format,Font,FontSize,TextColor,BGColor,ShowBlocks,About',
    readOnly:true
  }
  constructor(public dashboardService: DashBoardService
    , public helper: Helper, public permissionService: ConfigService,
    public workFlowDynamicFormService: WorkFlowDynamicFormService, public router: Router,
    public adminComponent: AdminComponent, private activeRouter: ActivatedRoute,
    private service: DynamicFormViewService, public docStatusService: DocStatusService,
    public dynamicService: DynamicFormService) {
  }
  @ViewChild('auditTrailFormGroup') auditTrail;
  @ViewChild('formTab') public tab:any;
  @ViewChild('documentcomments') documentcomments:DocumentStatusCommentLogComponent;
  @ViewChild('formDataListTab') tabSet:any;
  @ViewChild('formVerification') formVerification:FormEsignVerificationComponent;
  pdfView=false;
  pdfURL:string;
  pdfName:string;
  equipmentFlag=false;
  modalSpinner = false;
  permissionModel: Permissions = new Permissions("",false);
  permissionMap:Object=new Map<string,Permissions>();
  publishButtonFlag=false;
  createButtonFlag=false;
  public constants:any;
  public individualconstants :any;
  public individualId :any;
  public mappingId:any = 0;
  public masterDynamicFormId;
  public spinnerFlag = false;
  public rowsOnPage = 10;
  public sortBy = '';
  public sortOrder = 'desc';
  public filterQuery = '';
  public data: any[]=new Array();
  publishedData: any=new Array();
  dynamicForm=new DynamicFormDTO();
  viewIndividualData: boolean = false;
  public currentDocType:any;
  public currentDocStatus:any;
  public currentCreatedBy:any;
  public currentModifiedDate:any;
  commonDocumentStatusValue:any;
  public esignForm:any;
  popupdata = []=new Array<DynamicFormDTO>();
  statusLog:any=new Array();
  routeback:any;
  public list;
  public docSignselectList: Array<IOption> = new Array<IOption>();
  public modal: User = new User();
  public subscription;
  public currentId = null;
  isSelectedPublishData: boolean = false;
  selectAll:boolean=false;
  isMapping: boolean = false;
  tempDynamicForm=new DynamicFormDTO();
  currentUser:UserPrincipalDTO=new  UserPrincipalDTO();
  public globalPublishFlag;
  @ViewChild('auditView') auditView: AuditTrailViewComponent;
  nextId = 0;
  isWorkflowDocumentOrderSequence:boolean=false;

  ngOnInit() {
    
    this.permissionService.loadCurrentUserDetails().subscribe(res=>{
      this.currentUser=res;
      this.spinnerFlag = true;
      this.activeRouter.queryParams.subscribe(query => {
        if (query.status !== undefined) {
          this.routeback = query.id;
          this.isMapping=query.isMapping=="true"?true:false;
          const dto=new DynamicFormDTO();
          dto.id=query.id;
          dto.formMappingId=query.id;
          this.masterDynamicFormId = query.id;
          dto.isMapping=this.isMapping;
          dto.dynamicFormCode=query.documentCode;
          this.viewRowDetails(dto, query.status);
          this.helper.changeMessageforId(query.id);
        } else {
          this.masterDynamicFormId = query.id;
          this.loadData(this.masterDynamicFormId, query.isMapping);
        }
      });
      this.helper.listen().subscribe((m: any) => {
        
        this.dynamicService.getMinimalInfoBasedOnId(m).subscribe(resp=>{
          this.isMapping=resp.mapping;
          if(resp.mapping){
            this.masterDynamicFormId=resp.formMappingId;
          }else{
            this.masterDynamicFormId=resp.masterDynamicFormId;
          }
          this.viewRowDetails(resp, '/documentapprovalstatus' );
        });
      //
      });
    });

  }

  ngAfterViewInit(): void {
    this.spinnerFlag=true;
    setTimeout(()=>{
      if(localStorage.getItem('formTab')){
       if(this.tab)
       this.tab.activeId=this.helper.decode(localStorage.getItem('formTab'));
      }
      this.spinnerFlag=false;
    },600)


  }
  loadData(masterId,isMapping?){
    this.adminComponent.taskDocTypeUniqueId = "";
    this.adminComponent.taskEquipmentId = 0;
    this.selectAll = false;
    if(isMapping)
    this.isMapping=isMapping=="true"?true:false;
    this.viewIndividualData = false;
    
    this.service.loadAllDataForProject({ "masterDynamicFormId":masterId, "versionId": this.currentUser.versionId,isMapping:isMapping }).subscribe(response => {
      if (response != null) {
        this.formName=response.name;
        this.equipmentFlag=response.equipmentFlag;
        this.data=response.unpublishedList;
        this.publishedData=response.publishedList;
        this.permissionMap=response.permissionMap;

        this.permissionService.isWorkflowDocumentOrderSequence(response.isMapping == 'true' ? response.unique : response.constant).subscribe(resp => {
          this.isWorkflowDocumentOrderSequence = resp;
        });
        debugger
        Object.keys(this.permissionMap).forEach((key:string)=>{
          if(!this.createButtonFlag){
            this.createButtonFlag=this.permissionMap[key].createButtonFlag;
          }
          if(!this.publishButtonFlag){
            this.publishButtonFlag=this.permissionMap[key].publishButtonFlag;
          }
        })
     
        this.adminComponent.setUpModuleForHelpContent(response.constant);
        this.adminComponent.taskEnbleFlag = true;
        if(response.groupId != ""){
          this.adminComponent.taskDocType = response.unique;
        }else{
          this.adminComponent.taskDocType = response.constant;}
          this.adminComponent.checkTheTaskData();
        this.constants = response.constant;
        if(response.isMapping){
          this.mappingId = response.groupId;
        }
          
        if(localStorage.getItem('formTab')){
          if(this.helper.decode(localStorage.getItem('formTab'))==='audit')
            this.auditView.loadData(response.constant,response.groupId);
         }
        
      }
      this.ngAfterViewInit();
    });
  }

  navigate(exists, data?: any) {
    const queryParams = {
      exists: exists,
      id: this.masterDynamicFormId,
      isMapping: this.isMapping,
      redirectUrl: 'dynamicFormView/' + this.masterDynamicFormId + '?' + exists + '?' + this.isMapping,
      versionId: this.currentUser.versionId,
      projectId:this.currentUser.projectId
    };
    if (data !== undefined) {
      if (this.isMapping) {
        queryParams.id = data.formMappingId;
        queryParams['documentCode'] = data.dynamicFormCode;
        queryParams.redirectUrl = 'dynamicFormView/' + data.formMappingId + '?' + queryParams.exists + '?' + queryParams.isMapping;
      } else {
        queryParams.id = data.id;
      }
    }

    this.router.navigate(['/dynamicForm/' + this.masterDynamicFormId], { queryParams: queryParams, skipLocationChange: true });
  }
  loadDocumentCommentLog(row) {
      row.createdBy=row.createdByName;
      row.constantName = row.permissionConstant;
      row.templateName=this.formName;
      this.documentcomments.loadDocumentCommentLog(row);
  }

  viewRowDetails(row: any, status) {
    this.pdfView=false;
    this.adminComponent.taskDocTypeUniqueId = row.id; // To Populate the Task Popu data
    this.adminComponent.taskEquipmentId = row.equipmentId // To Populate the equipment daat in task
    this.tabChange('draft') ///need to change in time of performance
    this.commonDocumentStatusValue = status;
    this.popupdata = [];
    const queryParams = {
      exists: true,
      id: this.masterDynamicFormId,
      isMapping: this.isMapping,
      versionId: this.currentUser.versionId,
      projectId: this.currentUser.projectId
    };
    if (this.isMapping) {
      queryParams.id = row.formMappingId;
      queryParams['documentCode'] = row.dynamicFormCode;
    } else {
      queryParams.id = row.id;
    }
    this.dynamicService.loadDynamicFormForProject(queryParams).subscribe(jsonResp => {
      if (jsonResp != null) {
        if (!this.isMapping) {
          jsonResp.formData = JSON.parse(jsonResp.formData);
          this.individualconstants = jsonResp.permissionConstant;
          this.individualId = jsonResp.id;

          this.stepperfunction(jsonResp.permissionConstant, jsonResp.dynamicFormCode, jsonResp.id,
            jsonResp.publishedflag, jsonResp.createdBy, jsonResp.updatedTime,
             jsonResp.displayCreatedTime, jsonResp.displayUpdatedTime, jsonResp.updatedByName, jsonResp.templateName);

          if (jsonResp.publishedflag && !jsonResp.workFlowCompletionFlag) {// both true direct PDF VIEW
            this.pdfView = true;
            this.documentPreview(jsonResp);
          }
        } else {
          jsonResp.formData = [];
          let publishCount =0;
          jsonResp.formDataList.forEach((element, i) => {
            if(element.publishedflag){
              publishCount++;
            }
            element.formDataArray = [{ formData: JSON.parse(element.formData) }];
          });
          
          if(jsonResp.formDataList.length!=0){
            this.toggle(this.nextId,jsonResp);
            debugger
            if (jsonResp.formDataList.length == publishCount && !jsonResp.workFlowCompletionFlag) {// both true direct PDF VIEW
              this.pdfView = true;
              this.documentPreview(jsonResp);
             
            }
          }
        }
        this.tempDynamicForm = JSON.parse(JSON.stringify(jsonResp));
        this.popupdata.push(jsonResp);
        this.viewIndividualData = true;

      } else
        this.spinnerFlag = false;
    }, error => this.spinnerFlag = false);
  }

  closeDetailView() {
    this.viewIndividualData = false;
    this.pdfURL = ''; 
    this.pdfName = '';
    this.loadData(this.masterDynamicFormId, '' + this.isMapping);
  }
  openSuccessCancelSwal(data) {
    var obj=this
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      obj.deleteTemplate(data);
    });
  }
    deleteTemplate(data) {
      let dynamicForm=JSON.parse(JSON.stringify(data));
      if(this.isMapping){
        this.nextId
        dynamicForm.id=dynamicForm.formDataList[+this.nextId].id;
      }
      this.spinnerFlag = true;
      dynamicForm.formData='[]';
      dynamicForm.updatedBy  = this.currentUser.id;
      dynamicForm.loginUserId  = this.currentUser.id;
      dynamicForm.organizationOfLoginUser = this.currentUser.orgId;
      dynamicForm.projectId=this.currentUser.projectId;
      dynamicForm.globalProjectId=this.currentUser.projectId;
      dynamicForm.projectVersionId=this.currentUser.versionId;
      this.dynamicService.deleteDynamicForm(dynamicForm)
        .subscribe((resp) => {
          this.spinnerFlag = false;
          let responseMsg: string = resp.result;

          if (responseMsg === "success") {
            swal({
              title: 'Deleted!',
              text:this.dynamicForm.templateName + ' Record has been Deleted',
              type:'success',
              timer:2000,
              showConfirmButton:false,
              onClose: () => {
                this.viewIndividualData = false;
                this.loadData(this.masterDynamicFormId,''+this.isMapping);
              }
            });
          } else {
            swal(
              'Not Deleted!',
              this.dynamicForm.templateName + 'Record has not been Deleted',
              'error'
            );

          }

        }, (err) => {
          swal(
            'Not Deleted!',
            this.dynamicForm.templateName+ 'Record has not been Deleted',
            'error'
          );
          this.spinnerFlag = false;
        });
      }
  publish(){
    this.spinnerFlag=true;
    this.dynamicService.publishMultipleDynamicForm(this.data).subscribe(result => {
      this.isSelectedPublishData=false;
      this.spinnerFlag=false;
      this.loadData(this.masterDynamicFormId,''+this.isMapping);
      },error=>{this.spinnerFlag=false;});
}
  individualPublish(data, index) {
   let formName=data.templateName;
    debugger
    let list = new Array();
    let dynamicForm = JSON.parse(JSON.stringify(data));
    if (this.isMapping) {
      dynamicForm.id = dynamicForm.formDataList[+index].id;
      formName=dynamicForm.formDataList[+index].formName;
    }
    this.spinnerFlag = true;
    dynamicForm.formData = '[]';
    dynamicForm.updatedBy = this.currentUser.id;
    dynamicForm.loginUserId = this.currentUser.id;
    dynamicForm.organizationOfLoginUser = this.currentUser.orgId;
    dynamicForm.projectId = this.currentUser.projectId;
    dynamicForm.globalProjectId = this.currentUser.projectId;
    dynamicForm.projectVersionId = this.currentUser.versionId;
    dynamicForm.publishedflag = true;
    list.push(dynamicForm);
    this.dynamicService.publishMultipleDynamicForm(list).subscribe(result => {
      this.isSelectedPublishData = false;
      this.spinnerFlag = false;
      if(result.result=='success'){
        swal({
          title:'Pulished!',
          text:formName+' has published Successfully!',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false,
          onClose: () => {
            this.viewRowDetails(data,location.pathname);
          }
        });
      }else{
        swal({
          title:'Error',
          text:'Some Internal Issue has been occured. We will get back to You',
          type:'error',
          timer:this.helper.swalTimer
        })
      }
    },err=>{
      swal({
        title:'Error',
        text:'Some Internal Issue has been occured. We will get back to You',
        type:'error',
        timer:this.helper.swalTimer
      })
      this.spinnerFlag=false;
    });
  }

  selectAllData(event) {
    this.selectAll = event.currentTarget.checked;
    if (event.currentTarget.checked) {
      this.data.forEach(d => {
        if (this.permissionMap[d.permissionConstant].publishButtonFlag) {
          if (!this.isMapping) {
            d.loginUserId = this.currentUser.id;
            d.organizationOfLoginUser = this.currentUser.orgId;
            d.projectId = this.currentUser.projectId;
            d.globalProjectId = this.currentUser.projectId;
            d.projectVersionId = this.currentUser.versionId;
            d.publishedflag = true;
          } else {
            if (this.isMapping && (this.isWorkflowDocumentOrderSequence && (!d.workFlowSequenceFlag || d.perviousGroupPartCompleted))) {
              d.loginUserId = this.currentUser.id;
              d.organizationOfLoginUser = this.currentUser.orgId;
              d.projectId = this.currentUser.projectId;
              d.globalProjectId = this.currentUser.projectId;
              d.projectVersionId = this.currentUser.versionId;
              d.publishedflag = true;
            }
          }
        }
      });
      this.isSelectedPublishData = true;
    } else {
      this.data.filter(d => d.publishedflag).forEach(d => {
        d.publishedflag = false;
      });
      this.isSelectedPublishData = false;
    }
  }

  onChangePublishData(row) {
    row.publishedflag = !row.publishedflag;
    row.loginUserId = this.currentUser.id;
    row.organizationOfLoginUser = this.currentUser.orgId;
    row.projectId = this.currentUser.projectId;
    row.globalProjectId = this.currentUser.projectId;
    row.projectVersionId = this.currentUser.versionId
    if (this.isMapping && row.commonWorkFlowForGroupForm) {
      this.data.filter(d => row.uniqueId == d.uniqueId).forEach(ele => {
        if (row.uniqueId == ele.uniqueId) {
          ele.publishedflag = row.publishedflag;
          ele.loginUserId = this.currentUser.id;
          ele.organizationOfLoginUser = this.currentUser.orgId;
          ele.projectId = this.currentUser.projectId;
          ele.globalProjectId = this.currentUser.projectId;
          ele.projectVersionId = this.currentUser.versionId
        }
      });
    }
   

    this.isSelectedPublishData = this.data.filter(d => d.publishedflag).length > 0 ? true : false;
  }

  downloadTemplate(type: any, data: DynamicFormDTO) {
    this.spinnerFlag = true;
    let fileName = data.dynamicFormCode + "." + type;
    this.tempDynamicForm.downloadDocType = type;
    this.tempDynamicForm.formData = JSON.stringify(this.tempDynamicForm.formData);
    this.dynamicService.downloadPreviewDocument(this.tempDynamicForm).subscribe(resp => {
      this.tempDynamicForm.formData = JSON.parse(this.tempDynamicForm.formData);
      this.spinnerFlag = false;
      this.adminComponent.previewByBlob(fileName, resp, false, '');
    });
  }

  toggle(index,data){
    this.spinnerFlag=true;
    this.nextId = index
    var ele = index == -1 ? undefined : data.formDataList[+index];
    if (ele != undefined){
      this.permissionBasedOnModule(ele.permissionConstant,this.mappingId);
      this.individualconstants = ele.permissionUniqueConstant;
      this.individualId = ele.id;
      if(this.auditTrail && this.auditTrail.viewFlag)//when audit is in view and tab is changes need to update the audit
      this.auditTrail.loadData(this.individualconstants,this.individualId);
      this.stepperfunction(ele.permissionUniqueConstant,data.dynamicFormCode,ele.id,ele.publishedflag,
        data.createdBy,data.updatedTime,data.displayCreatedTime,data.displayUpdatedTime,data.updatedByName,data.templateName);
    }
    this.spinnerFlag=false;
   }


   stepperfunction(documentConstant,code,id,publishedflag,creatorId,updatedTime,displayCreatedTime,displayUpdatedTime,updatedBy,templateName) {
    this.spinnerFlag=true;
    this.globalPublishFlag=publishedflag;
    const stepperModule: StepperClass = new StepperClass();
     stepperModule.constantName = documentConstant;
     stepperModule.code = code;
     stepperModule.documentIdentity = id;
     stepperModule.publishedFlag = publishedflag;
     stepperModule.creatorId = creatorId;
     stepperModule.lastupdatedTime = updatedTime;
     stepperModule.displayCreatedTime = displayCreatedTime;
     stepperModule.displayUpdatedTime = displayUpdatedTime;
     stepperModule.documentTitle = templateName;
     stepperModule.createdBy = creatorId;
     stepperModule.updatedBy = updatedBy;
     this.helper.stepperchange(stepperModule);
     this.spinnerFlag=false;
  }

  tabChange(id: any){
    this.isSelectedPublishData=false;
    this.data.forEach(element => {
       element.publishedflag=false; 
    });
    
  }
  verify(data){
    if(this.isMapping){
     let ele=data.formDataList[+this.nextId];
      this.formVerification.openMyModal(ele.permissionUniqueConstant,data.dynamicFormCode,ele.id);
    }else{
      this.formVerification.openMyModal(data.permissionConstant,data.dynamicFormCode,data.id);
    }
  }

  cloneOfDynamicForm(data){
    this.spinnerFlag=true;
    let dynamicForm=JSON.parse(JSON.stringify(data));
    delete dynamicForm.formData
    this.permissionService.HTTPPostAPI(dynamicForm,"dynamicForm/cloneDynamicFormForProject").subscribe((resp) => {
      if(resp.result=='success'){
        swal({
          title:'Copied Successfully!',
          text:' ',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false,
          onClose: () => {
            this.loadData(this.masterDynamicFormId,''+this.isMapping);
          }
        });
      }else{
        swal({
          title:'Error',
          text:'Some Internal Issue has been occured. We will get back to You',
          type:'error',
          timer:this.helper.swalTimer
        })
        this.spinnerFlag=false;
      }
    },err=>{
      swal({
        title:'Error',
        text:'Some Internal Issue has been occured. We will get back to You',
        type:'error',
        timer:this.helper.swalTimer
      })
      this.spinnerFlag=false;
    });
    

  }

  permissionBasedOnModule(permissionConstant,groupId){
    this.permissionService.loadPermissionsBasedOnModule(permissionConstant,'',groupId).subscribe(resp=>{
      this.permissionModel=resp;
      
    });
  }

  documentPreview(data) {
    if (this.pdfView) {
      if(this.pdfName && !this.pdfName.includes(data.dynamicFormCode)){
        this.pdfURL='';
      }
      if (!this.pdfURL) {
        this.spinnerFlag = true;
        let dynamicForm = JSON.parse(JSON.stringify(data));
        dynamicForm.formData = JSON.stringify(data.formData);
        this.dynamicService.loadPreviewDocument(dynamicForm).subscribe(resp => {
          this.spinnerFlag = false;
          if (resp != null) {
            const blob: Blob = new Blob([resp], { type: "application/pdf" });
            this.pdfURL = URL.createObjectURL(blob)
            this.pdfName = dynamicForm.dynamicFormCode + ".pdf";
          }
        }, err => {
          this.spinnerFlag = false;
        });
      }
    }
  }
  downloadRawPDF(data:any){
    this.adminComponent.downloadOrViewFile(data.dynamicFormCode+"_RawData.pdf",data.apiRawDataFilePath,false);
  }
}
