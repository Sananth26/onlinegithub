import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { SelectModule } from 'ng-select';
import { CKEditorModule } from 'ng2-ckeditor';
import { UiSwitchModule } from 'ng2-ui-switch';
import { QuillEditorModule } from 'ngx-quill-editor';
import { SqueezeBoxModule } from 'squeezebox';

import { AuthGuardService } from '../../layout/auth/AuthGuardService';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { SharedModule } from '../../shared/shared.module';
import { SharedCommonModule } from '../../shared/SharedCommonModule';
import { DMSService } from '../dms/dms.service';
import { DocumentsignComponentModule } from '../documentsign/documentsign.module';
import { DynamicFormService } from '../dynamic-form/dynamic-form.service';
import { stepperProgressModule } from './../stepperprogress/stepperprogress.module';
import { DynamicFormViewComponent } from './dynamic-form-view.component';
import { DynamicFormViewService } from './dynamic-form-view.service';
import {WorkFlowDynamicFormService} from '../work-flow-dynamic-form/work-flow-dynamic-form.service'
import {DocumentStatusCommentLog} from '../document-status-comment-log/document-status-comment-log.module'
import { DocumentForumModule } from '../document-forum/document-forum.module';
import { AuditTrailViewModule } from '../audit-trail-view/audit-trail-view.module';
import { IndividualAuditModule } from '../individual-audit-trail/individual-audit-trail.module';
import { FormEsignVerificationModule } from '../form-esign-verification/form-esign-verification.module';
import { PDFViewerModule } from '../pdf-viewer/pdf-viewer.module';
export const FormView: Routes = [
  {
      path: '',
      component: DynamicFormViewComponent,
      canActivate: [ AuthGuardService ],
  }
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(FormView),
    SharedCommonModule,
    SharedModule,
    FormsModule,
    QuillEditorModule,
    NgxDatatableModule,
    SqueezeBoxModule,
    UiSwitchModule,
    DocumentsignComponentModule,
    SelectModule, CKEditorModule,
    stepperProgressModule,
    DocumentForumModule,
    DocumentStatusCommentLog, 
    AuditTrailViewModule, 
    IndividualAuditModule, 
    FormEsignVerificationModule,
    PDFViewerModule
  ],
  declarations: [DynamicFormViewComponent],
  providers: [Helper,WorkFlowDynamicFormService, ConfigService, DynamicFormViewService,DynamicFormService,DMSService,DatePipe],

})
export class DynamicFormViewModule { }
