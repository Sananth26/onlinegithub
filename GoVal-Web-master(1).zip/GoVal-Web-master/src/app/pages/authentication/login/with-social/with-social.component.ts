import { Component, Inject, OnInit, ViewEncapsulation } from '@angular/core';
import { DOCUMENT } from "@angular/platform-browser";
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import { AuthGuardService } from '../../../../layout/auth/AuthGuardService';
import { CommonModel, JsonResponse, User } from "../../../../models/model";
import { ConfigService } from '../../../../shared/config.service';
import { Helper } from '../../../../shared/helper';
import { projectsetupService } from "../../../projectsetup/projectsetup.service";
import { AuthenticationService } from '../../authentication.service';
@Component({
  selector: 'app-with-social',
  templateUrl: './with-social.component.html',
  styleUrls: ['./with-social.component.css', './../../../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class WithSocialComponent implements OnInit {
  submitted: boolean = false;
  model: User;
  response: JsonResponse;
  loading: boolean = false;
  inValidCredentials : boolean = false;
  inActiveSession : boolean = false;
  modal: CommonModel;
  message:string="";
  hitsCount:number = 0;
  inToManyAtt:boolean = false;
  timeLeft: number = 60;
  interval;
  constructor(public helper:Helper,public router:Router,@Inject(DOCUMENT) document:any,public authenticationService:AuthenticationService, public projectsetupService: projectsetupService,public permission:AuthGuardService, public configService: ConfigService) {
    if (localStorage.length!=0 && null!= localStorage.getItem("token")) {
      this.router.navigate(["/MainMenu"])
  }
  }

  ngOnInit() {
  this.model=new User();
  this.response = new JsonResponse();

}

  onSubmit(formIsValid){
    this.submitted = true;
    this.loading = true;
    this.model.userName;
    this.model.password;
    if (formIsValid) {
      this.authenticationService.loginCall(this.model).subscribe(jsonResp => {
        this.loading = false;
          let responseMsg = jsonResp.result;
          if (responseMsg === "success") {
              this.modal = new CommonModel();
              localStorage.setItem("token", jsonResp.token);
            if (jsonResp.userData.adminFlag == "A") {
                this.router.navigate(["/MainMenu"]);
            } else {
              if (jsonResp.userData.newUser === true) {
                this.router.navigate(["/changePassword"]);
              } else {
                this.router.navigate(["/home"]);
              }
            }

          }else if(responseMsg === "ActiveSessionExists"){
            this.loading = false;
            this.submitted = false ;
            this.inValidCredentials = false;
            this.inToManyAtt = false;
            this.inActiveSession = true;
            var classObject = this;
            swal({
              title: 'You have already active session. You want to clear and Login?',
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Yes,Clear!',
              cancelButtonText: 'No, cancel!',
              confirmButtonClass: 'btn btn-success m-r-10',
              cancelButtonClass: 'btn btn-danger',
              buttonsStyling: false
            }).then(function () {
              classObject.inActiveSession = false;
              classObject.authenticationService.clearSession(classObject.model.userName).subscribe(jsonResp => {
                if(!classObject.helper.isEmpty(classObject.model.userName) && !classObject.helper.isEmpty(classObject.model.password))
                  classObject.onSubmit(true);
              });
            });
          }else {
            this.loading = false;
            this.submitted = false ;
            this.inValidCredentials = true;
            this.inActiveSession = false;
            this.message=jsonResp.message;
            this.hitsCount = this.hitsCount + 1;
            if(this.hitsCount == 5){
              this.inToManyAtt = true;
              this.inValidCredentials = false;
              this.startTimer();
            }
          }
        },
        err => {
          this.loading = false;
        }
      );
    } else {
      this.loading = false;
    }
  }
  startTimer() {
    this.interval = setInterval(() => {
      if(this.timeLeft > 0) {
        this.timeLeft--;
        if(this.timeLeft == 0)
             window.location.reload();
      } else {
        this.timeLeft = 60;
      }
    },1000)
  }
  onChange(){
    this.inValidCredentials = false;
    this.inToManyAtt = false;
}

keyDownFunction(event,formIsValid) {
  if(event.keyCode == 13) {
      this.onSubmit(formIsValid);
  }
}

  onclick(){
    this.router.navigate(["/forgetPassword"]);
  }
}
