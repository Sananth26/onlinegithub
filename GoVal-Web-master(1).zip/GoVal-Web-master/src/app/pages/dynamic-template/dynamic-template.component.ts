import { Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { DynamicTemplateDTO, StepperClass, WorkflowDocumentStatusDTO,UserPrincipalDTO } from '../../models/model';
import { Permissions } from '../../shared/config';
import { CommonFileFTPService } from '../common-file-ftp.service';
import { ConfigService } from '../../shared/config.service';
import { AdminComponent } from '../../layout/admin/admin.component';
import { Helper } from '../../shared/helper';
import { ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';
import { DynamicTemplateService } from './dynamic-template.service';
import { TaskCreationService } from '../task-creation/task-creation.service';
import { FormEsignVerificationComponent } from '../form-esign-verification/form-esign-verification.component';

@Component({
  encapsulation: ViewEncapsulation.None,
  selector: 'app-dynamic-template',
  templateUrl: './dynamic-template.component.html',
  styleUrls: ['./dynamic-template.component.css', './../../../../node_modules/sweetalert2/dist/sweetalert2.min.css']
})
export class DynamicTemplateComponent implements OnInit {
  @ViewChild('auditSingleView') auditSingleView
  @ViewChild('formVerification') formVerification:FormEsignVerificationComponent;
  public submitted = false;
  public spinnerFlag = false;
  dynamicTemplate = new DynamicTemplateDTO();
  permissionModel: Permissions = new Permissions(this.helper.TEMPLATE_VALUE, false);
  permissionData: any;
  singleFileUploadFlag: boolean = false;
  multiFileUploadFlag: boolean = false;
  uploadSingleFile: any;
  fileValidationMessage: any = "";
  revisionArray:any[]=new Array<any>();
  leftRevisionArray:any[]=new Array<any>();
  rightRevisionArray:any[]=new Array<any>();
  sourceFile:string="";
  compareFile:string="";
  revisionValidationMessage:string="";
  modalSpinner:any=false;
  sourceFileName:any;
  compareFileName:any;
  routeback:any;
  viewIndividualData: boolean = false;
  currentUser:UserPrincipalDTO=new  UserPrincipalDTO();
  isWorkflowDocumentOrderSequence:boolean=false;
  public individualconstants :any;
  public individualId :any;
  projectTaskviewFlag:boolean=false;
  pendingTaskList: any[]=new Array();
  constructor(public activeRouter: ActivatedRoute, public service: DynamicTemplateService, public helper: Helper, private adminComponent: AdminComponent, public permissionService: ConfigService, private commonService: CommonFileFTPService, private taskCreationService: TaskCreationService) {
  }

  ngOnInit() {
    this.permissionService.loadCurrentUserDetails().subscribe(res=>{
      this.currentUser=res;
        this.adminComponent.setUpModuleForHelpContent("");
        this.adminComponent.taskEnbleFlag = true;
        this.adminComponent.taskDocType = "";
        this.adminComponent.taskDocTypeUniqueId = "";
        this.adminComponent.taskEquipmentId = 0;
        this.activeRouter.queryParams.subscribe(queryData => {
          if(queryData.status!=undefined){
            this.routeback = queryData.status;
            this.loadDynamicTemplate(queryData.id, queryData.exists,queryData.status);
            this.helper.changeMessageforId(queryData.id);
          }else{
            this.loadDynamicTemplate(queryData.id, queryData.exists,queryData.status);
          }
        });

          this.helper.listen().subscribe((m:any) => {
          this.loadDynamicTemplate(m,"true","/documentapprovalstatus")
      });
    });
  }

    loadDynamicTemplate(id,exists,redirectUrl){
     if(redirectUrl){
       this.routeback=redirectUrl;
     }else{
      this.routeback="/MainMenu"
     }

    if("/documentapprovalstatus" === exists|| this.helper.isEmpty(exists))
            exists="true";
          
      
    this.service.loadDynamicTemplateForProject({ "id": id, "exists": exists }).subscribe(res => {
      if (res != null) {
        this.dynamicTemplate = res;
        this.adminComponent.taskDocType = this.dynamicTemplate.permissionConstant;
        this.adminComponent.taskDocTypeUniqueId = id;
        this.adminComponent.taskEnbleFlag = true;
        this.adminComponent.taskEquipmentId =0;
        this.workflowfunction(res);
        this.permissionService.loadPermissionsBasedOnModule(this.dynamicTemplate.permissionConstant).subscribe(resp=>{
          this.permissionModel=resp;
        });
        this.permissionService.isWorkflowDocumentOrderSequence(this.dynamicTemplate.permissionConstant).subscribe(resp => {
          this.isWorkflowDocumentOrderSequence = resp;
        });
        this.adminComponent.setUpModuleForHelpContent(this.dynamicTemplate.permissionConstant);
        this.spinnerFlag = false;
        this.downloadFileOrView(this.dynamicTemplate, true);
        if(this.dynamicTemplate.id!=0){
          let stepperModule: StepperClass= new StepperClass();
          stepperModule.constantName = this.dynamicTemplate.permissionConstant;
          stepperModule.documentIdentity = this.dynamicTemplate.id;
          stepperModule.code = this.dynamicTemplate.dynamicTemplateCode;
          stepperModule.publishedFlag = this.dynamicTemplate.publishedflag;
          stepperModule.creatorId=this.dynamicTemplate.createdBy;
          stepperModule.lastupdatedTime= this.dynamicTemplate.updatedTime;
          stepperModule.displayCreatedTime= this.dynamicTemplate.displayCreatedTime;
          stepperModule.displayUpdatedTime= this.dynamicTemplate.displayUpdatedTime;
          stepperModule.documentTitle=this.dynamicTemplate.templateName;
          stepperModule.createdBy= this.dynamicTemplate.createdByName;
          stepperModule.updatedBy= this.dynamicTemplate.lastUpdatedByName;
          this.helper.stepperchange(stepperModule);
          this.individualconstants=this.dynamicTemplate.permissionConstant;
          this.individualId= this.dynamicTemplate.id;
        }
        if(this.auditSingleView && this.auditSingleView.viewFlag)//when audit is in view and tab is changes need to update the audit
          this.auditSingleView.loadData(this.individualconstants,this.individualId);
          this.loadTaskData();
      } else {
        this.spinnerFlag = false
      }
    })
  }

  workflowfunction(jsonResp: any) {
    if ( jsonResp .publishedflag) {
      const workflowmodal: WorkflowDocumentStatusDTO = new WorkflowDocumentStatusDTO();
        workflowmodal.documentType = jsonResp.permissionConstant;
        workflowmodal.documentId = jsonResp.id;
        workflowmodal.currentLevel = jsonResp.currentCommonLevel;
        workflowmodal.documentCode = jsonResp.dynamicTemplateCode;
        workflowmodal.workflowAccess = jsonResp.workflowAccess;
        workflowmodal.docName = jsonResp.templateName;
        workflowmodal.publishFlag = jsonResp.publishedflag;
        this.helper.setIndividulaWorkflowData(workflowmodal);
        }
  }

  saveDynamicTemplateData(formValid) {
    this.submitted = true;
    if (this.dynamicTemplate.fileName == "" || this.fileValidationMessage != "") {
      return
    } else {
      if (this.dynamicTemplate.id == 0) {
        this.dynamicTemplate.createdBy = this.currentUser.id;
      }
      this.dynamicTemplate.updatedBy =this.currentUser.id;
      this.dynamicTemplate.loginUserId =this.currentUser.id;
      this.dynamicTemplate.organizationOfLoginUser = this.currentUser.orgId;
      this.dynamicTemplate.projectId = this.currentUser.projectId;
      this.dynamicTemplate.globalProjectId = this.currentUser.projectId;
      this.dynamicTemplate.projectVersionId = this.currentUser.versionId;
      this.service.saveDynamicTemplateForProject(this.dynamicTemplate).subscribe(data => {
        if (data.result.message == "success") {
          this.spinnerFlag = false;
          swal({
            title:'Saved Successfully!',
            text:this.dynamicTemplate.templateName + ' template has been saved.',
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
              if(this.dynamicTemplate.id==0){
                let url = 'newDynamicTemplate?'+ data.result.id +'&true'
                this.adminComponent.redirect(url);
                 }
              this.adminComponent.loadNavBarTemplates();
            }
          });
        }
      }, error => {
        this.spinnerFlag = false;
        swal({
          title:'Error in Saving',
          text:this.dynamicTemplate.templateName + ' template has not  been saved',
          type:'error',
          timer:this.helper.swalTimer
        }

        );
      });
    }
  }
  deleteTemplateSwal(id) {
    var obj = this
    swal({
      title: 'Are you sure?',
      text: 'You wont be able to revert',
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success m-r-10',
      cancelButtonClass: 'btn btn-danger',
      allowOutsideClick: false,
      buttonsStyling: false
    }).then(function () {
      obj.deleteTemplate(id);
    });
  }
  deleteTemplate(id) {
    this.spinnerFlag = true;
    let dynamicTemplate = new DynamicTemplateDTO();
    dynamicTemplate.id = id;
    dynamicTemplate.updatedBy = this.currentUser.id;
    dynamicTemplate.loginUserId = this.currentUser.id;
    dynamicTemplate.organizationOfLoginUser = this.currentUser.orgId;
    dynamicTemplate.projectId = this.currentUser.projectId;
    dynamicTemplate.globalProjectId = this.currentUser.projectId;
    this.dynamicTemplate.projectVersionId = this.currentUser.versionId;
    this.service.deleteDynamicTemplate(dynamicTemplate)
      .subscribe((resp) => {
        this.spinnerFlag = false;
        let responseMsg: string = resp.result;
        if (responseMsg === "success") {
          swal({
            title:'Deleted!',
            text:this.dynamicTemplate.templateName + ' record has been deleted.',
            type:'success',
            timer:this.helper.swalTimer,
            showConfirmButton:false,
            onClose: () => {
                let url = 'newDynamicTemplate?'+ this.dynamicTemplate.masterDynamicTemplateId +'&false';
                this.adminComponent.redirect(url);
                this.adminComponent.loadNavBarTemplates();
            }
          });
        } else {
          swal({
            title:'Not Deleted!',
            text:this.dynamicTemplate.templateName + ' has  not been deleted.',
            type:'error',
            timer:this.helper.swalTimer
          });
        }
      }, (err) => {
        swal({
          title:'Not Deleted!',
          text:this.dynamicTemplate.templateName + 'has  not been deleted.',
          type:'error',
          timer:this.helper.swalTimer
        });
        this.spinnerFlag = false;
      });
  }

 

  /* START:PDF OPERATIONS*/
  deleteUploadedFile() {
    this.dynamicTemplate.filePath = "";
    this.dynamicTemplate.fileName = "";
    this.deletePDFView();
  }
  deletePDFView() {
    if (document.getElementById("iframeView")) {
      document.getElementById("iframeView").remove();
      document.getElementById("fileUploadIdDynamicTemplate").setAttribute("class", "form-group row");
    }

  }
  onSingleFileUpload(event) {
    this.fileValidationMessage = "";
    this.deletePDFView();
    if (event.target.files.length != 0) {
      this.spinnerFlag = true;
      let file = event.target.files[0];
      let fileName = event.target.files[0].name;
      this.singleFileUploadFlag = true;
      if (fileName.toLocaleLowerCase().match('.doc') || fileName.toLocaleLowerCase().match('.docx') || fileName.toLocaleLowerCase().match('.pdf')) {
        let filePath = "IVAL/" + this.currentUser.orgId + "/" + this.currentUser.projectId + "/dynamicTemplate/";
        const formData: FormData = new FormData();
        formData.append('file', file, fileName);
        formData.append('filePath', filePath);
        formData.append('extension', fileName.split(".")[fileName.split(".").length - 1]);
        this.commonService.singleFileUpload(formData).subscribe(resp => {
          this.spinnerFlag = false;
          if(resp.result){
            this.dynamicTemplate.filePath = resp.path;
            this.dynamicTemplate.fileName = fileName;
            this.singleFileUploadFlag = false;
            this.downloadFileOrView(this.dynamicTemplate, true);
          }else{
            this.downloadFileOrView(this.dynamicTemplate, true);
          }
        }, error => {
          this.spinnerFlag = false;
          this.singleFileUploadFlag = false;
        });
        
      } else {
        this.spinnerFlag = false;
        this.singleFileUploadFlag = false;
        this.fileValidationMessage = "Upload .pdf,.doc,.docx file only";
      }
    }
  }
  downloadFileOrView(input, viewFlag) {
    if (this.permissionModel.exportButtonFlag || viewFlag) {
    this.spinnerFlag = true;
    let filePath = input.filePath;
    let fileName = input.fileName;
    this.commonService.loadFile(filePath).subscribe(resp => {
      let contentType = this.commonService.getContentType(fileName.split(".")[fileName.split(".").length - 1]);
      var blob: Blob = new Blob([resp], { type: contentType });
      if (viewFlag) {
        if (!contentType.match(".pdf")) {
          this.commonService.convertFileToPDF(blob, fileName).then((respBlob) => {
            this.createIFrame(URL.createObjectURL(respBlob));
          });
        } else {
          this.createIFrame(URL.createObjectURL(blob));
        }
      } else {
        this.commonService.downloadFileAudit(fileName,input.templateName,"138",input.dynamicTemplateCode,input.masterDynamicTemplateId);
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, fileName);
        } else {
          var a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
        this.spinnerFlag = false;
      }
    },error=>{
      this.spinnerFlag = false;
    })
  }
}
  /* END:PDF OPERATIONS*/
  createIFrame(blob_url) {
    var iframe;
    var elementExists = document.getElementById("iframeView");
    if (!elementExists)
      iframe = document.createElement('iframe');
    else
      iframe = elementExists;

    iframe.setAttribute("id", "iframeView")
    iframe.setAttribute("height", "1200px");
    iframe.setAttribute("width", "1000px");
    iframe.src = blob_url;
    let find = document.querySelector('#fileUploadIdDynamicTemplate');
    find.setAttribute("class", "well well-lg form-group row");
    find.appendChild(iframe);
    this.spinnerFlag = false;
  }
  publishDynamicTemplateData(){
    this.service.publish(this.dynamicTemplate.id).subscribe((resp) => {
        swal({
          title:'Published Successfully!',
          text:this.dynamicTemplate.templateName+ ' template has been published.',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false,
          onClose: () => {
            this.adminComponent.loadNavBarTemplates();
              this.ngOnInit();
          }
        });
    });
  }

revisionForDocument(dto){
  this.viewIndividualData=true;
  var element= document.getElementById("overflowCompareId");
  element.setAttribute("style", "visibility:hidden");
  this.sourceFile="";
  this.compareFile="";
  this.modalSpinner=false;
  this.service.loadDynamicTemplateLogBasedOnId({id:dto.id,masterTemplateId:dto.masterDynamicTemplateId}).subscribe(resp => {
    if(resp.list!=null){

      this.revisionArray=resp.list;
      this.leftRevisionArray=resp.list;
      this.rightRevisionArray=resp.list;
    }
  });
}

removeDataFromList(id,leftOrRightSideFlag){
  if(leftOrRightSideFlag){
    this.leftRevisionArray= this.revisionArray.filter(value=>value.id!=id);
  }else{
    this.rightRevisionArray= this.revisionArray.filter(value=>value.id!=id);
  }
}
   /*END:REVISION FOR DOCUMENT*/

   getFileNameForRevisionRight(value){
     this.sourceFileName = value.currentTarget.selectedOptions[0].label;
   }
   getFileNameForRevisionLeft(value){
     this.compareFileName = value.currentTarget.selectedOptions[0].label;
   }

compareTwoFile() {
  this.modalSpinner=true;
  this.revisionValidationMessage = "";
  if (this.sourceFile == '')
    this.revisionValidationMessage = "Please Select the file in Source File Drop Down";
  if (this.compareFile == '')
    this.revisionValidationMessage = "Please Select the file in Compare File Drop Down";
  if (this.sourceFile == '' && this.compareFile == '')
    this.revisionValidationMessage = "Please Select the file in both Drop Down";

  if (this.revisionValidationMessage != '') {
    this.modalSpinner=false;
    return;
  } else {
    this.commonService.compareTwoFile({sourceFilePath:this.sourceFile,compareFilePath: this.compareFile}).subscribe(res=>{
      let data = {"sourceFileName":this.sourceFileName,"compareFile":this.compareFileName,
                  "templateName":this.dynamicTemplate.templateName,"uniqid":this.dynamicTemplate.dynamicTemplateCode,"value":this.dynamicTemplate.masterDynamicTemplateId,
                   "isTemplate":true};
      this.commonService.auditRevision(data).subscribe(resp=>{});
      var sourceFile = <any>document.getElementById("sourceFileId");
      var compareFile = <any>document.getElementById("compareFileId");
       var sourceFileContentBinary = window.atob(res.sourceFileContent);
         var sourceFileContentArray = [];
      for (var i = 0; i < sourceFileContentBinary.length; i++) {
        sourceFileContentArray.push(sourceFileContentBinary.charCodeAt(i));
      }

        setTimeout( () => {
          sourceFile.src= URL.createObjectURL(new Blob([new Uint8Array(sourceFileContentArray)], {type: 'application/pdf'}));
        }, 1500);

        var diffrenceFileContentBinary = window.atob(res.diffrenceFileContent);
        var diffrenceFileContentArray = [];
     for (var i = 0; i < diffrenceFileContentBinary.length; i++) {
      diffrenceFileContentArray.push(diffrenceFileContentBinary.charCodeAt(i));
     }

       setTimeout( () => {
         compareFile.src= URL.createObjectURL(new Blob([new Uint8Array(diffrenceFileContentArray)], {type: 'application/pdf'}));
         var element= document.getElementById("overflowCompareId");
         element.setAttribute("style", "visibility:visible");
         this.modalSpinner=false;
        }, 1500);

    })
    }
}
onClickViewClose(){
  this.viewIndividualData=false;
  this.ngOnInit();
  this.sourceFile='';
  this.compareFile='';
  }
  loadTaskData() {
    this.taskCreationService.loadTasksForDocument(this.dynamicTemplate.permissionConstant).subscribe(res => {
      if (res.pendingList)
        this.pendingTaskList = res.pendingList;
    },
      err => {
        this.spinnerFlag = false;
      }
    );
  }

  verify(documentType,documentCode,documentId){
    this.formVerification.openMyModal(documentType,documentCode,documentId);
  }
}
