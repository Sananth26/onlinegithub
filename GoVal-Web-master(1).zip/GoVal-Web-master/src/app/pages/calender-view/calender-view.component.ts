import { DatePipe } from '@angular/common';
import { Component, OnInit, TemplateRef, ViewChild, ViewEncapsulation, ViewChildren, QueryList } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CalendarEvent, CalendarEventTimesChangedEvent } from 'angular-calendar';
import { isSameDay, isSameMonth, startOfDay } from 'date-fns';
import { Subject } from 'rxjs';
import swal from 'sweetalert2';
import { AdminComponent } from '../../layout/admin/admin.component';
import { CalendarColorDTO, CalendarEventDTO, UserPrincipalDTO, WeekDaysDTO } from '../../models/model';
import { Permissions } from '../../shared/config';
import { ConfigService } from '../../shared/config.service';
import { Helper } from '../../shared/helper';
import { LookUpService } from '../LookUpCategory/lookup.service';
import { CalenderViewService } from './calender-view.service';
import { DateFormatSettingsService } from '../date-format-settings/date-format-settings.service';
@Component({
  selector: 'app-calender-view',
  templateUrl: './calender-view.component.html',
  styleUrls: ['./calender-view.component.css', './../../../../node_modules/sweetalert2/dist/sweetalert2.min.css'],
  encapsulation: ViewEncapsulation.None
})
export class CalenderViewComponent implements OnInit {
  colors: any = {
    red: {
      primary: '#ad2121',
      secondary: '#FAE3E3'
    },
    blue: {
      primary: '#1e90ff',
      secondary: '#D1E8FF'
    },
    yellow: {
      primary: '#e3bc08',
      secondary: '#FDF1BA'
    }
  };
  @ViewChild('modalContent') modalContent: TemplateRef<any>;
  position=-1;
  view: string = "month";
  viewDate: Date = new Date();
  modalData: {
    action: string;
    event: CalendarEvent;
  };
  refresh: Subject<any> = new Subject();
  events: any[]=new Array();
  holidayEvents:any[]=new Array();
  activeDayIsOpen: boolean = false;
  spinnerFlag = false;
  weekDaysList:WeekDaysDTO[]=new Array();
  permissionData:any=new Array<Permissions>();
  permissionModal:Permissions=new Permissions("173",false);
  currentUser:UserPrincipalDTO=new UserPrincipalDTO();
  frequencyList=new Array();
  minDate = startOfDay(new Date());
  pattern="d-m-Y";
  constructor(private adminComponent: AdminComponent,public permissionService:ConfigService,
    private modal: NgbModal, public helper: Helper, public service: CalenderViewService,
    public datePipe: DatePipe,private lookUpService:LookUpService,private servie: DateFormatSettingsService) {
    this.loadWeekdays();
   }

  ngOnInit() {
    this.loadOrgDateFormat()
    this.loadAll();
    this.lookUpService.getlookUpItemsBasedOnCategory("dueDateFrequency").subscribe(res => {
      this.frequencyList = res.response;
    });
    this.permissionService.loadCurrentUserDetails().subscribe(resp=>{
      this.currentUser=resp;
    });
    this.permissionService.loadPermissionsBasedOnModule("173").subscribe(resp=>{
      this.permissionModal=resp;
    });
    
    this.adminComponent.setUpModuleForHelpContent("173");
  }
  loadAll() {
    this.spinnerFlag = true;
    this.service.loadCalendarEvents().subscribe(response => {
      this.spinnerFlag = false
      if (response.result != null) {
        this.events = response.result;
        this.holidayEvents= response.result;

      }
    }, error => { this.spinnerFlag = false });
  }

  loadWeekdays() {
    this.service.loadWeekdays().subscribe(response => {
      let isIdNull=false;
      if (response.result != null) {
        this.weekDaysList = response.result;
        this.weekDaysList.forEach(day =>{
          isIdNull=this.helper.isEmpty(day.id);
          day.loginUserId =this.currentUser.id;
          day.organizationOfLoginUser = this.currentUser.orgId;
        });
        if(isIdNull)
          this.saveWeekdays(false);
      }
    });
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }

  eventTimesChanged({
    event,
    newStart,
    newEnd
  }:
    CalendarEventTimesChangedEvent): void {
    this.events = this.events.map(iEvent => {
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd
        };
      }
      return iEvent;
    });
    this.handleEvent('Dropped or resized', event);
  }

  handleEvent(action: string, event: CalendarEvent): void {
    this.modalData = { event, action };
    this.modal.open(this.modalContent, { size: 'lg' });
  }

  addEvent(): void {
    this.position=-1;
    this.holidayEvents = [
      ...this.holidayEvents,
      {
        id:0,
        title: 'New event',
        start: startOfDay(new Date()),
        end: '',
        color: this.colors.red,
        holidayFlag:'N',
        frequency:'noreminder'
      }
    ];
  }

  deleteEvent(eventToDelete: any) {
    this.refresh.next();
    this.holidayEvents = this.holidayEvents.filter(event => event !== eventToDelete);
    eventToDelete.loginUserId =this.currentUser.id;
    eventToDelete.organizationOfLoginUser = this.currentUser.orgId;
    if(eventToDelete.id >0)
    this.service.deleteCalendarEvent(eventToDelete).subscribe(jsonResp => {
      if (jsonResp.result === "success") {
        this.spinnerFlag = false;
        this.activeDayIsOpen = false;
        this.loadAll();
        swal({title:'',text:'Event Deleted Successfully',type:'success',timer:this.helper.swalTimer,showConfirmButton:false,
          onClose: () => {
          }
        });
      } else {
        swal({
          title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
        });
      }
    },
      err => {
        swal({
          title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
        });
        this.spinnerFlag = false
      }
    );
  }

  setView(view) {
    this.view = view;
  }

  closeOpenMonthViewDay() {
    this.activeDayIsOpen = false;
  }

  convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }

  saveEvent(event:any,index){
    if('Invalid Date'==event.end){
      this.position=index;
      return
    }else{
    this.spinnerFlag =true;
    this.position=-1
    let dto:CalendarEventDTO=new CalendarEventDTO();
    let color:CalendarColorDTO=new CalendarColorDTO();
    dto.id=event.id;
    dto.title=event.title;
    dto.start =  this.datePipe.transform(new Date(event.start), 'yyyy-MM-dd hh:mm:ss');
    dto.end = this.datePipe.transform(new Date(event.end), 'yyyy-MM-dd hh:mm:ss');
    color.primary=event.color.primary;
    color.secondary=event.color.secondary;
    dto.color=color;
    dto.frequency=event.frequency;
    dto.holidayFlag=event.holidayFlag;
    dto.loginUserId = this.currentUser.id;
    dto.organizationOfLoginUser = this.currentUser.orgId;
    this.service.createCalendarEvent(dto).subscribe(jsonResp => {
      this.spinnerFlag = false;
      let responseMsg: string = jsonResp.result;
      if (responseMsg === "success") {
        this.loadAll();
        swal({title:'',text:'Event Added Successfully',type:'success',timer:this.helper.swalTimer,showConfirmButton:false,
          onClose: () => {
          }
        });
      } else {
        swal({
          title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
        });
      }
    },
      err => {
        swal({
          title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
        });
        this.spinnerFlag = false;
      }
    );
  }
  }
  beforeMonthViewRender(renderEvent: any): void {
    renderEvent.body.forEach(day => {
      if (this.weekDaysList.length == 0) {
        this.service.loadWeekdays().subscribe(response => {
          if (response.result != null) {
            this.weekDaysList = response.result;
            this.weekDaysList.forEach(day => {
              day.loginUserId = this.currentUser.id;
              day.organizationOfLoginUser = this.currentUser.orgId;
            });
          }
          this.weekDaysList.forEach(weekday => {
            if (!weekday.selectedFlag && day.date.getDay() == weekday.weekdayCode)
              day.cssClass = 'bg-gray';
          });
        });
      } else {
        this.weekDaysList.forEach(weekday => {
          if (!weekday.selectedFlag && day.date.getDay() == weekday.weekdayCode)
            day.cssClass = 'bg-gray';
        });
      }
      this.events.forEach(event =>{
        if(event.holidayFlag === 'Y'){
          let oneDay = 24 * 60 * 60 * 1000;
          let startDate=new Date(event.start);
          let diffDays = Math.round(Math.abs((+new Date(event.start) - +new Date(event.end)) / oneDay));
          for(let i=1;i<=diffDays;i++){
            startDate.setDate(startDate.getDate() + 1);
            if(this.datePipe.transform(startDate, 'yyyy-MM-dd') === this.datePipe.transform(day.date, 'yyyy-MM-dd'))
              day.cssClass = 'bg-gray';
          }
          if(this.datePipe.transform(event.start, 'yyyy-MM-dd') === this.datePipe.transform(day.date, 'yyyy-MM-dd')){
            day.cssClass = 'bg-gray';
          }
        }else{
          this.weekDaysList.forEach(weekday => {
            if (weekday.selectedFlag && day.date.getDay() == weekday.weekdayCode){
              if (this.datePipe.transform(event.start, 'yyyy-MM-dd') === this.datePipe.transform(day.date, 'yyyy-MM-dd')) {
                day.cssClass = 'bg-white';
              }
            }
          });
        }
      });
    });
  }
  saveWeekdays(flag){
    this.service.saveWeekdays(this.weekDaysList).subscribe(jsonResp => {
      this.spinnerFlag = false;
      let responseMsg: string = jsonResp.result;
      if (responseMsg === "success") {
        this.loadAll();
        this.loadWeekdays();
        if(flag)
        swal({
          title:'',
          text:'Saved Successfully',
          type:'success',
          timer:this.helper.swalTimer,
          showConfirmButton:false,
          onClose: () => {
          }
        });
      } else {
        if(flag)
          swal({
            title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
          })
      }
    },
      err => {
        swal({
          title: '', text: 'Something went Wrong ...Try Again', type: 'error', timer: this.helper.swalTimer, showConfirmButton: false
        })
        this.spinnerFlag = false
      }
    );
  }

  tabChange(id: any){
    if(id==="holiday")
      this.loadAll();
  }

  getMinDate(start){
    if(this.datePipe.transform(start,"yyyy-MM-dd") < this.datePipe.transform(this.minDate,"yyyy-MM-dd"))
    return start;
    else
    return this.minDate;
  }
  loadOrgDateFormat() {
    this.servie.getOrgDateFormatForDatePicker().subscribe(result => {
        if (!this.helper.isEmpty(result)) {
            this.pattern = result.replace("y","Y");
        }
    });
  }
}
