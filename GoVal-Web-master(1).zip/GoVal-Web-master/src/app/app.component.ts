import { Component } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import swal from 'sweetalert2';
import { User } from './models/model';
import { Helper } from './shared/helper';
import { AdminComponent } from './layout/admin/admin.component';
import  {projectsetupService} from './pages/projectsetup/projectsetup.service';
import * as $ from "jquery";
import * as jQuery from "jquery";
@Component({
  selector: 'app-root',
  template: '<router-outlet><app-spinner></app-spinner></router-outlet>',
  styleUrls: ['./app.component.css'],
  host: {
    '(document:click)': 'onClickSessionExtend($event)',
    '(document:keypress)': 'onClickSessionExtend($event)',
  },
  providers: [AdminComponent,projectsetupService]
})
export class AppComponent {
  title = 'app';
  seconds=60;
  secondsText=`<p id="sessionSecondsText">Redirecting in 60 seconds.</p>`
  constructor(private http:Http){
    let interval;
   if(localStorage.getItem('token')){
      interval= setInterval(() => {
     if(localStorage.getItem('time')){
      let time=new Date().getTime();
      let timeOut=+atob(localStorage.getItem('time'))
      let toShowSessionPopUp=(timeOut - (1*60000));
      if(time>timeOut){
        this.logOut(interval);
      }else{
        if(time>toShowSessionPopUp&&time<timeOut){
         var ele= document.getElementById('sessionSecondsText');
         if(ele){
          this.seconds=this.seconds-1;
          let secondsText=`Redirecting in `+this.seconds+` seconds.`
          $('#sessionSecondsText').text(secondsText);
         }
        if(this.seconds==60){
          var that=this;
          swal({ title: 'You Session is About to Expire!',type: 'info',
            showCancelButton: true,confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',confirmButtonText: 'Stay Connected',
            cancelButtonText: 'Logout',confirmButtonClass: 'btn btn-primary m-r-10',
            cancelButtonClass: 'btn btn-default',allowOutsideClick: false,
            buttonsStyling: false,html: this.secondsText,timer:62000
          }).then(function (event) {
            that.seconds = 60;
          }).catch(err => {
            that.logOut(interval);
          });
        }
        }
      }
     }else{
       this.logOut(interval);
     }
   },1000);
  }else{
    if(interval)
    clearInterval(interval);
  }
  }

  logOut(interval){
    let  options = new RequestOptions();
    options.headers = new Headers();
    options.headers.append('Authorization', 'Bearer ' + localStorage.getItem("token"));
    let url=new Helper(null,null).common_URL + "user/logout";
      this.http.post(url, new User(),options).subscribe(res=>{
        localStorage.clear();
        location.href = "/authentication/login/with-social";
        if (interval)
          clearInterval(interval);
      },er=>{
        localStorage.clear();
        location.href = "/authentication/login/with-social";
 		if (interval)
          clearInterval(interval);
      })
       
  }
  
  onClickSessionExtend(event){
    localStorage.setItem("time",btoa(''+(new Date().getTime() + (25*60000))));
    new AppComponent(this.http);
  }
}
